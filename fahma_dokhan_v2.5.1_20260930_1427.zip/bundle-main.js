
/* === supabase.js === */
/**
 * Smart E-Menu - Supabase Integration Client
 * تهيئة الاتصال السحابي بقاعدة بيانات Supabase
 */

const DEFAULT_SUPABASE_URL = (window.__ENV__ && window.__ENV__.SUPABASE_URL) || "https://vyeolhhipsdcnntfbksy.supabase.co";
const DEFAULT_SUPABASE_ANON_KEY = (window.__ENV__ && window.__ENV__.SUPABASE_ANON_KEY) || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5ZW9saGhpcHNkY25udGZia3N5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkwNDk2MDksImV4cCI6MjEwNDYyNTYwOX0.mLBkQh2r1iCarmWU76xrQVQprq305hnDAK95nMe1yh8";

// دعم تمرير عنوان ومفتاح السحابة عبر الرابط (URL Params)
try {
  const p = new URLSearchParams(window.location.search);
  const u = p.get('sb_url');
  const k = p.get('sb_key');
  if (u && u.trim()) localStorage.setItem('smart_emenu_supabase_url', u.trim());
  if (k && k.trim()) localStorage.setItem('smart_emenu_supabase_anon_key', k.trim());
} catch(e) {}

function getActiveSupabaseUrl() {
  return localStorage.getItem('smart_emenu_supabase_url') || DEFAULT_SUPABASE_URL;
}

function getActiveSupabaseAnonKey() {
  return localStorage.getItem('smart_emenu_supabase_anon_key') || DEFAULT_SUPABASE_ANON_KEY;
}

const SUPABASE_URL = getActiveSupabaseUrl();
const SUPABASE_ANON_KEY = getActiveSupabaseAnonKey();

// إنشاء عميل Supabase ديناميكي
let supabaseClient = null;
let _cachedClientUrl = null;
let _cachedClientKey = null;

function getSupabase() {
  const currentUrl = getActiveSupabaseUrl();
  const currentKey = getActiveSupabaseAnonKey();
  if ((!supabaseClient || _cachedClientUrl !== currentUrl || _cachedClientKey !== currentKey) && window.supabase) {
    try {
      supabaseClient = window.supabase.createClient(currentUrl, currentKey);
      _cachedClientUrl = currentUrl;
      _cachedClientKey = currentKey;
    } catch (e) {
      console.warn("Supabase init warning:", e);
    }
  }
  return supabaseClient;
}

function getSupabaseClient() {
  return getSupabase();
}
window.getSupabase = getSupabase;
window.getSupabaseClient = getSupabase;

// دوال التحكم بتغيير السحابة
window.setSupabaseConfig = function(url, key) {
  if (url && url.trim()) localStorage.setItem('smart_emenu_supabase_url', url.trim());
  if (key && key.trim()) localStorage.setItem('smart_emenu_supabase_anon_key', key.trim());
  location.reload();
};
window.resetSupabaseConfig = function() {
  localStorage.removeItem('smart_emenu_supabase_url');
  localStorage.removeItem('smart_emenu_supabase_anon_key');
  location.reload();
};

// الاستماع لأي تغيير في إعدادات السحابة لتحديث الصفحة فورياً
window.addEventListener('storage', (e) => {
  if (e.key === 'smart_emenu_supabase_url' || e.key === 'smart_emenu_supabase_anon_key') {
    supabaseClient = null;
    location.reload();
  }
});

// معرف المطعم الافتراضي (لدعم تعدد المطاعم والفروع)
const DEFAULT_RESTAURANT_ID = "fahma_dokhan";

function getActiveRestaurantId() {
  try {
    const params = new URLSearchParams(window.location.search);
    const qRest = params.get('rest') || params.get('restaurant');
    if (qRest && qRest.trim()) {
      const clean = qRest.trim().toLowerCase();
      if (clean === 'platform_market') {
        if (typeof window !== 'undefined' && window.location) {
          const p = window.location.pathname.toLowerCase();
          if (p.endsWith('index.html') || p === '/' || p.endsWith('/') || !p.includes('.html')) {
            if (!window._redirectingToPlatform) {
              window._redirectingToPlatform = true;
              window.location.replace('platform-menu.html');
            }
            return 'platform_market';
          }
        }
      }
      try { 
        sessionStorage.setItem('smart_emenu_restaurant_id', clean); 
        localStorage.setItem('smart_emenu_last_active_restaurant', clean);
      } catch (e) {}
      return clean;
    }
    const sRest = sessionStorage.getItem('smart_emenu_restaurant_id');
    if (sRest && sRest.trim()) {
      return sRest.trim().toLowerCase();
    }
  } catch (e) {}

  try {
    const sessStr = sessionStorage.getItem('smart_emenu_session');
    if (sessStr) {
      const sess = JSON.parse(sessStr);
      if (sess && sess.restaurantId && sess.restaurantId.trim()) {
        return sess.restaurantId.trim().toLowerCase();
      }
    }
  } catch (e) {}

  // إذا لم يُحدد مطعم في الرابط ولم توجد جلسة سابقة، التوجيه الذكي للمطعم الافتراضي
  try { sessionStorage.setItem('smart_emenu_restaurant_id','fahma_dokhan'); } catch(e) {}
  return 'fahma_dokhan';
}

function setActiveRestaurantId(id) {
  if (!id) return;
  const clean = id.trim().toLowerCase();
  try {
    sessionStorage.setItem('smart_emenu_restaurant_id', clean);
  } catch (e) {}
}

// -------------------------------------------------------------
// فحص حالة اشتراك المطعم في Supabase وقفل الموقع عند الإلغاء
// -------------------------------------------------------------
async function checkRestaurantSubscription() {
  const client = getSupabase();
  if (!client) return { active: true };

  const restId = getActiveRestaurantId();

  try {
    const { data, error } = await client
      .from('restaurants')
      .select('*')
      .eq('id', restId)
      .limit(1);

    if (!error && data && data.length > 0) {
      const rest = data[0];

      // إذا كان المطعم موقوفاً أو منتهي الاشتراك (is_active === false)
      if (rest.is_active === false) {
        showSubscriptionLockScreen(rest);
        return { active: false, restaurant: rest };
      } else {
        hideSubscriptionLockScreen();

        // مزامنة حالة الباقات ونوع الخطة في التخزين المحلي فوراً
        const localConfig = typeof getStoredData === 'function' ? getStoredData('config', {}) : {};
        if (typeof setStoredData === 'function' && localConfig) {
          const plan = rest.subscription_plan || rest.plan_type || 'pro';
          localConfig.planType = plan;
          localConfig.subscriptionPlan = plan;
          if (plan === 'basic') {
            localConfig.allowDineInOrders = false;
            localConfig.allowTakeawayOrders = false;
            localConfig.takeawayPackageActive = false;
          } else {
            localConfig.allowDineInOrders = !!rest.allow_dinein_orders;
            localConfig.allowTakeawayOrders = rest.allow_takeaway_orders !== false;
            localConfig.takeawayPackageActive = rest.takeaway_package_active !== false;
          }
          if (rest.logo !== undefined && rest.logo !== null && rest.logo.trim() !== '') {
            localConfig.logo = rest.logo.trim();
          } else if (rest.logo !== undefined) {
            localConfig.logo = 'logo.svg';
          }
          setStoredData('config', localConfig);
          if (typeof updateAppBranding === 'function') updateAppBranding();
        }

        return { active: true, restaurant: rest };
      }
    }
  } catch (e) {
    console.warn("Subscription check offline:", e);
  }

  return { active: true };
}

// -------------------------------------------------------------
// شاشة القفل وتجديد الاشتراك والتواصل مع الدعم 07702265652
// -------------------------------------------------------------
function showSubscriptionLockScreen(rest) {
  let overlay = document.getElementById('subscription-locked-overlay');
  const supportPhone = rest?.support_phone || '07702265652';

  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'subscription-locked-overlay';
    overlay.className = 'fixed inset-0 z-[999999] bg-[#0b1120] flex items-center justify-center p-4 text-center overflow-y-auto';
    overlay.innerHTML = `
      <div class="max-w-md w-full bg-slate-900 border-2 border-rose-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5 my-auto">
        
        <!-- لوجو مكتب emattec -->
        <div class="w-24 h-24 rounded-3xl bg-white p-2 mx-auto shadow-2xl border-2 border-rose-500/30 flex items-center justify-center overflow-hidden">
          <img src="emattec-logo.jpg" alt="emattec" class="w-full h-full object-contain" onerror="this.src='logo.svg'" />
        </div>

        <div class="space-y-2">
          <div class="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-500/20 text-rose-400 text-xs font-black rounded-full border border-rose-500/30">
            <span class="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            <span>الاشتراك غير مفعّل / منتهي</span>
          </div>
          <h2 class="text-2xl font-black text-white">يرجى تجديد الاشتراك</h2>
          <p class="text-xs text-slate-300 leading-relaxed">
            عزيزي صاحب المطعم، لقد تم إيقاف الخدمة مؤقتاً لتجديد الاشتراك أو ترقية الباقات. يرجى التواصل مع مكتب <b>emattec</b> لإعادة التفعيل الفوري.
          </p>
        </div>

        <!-- بطاقة رقم الدعم والتجديد -->
        <div class="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1.5">
          <div class="text-xs text-slate-400 font-bold">رقم الدعم الفني وتجديد الباقات:</div>
          <div class="text-2xl font-black text-rose-400 font-mono tracking-wider">${supportPhone}</div>
          <div class="text-[11px] text-slate-500">مكتب emattec للحلول البرمجية والأنظمة الذكية</div>
        </div>

        <!-- أزرار التواصل والتجديد -->
        <div class="space-y-2 pt-1">
          <a href="tel:${supportPhone}" class="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-600/30 transition flex items-center justify-center gap-2 active:scale-95">
            <span>📞 اتصال فوري لتجديد الاشتراك</span>
          </a>
          <a href="https://wa.me/964${supportPhone.replace(/^0+/, '')}" target="_blank" class="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition">
            <span>💬 تواصل عبر WhatsApp للتفعيل</span>
          </a>
        </div>

        <div class="text-[11px] text-slate-500 pt-3 border-t border-slate-800">
          تطوير وبرمجة <b>مكتب emattec</b> للأنظمة والحلول السحابية
        </div>

      </div>
    `;
    document.body.appendChild(overlay);
  }

  overlay.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function hideSubscriptionLockScreen() {
  const overlay = document.getElementById('subscription-locked-overlay');
  if (overlay) {
    overlay.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// -------------------------------------------------------------
// قسم / نافذة التعريف بمكتب emattec (About Emattec)
// -------------------------------------------------------------
function openAboutEmattecModal() {
  let modal = document.getElementById('about-emattec-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'about-emattec-modal';
    modal.className = 'fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4';
    modal.innerHTML = `
      <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-5 text-center relative">
        
        <button onclick="closeAboutEmattecModal()" class="absolute left-4 top-4 w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center font-bold">
          ✕
        </button>

        <!-- لوجو مكتب emattec -->
        <div class="w-24 h-24 rounded-3xl bg-white p-2.5 mx-auto shadow-2xl border border-slate-700 flex items-center justify-center overflow-hidden">
          <img src="emattec-logo.jpg" alt="لوجو مكتب emattec" class="w-full h-full object-contain" />
        </div>

        <div class="space-y-1.5">
          <div class="inline-block px-3 py-1 bg-rose-600/10 text-rose-400 text-xs font-black rounded-full border border-rose-500/30">
            الحلول البرمجية والأنظمة الذكية
          </div>
          <h3 class="text-2xl font-black text-white">مكتب emattec</h3>
          <p class="text-xs text-slate-300 leading-relaxed px-2">
            متخصصون في برمجة وتطوير أنظمة المطاعم، المنيو الرقمي التفاعلي، تطبيقات الكاشير والطلبات، والربط السحابي مع أنظمة الخرائط والملاحة.
          </p>
        </div>

        <!-- بطاقة طلب نفس النظام -->
        <div class="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-right">
          <div class="flex items-center gap-2 text-rose-400 font-bold text-xs">
            <span>🚀</span>
            <span>هل ترغب بإنشاء نفس هذا النظام لمطعمك أو مشروعك؟</span>
          </div>
          <p class="text-[11px] text-slate-400 leading-relaxed">
            نقدم حلولاً مخصصة تناسب كافة الأنشطة التجارية مع استضافة سحابية، استوديو باركود، دعم الطباعة الحرارية، وتطبيقات متكاملة.
          </p>
        </div>

        <!-- رقم التواصل المباشر -->
        <div class="space-y-2">
          <a href="tel:07702265652" class="w-full py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-rose-600/30 transition flex items-center justify-center gap-2">
            <span>📞 اتصل الآن لطلب النظام: 07702265652</span>
          </a>
          <a href="https://wa.me/9647702265652" target="_blank" class="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition">
            <span>💬 تواصل معنا عبر واتساب</span>
          </a>
        </div>

        <div class="text-[11px] text-slate-500 pt-2 border-t border-slate-800">
          جميع الحقوق محفوظة © مكتب <b>emattec</b> 2026
        </div>

      </div>
    `;
    document.body.appendChild(modal);
  }

  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeAboutEmattecModal() {
  const modal = document.getElementById('about-emattec-modal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

function preserveRestaurantParamInLinks() {
  try {
    const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : null;
    if (!restId) return;
    const pages = ['index.html', 'admin.html', 'cashier.html', 'captain.html'];
    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.getAttribute('href');
      if (!href) return;
      const isTargetPage = pages.some(p => href === p || href.startsWith(p + '?') || href.startsWith(p + '#'));
      if (isTargetPage && !href.includes('rest=')) {
        const hashParts = href.split('#');
        const mainPart = hashParts[0];
        const hash = hashParts.length > 1 ? ('#' + hashParts[1]) : '';
        const sep = mainPart.includes('?') ? '&' : '?';
        a.setAttribute('href', `${mainPart}${sep}rest=${encodeURIComponent(restId)}${hash}`);
      }
    });
  } catch(e) {}
}

// تشغيل الفحص الدوري للاشتراك في كل الصفحات
document.addEventListener('DOMContentLoaded', () => {
  preserveRestaurantParamInLinks();
  setTimeout(() => {
    checkRestaurantSubscription();
    preserveRestaurantParamInLinks();
  }, 500);
});

/* === data.js === */
/**
 * مطعم فحمة ودخان - بيانات المنيو وإعدادات رابط النشر والباركود
 */

const DEFAULT_RESTAURANT_CONFIG = {
  name: "مطعم فحمة ودخان",
  nameEn: "Fahma & Dokhan Restaurant",
  tagline: "أشهى المشاوي والدجاج على الفحم، البركر، الساندويشات الغربية والريزو",
  taglineEn: "Delicious Charcoal Grills, Mansaf, Burgers & Western Sandwiches",
  currency: "د.ع",
  currencyEn: "IQD",
  phone: "07755009771",
  phone2: "07509009676",
  mapUrl: "https://maps.app.goo.gl/dr2x5U7NFiFKXJnQ9?g_st=com.google.maps.preview.copy",
  whatsappNumber: "07755009771",
  whatsappUrl: "https://wa.me/9647755009771",
  publishedUrl: "https://fahma-dokhan.netlify.app", 
  
  // خيارات وقفل الطلبات في المنيو (التحكم من لوحة الأدمن)
  allowDineInOrders: true,           // تفعيل الطلب الذاتي داخل الصالة
  allowTakeawayOrders: true,         // طلب السفري والتوصيل أونلاين (مفعل)
  takeawayPackageActive: true,       // باقة التوصيل السريع (مفعلة)
  planType: "pro",                   // نوع الباقة: pro

  whatsappDirectOrderEnabled: false,
  whatsappLockReason: "للتواصل والطلب المباشر أو تفعيل الخدمات، يرجى الاتصال برقم الدعم الفني: 07702265652.",
  autoPrintKitchenTicket: true,
  printerPaperSize: "80mm",
  adminPin: "",
  wifiName: "Fahma_Dokhan_WiFi",
  wifiPass: "fahma2026",
  address: "العراق - نينوى - الشيماء",
  workingHours: "10:00 صباحاً - 10:00 بعد منتصف الليل",
  holidays: "مفتوح طوال أيام الأسبوع",
  tablesCount: 20,
  taxRate: 0,
  serviceCharge: 0,
  theme: "luxury",
  lang: "ar"
};

const DEFAULT_CATEGORIES = [
  { id: "all", name: "الكل", nameEn: "All", icon: "🍽️" },
  { id: "grills", name: "المشاوي والكباب", nameEn: "Grills", icon: "🥩" },
  { id: "chicken", name: "الدجاج والمناسف", nameEn: "Chicken & Mansaf", icon: "🍗" },
  { id: "fish", name: "الأسماك والمسكوف", nameEn: "Fish & Masgouf", icon: "🐟" },
  { id: "burgers", name: "البركر", nameEn: "Burgers", icon: "🍔" },
  { id: "western", name: "الساندويشات الغربية", nameEn: "Western", icon: "🌯" },
  { id: "rizo", name: "الريزو", nameEn: "Rizo", icon: "🍚" },
  { id: "appetizers", name: "المقبلات والبطاطا", nameEn: "Appetizers", icon: "🥗" },
  { id: "drinks", name: "المشروبات", nameEn: "Drinks", icon: "🥤" }
];

const DEFAULT_DISHES = [{"id":101,"name":"نفر كباب لحم","nameEn":"Beef Kebab Plate (Full)","categoryId":"grills","price":8000,"ingredients":"لحم غنم عراقي مفروم طازج، لية، بصل، بقدونس، سماق، طماطم وفلفل مشوي، يقدم مع الخبز الحار وسرفيس الخضار.","calories":"680 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":102,"name":"نص نفر كباب لحم","nameEn":"Half Beef Kebab Plate","categoryId":"grills","price":5000,"ingredients":"نصف وجبة كباب لحم غنم مشوي على الفحم مع الطماطم المشوية والخبز الحار والسماق.","calories":"360 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":103,"name":"نفر تكة لحم","nameEn":"Beef Tikka Plate (Full)","categoryId":"grills","price":9000,"ingredients":"شقف لحم غنم هبرة طازجة، لية غنم، تتبيلة بهارات خاصة، بصل مشوي، طماطم، خبز حار.","calories":"620 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":104,"name":"نص نفر تكة لحم","nameEn":"Half Beef Tikka Plate","categoryId":"grills","price":5000,"ingredients":"قطع تكة لحم غنم متبلة ومشوية على الفحم مع الخبز الحار والخضار المشوية.","calories":"330 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":105,"name":"نفر معلاق","nameEn":"Liver (Malaq) Plate (Full)","categoryId":"grills","price":9000,"ingredients":"كبدة غنم طازجة مقطعة، شحم لية غنم، رشة سماق، ليمون، خبز حار صاج أو تنور.","calories":"530 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":106,"name":"نص نفر معلاق","nameEn":"Half Liver Plate","categoryId":"grills","price":5000,"ingredients":"نصف وجبة معلاق غنم طازج مشوي على جمر الفحم مع الليمون والخبز.","calories":"280 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":107,"name":"نفر تكة دجاج","nameEn":"Chicken Tikka Plate (Full)","categoryId":"grills","price":7000,"ingredients":"مكعبات صدور دجاج طرية، تتبيلة الزبادي والثوم والليمون والزعفران، صوص ثومية، خبز حار، طماطم مشوية.","calories":"510 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":108,"name":"نص نفر تكة دجاج","nameEn":"Half Chicken Tikka Plate","categoryId":"grills","price":4000,"ingredients":"نصف وجبة تكة دجاج مشوية على الفحم مع الثومية والخبز وسرفيس الخضار.","calories":"270 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":109,"name":"نفر كباب دجاج","nameEn":"Chicken Kebab Plate (Full)","categoryId":"grills","price":5000,"ingredients":"دجاج مفروم، بصل، كزبرة، بهارات مشاوي دجاج خاصة، طماطم مشوية، خبز حار، صوص ثوم.","calories":"470 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":110,"name":"نص نفر كباب دجاج","nameEn":"Half Chicken Kebab Plate","categoryId":"grills","price":3000,"ingredients":"نصف وجبة كباب دجاج مشوي على الفحم مع الخبز والصوص.","calories":"250 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":111,"name":"نفر مشكل","nameEn":"Mixed Grill Plate (Full)","categoryId":"grills","price":9000,"ingredients":"سيخ كباب لحم + سيخ تكة لحم + سيخ تكة دجاج + طماطم وبصل مشوي + خبز حار وسرفيس كامل.","calories":"740 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":112,"name":"نص نفر مشكل","nameEn":"Half Mixed Grill Plate","categoryId":"grills","price":5000,"ingredients":"تشكيلة من كباب اللحم وتكة الدجاج واللحم مع المرفقات والخبز.","calories":"390 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":113,"name":"عرايس على الفحم","nameEn":"Arayes Meat on Charcoal","categoryId":"grills","price":5000,"ingredients":"خبز محشو بلحم الغنم المفروم والمتبل بالبصل والبقدونس ودبس الرمان، محمص على جمر الفحم.","calories":"560 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":114,"name":"كيلو كباب لحم","nameEn":"1 KG Beef Kebab","categoryId":"grills","price":18000,"ingredients":"كيلو كامل كباب لحم غنم بلدي مشوي على الفحم، يقدم مع كمية وفيرة من الخبز الحار، البصل المشوي، الطماطم، والمخللات.","calories":"2200 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":115,"name":"كيلو كباب دجاج","nameEn":"1 KG Chicken Kebab","categoryId":"grills","price":10000,"ingredients":"كيلو كامل كباب دجاج متبل ومشوي على الفحم مع الخبز والصوصات وسرفيس الخضار.","calories":"1700 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":116,"name":"كيلو كباب مشكل","nameEn":"1 KG Mixed Kebab","categoryId":"grills","price":15000,"ingredients":"كيلو مشكل كباب لحم وكباب دجاج على الفحم مع الخبز والطرشي والطماطم المشوية.","calories":"1950 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1544025162-d76694265947?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":201,"name":"منسف دجاجة شواية","nameEn":"Whole Rotisserie Chicken Mansaf","categoryId":"chicken","price":15000,"ingredients":"دجاجة كاملة شواية محمرة، صينية تمن (أرز) زعفران ومبهر، مرق فاصوليا/بامية، حشو شعرية ومكسرات، ليمون وطرشي.","calories":"1650 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1598103442097-8b74394b95c6?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":202,"name":"منسف نص دجاجة شواية","nameEn":"Half Rotisserie Chicken Mansaf","categoryId":"chicken","price":10000,"ingredients":"نصف دجاجة شواية محمرة، صحن تمن مع الحشو، صحن مرق، سلطة وطرشي.","calories":"920 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1598103442097-8b74394b95c6?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":203,"name":"دجاجة شواية (بدون تمن)","nameEn":"Whole Rotisserie Chicken Only","categoryId":"chicken","price":9000,"ingredients":"دجاجة شواية كاملة متبلة ومحمرة على السيخ الدوار، تقدم مع الخبز، الطرشي، وصلصة الثومية.","calories":"1200 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":204,"name":"نص دجاجة شواية (بدون تمن)","nameEn":"Half Rotisserie Chicken Only","categoryId":"chicken","price":5000,"ingredients":"نصف دجاجة شواية محمرة مع الخبز الحار والمخللات والثومية.","calories":"600 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":205,"name":"منسف دجاجة على الفحم","nameEn":"Charcoal Grilled Chicken Mansaf","categoryId":"chicken","price":13000,"ingredients":"دجاجة كاملة مشوية على جمر الفحم بنكهة التدخين المميزة، تقدم على منسف تمن مبهر مع المرق والمخلل والخبز.","calories":"1550 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":206,"name":"منسف نص دجاجة على الفحم","nameEn":"Charcoal Half Chicken Mansaf","categoryId":"chicken","price":10000,"ingredients":"نصف دجاجة مشوية على الفحم، تمن مبهر، مرق، سلطة ومخلل.","calories":"880 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":207,"name":"دجاجة على الفحم (بدون تمن)","nameEn":"Whole Charcoal Grilled Chicken","categoryId":"chicken","price":8000,"ingredients":"دجاجة كاملة متبلة بالليمون والبهارات ومشوية على الفحم مع الخبز وصلصة الثوم والطرشي.","calories":"1150 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":208,"name":"نص دجاجة على الفحم (بدون تمن)","nameEn":"Half Charcoal Grilled Chicken","categoryId":"chicken","price":5000,"ingredients":"نصف دجاجة مشوية على الفحم مع الخبز والصلصة.","calories":"580 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":209,"name":"نفر أجنحة دجاج على تمن","nameEn":"Wings with Rice (Full Plate)","categoryId":"chicken","price":9000,"ingredients":"أجنحة دجاج متبلة ومشوية على الفحم، تقدم على وجبة تمن مع المرق وسرفيس الخضار.","calories":"820 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":210,"name":"نص نفر أجنحة دجاج على تمن","nameEn":"Half Wings with Rice Plate","categoryId":"chicken","price":5000,"ingredients":"نصف وجبة أجنحة دجاج مشوية على الفحم مع التمن والمرق.","calories":"460 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":211,"name":"نفر أجنحة دجاج مشوية","nameEn":"Grilled Wings Plate Only","categoryId":"chicken","price":7000,"ingredients":"أجنحة دجاج مقرمشة مشوية على الفحم مع الخبز والصلصات الحارة والعادية.","calories":"580 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":212,"name":"نص نفر أجنحة دجاج مشوية","nameEn":"Half Grilled Wings Plate Only","categoryId":"chicken","price":4000,"ingredients":"نصف وجبة أجنحة دجاج مشوية على الفحم مع الخبز.","calories":"310 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":301,"name":"بركر لحم عادي","nameEn":"Single Beef Burger","categoryId":"burgers","price":1500,"ingredients":"شريحة لحم مشوية، خس طازج، طماطم، مخلل خيار، صوص بركر خاص، خبز سمسم طري.","calories":"410 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":302,"name":"بركر لحم دبل","nameEn":"Double Beef Burger","categoryId":"burgers","price":2500,"ingredients":"شريحتين لحم بقري مشوي، خس، طماطم، مخلل، صوص الشيف المميز في خبز برجر كبير.","calories":"640 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":303,"name":"بركر لحم بالجبن عادي","nameEn":"Single Cheeseburger","categoryId":"burgers","price":1750,"ingredients":"شريحة لحم مشوية، شريحة جبنة شيدر أمريكية ذائبة، خس، طماطم، صوص بركر، خبز سمسم.","calories":"470 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":304,"name":"بركر لحم بالجبن دبل","nameEn":"Double Cheeseburger","categoryId":"burgers","price":3000,"ingredients":"شريحتين لحم مشوي، طبقتين جبنة شيدر ذائبة، خس، مخلل، صوصات غنية، خبز محمص.","calories":"770 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":305,"name":"بركر اومليت عادي","nameEn":"Single Omelette Burger","categoryId":"burgers","price":2000,"ingredients":"شريحة لحم برجر، قرص بيض أومليت ذهبي مطهو بالزبدة، جبنة شيدر، خس، صوص المايونيز والكاتشب.","calories":"530 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":306,"name":"بركر اومليت دبل","nameEn":"Double Omelette Burger","categoryId":"burgers","price":3000,"ingredients":"شريحتين لحم + قرص بيض أومليت + جبنة شيدر ذائبة + خضار وصوص.","calories":"810 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":307,"name":"بركر فطر عادي","nameEn":"Single Mushroom Burger","categoryId":"burgers","price":2000,"ingredients":"شريحة لحم مشوية، فطر (مشروم) طازج مشوح، صلصة الفطر الكريمية الغنية، جبنة، خس.","calories":"520 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":308,"name":"بركر فطر دبل","nameEn":"Double Mushroom Burger","categoryId":"burgers","price":3000,"ingredients":"شريحتين لحم مشوي مع كمية مضاعفة من صلصة المشروم الكريمية وحبات الفطر والجبنة.","calories":"780 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":401,"name":"زنجر عادي","nameEn":"Zinger Chicken Sandwich","categoryId":"western","price":1500,"ingredients":"قطعة صدر دجاج زنجر مقرمشة حارة، خس كابوتشا طازج، مايونيز، خبز صمون فرنسي طري.","calories":"470 سعرة","isPopular":true,"isSpicy":true,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":402,"name":"زنجر بالجبن","nameEn":"Zinger with Cheese","categoryId":"western","price":1750,"ingredients":"صدر دجاج زنجر سبايسي حار، شريحة جبنة شيدر ذائبة، خس، صوص زنجر خاص.","calories":"530 سعرة","isPopular":true,"isSpicy":true,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":403,"name":"زنجر هوني ماسترد","nameEn":"Zinger Honey Mustard","categoryId":"western","price":2000,"ingredients":"دجاج زنجر مقرمش، صلصة الهوني ماسترد (الخردل بالعسل الطبيعي)، جبنة، خس.","calories":"550 سعرة","isPopular":true,"isSpicy":true,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":404,"name":"كريسبي عادي","nameEn":"Crispy Chicken Sandwich","categoryId":"western","price":1500,"ingredients":"صدر دجاج مقرمش ذهبي غير حار، خس، مايونيز، خبز صمون سمسم.","calories":"450 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":405,"name":"كريسبي بالجبن","nameEn":"Crispy with Cheese","categoryId":"western","price":1750,"ingredients":"دجاج كريسبي مقرمش غير حار مع شريحة جبنة شيدر وخس وصوص.","calories":"510 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":406,"name":"كريسبي هوني ماسترد","nameEn":"Crispy Honey Mustard","categoryId":"western","price":2000,"ingredients":"دجاج كريسبي مع صلصة الهوني ماسترد الغنية الحلوة والشهية وجبنة.","calories":"540 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":407,"name":"فاهيتا دجاج","nameEn":"Chicken Fajita Sandwich","categoryId":"western","price":1500,"ingredients":"شرائح صدور دجاج طرية، فلفل أخضر وأحمر وأصفر، بصل مكرمل، بهارات فاهيتا، صوص مايونيز بالثوم.","calories":"430 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":408,"name":"مكسيكانو دجاج حار","nameEn":"Spicy Mexicano Chicken","categoryId":"western","price":1500,"ingredients":"دجاج مطهو بصلصة المكسيكانو الحارة مع الفلفل الهالبينو، ذرة، بصل، صلصة طماطم حارة.","calories":"440 سعرة","isPopular":true,"isSpicy":true,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":409,"name":"تويستر","nameEn":"Chicken Twister Wrap","categoryId":"western","price":1500,"ingredients":"أصابع دجاج مقرمشة، خس طازج، طماطم، صوص فلفل أو مايونيز، ملفوفة في خبز تورتيلا محمص.","calories":"420 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":410,"name":"سكالوب دجاج","nameEn":"Chicken Escalope Sandwich","categoryId":"western","price":1500,"ingredients":"شريحة سكالوب دجاج بانيه مقلية ذهبية، خس، مخلل، مايونيز، كاتشب.","calories":"460 سعرة","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1608797178974-15b35a61ded7?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":411,"name":"جيكن ساب (تشيكن سب)","nameEn":"Chicken Sub Sandwich","categoryId":"western","price":2000,"ingredients":"ساندويتش صب كبير، دجاج متبل، جبنة موزاريلا وشيدر ذائبة، خضار مشكلة، صوصات غنية.","calories":"590 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":412,"name":"فنكر عادي (بطاطا مقلية)","nameEn":"Crispy French Fries","categoryId":"western","price":1000,"ingredients":"أصابع بطاطا مقلية ذهبية مقرمشة مع بهارات الفنكر وكاتشب.","calories":"320 سعرة","isPopular":false,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":413,"name":"فنكر بالجبن","nameEn":"Loaded Cheddar Cheese Fries","categoryId":"western","price":1500,"ingredients":"أصابع بطاطا مقلية ساخنة مغطاة بصلصة جبنة الشيدر الذائبة الكريمية.","calories":"490 سعرة","isPopular":true,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":501,"name":"ريزو عادي","nameEn":"Classic Chicken Rizo","categoryId":"rizo","price":4000,"ingredients":"أرز ريزو مبهر أصفر، قطع دجاج كرسبي مقرمشة مقطعة، صوص الريزو الخاص الحامض والحلو.","calories":"630 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":502,"name":"ريزو بالجبن","nameEn":"Cheese Chicken Rizo","categoryId":"rizo","price":4500,"ingredients":"أرز ريزو مبهر، قطع دجاج مقرمش، صوص جبنة شيدر غني وساخن، صوص ريزو.","calories":"750 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":503,"name":"ريزو باربيكو","nameEn":"BBQ Chicken Rizo","categoryId":"rizo","price":4500,"ingredients":"أرز ريزو، قطع دجاج مقرمشة، صلصة باربيكيو مدخنة، صوص ريزو خاص.","calories":"690 سعرة","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":601,"name":"مقبلات مشكلة - حجم كبير","nameEn":"Large Mixed Appetizers Platter","categoryId":"appetizers","price":3000,"ingredients":"تشكيلة مقبلات شرقية منوعة (حمص بطحينة، متبل باذنجان، بابا غنوج، جاجيك بالخيار والنعناع، لهانة حمراء، وسلطة زيتون).","calories":"460 سعرة","isPopular":true,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":602,"name":"مقبلات مشكلة - حجم وسط","nameEn":"Medium Mixed Appetizers","categoryId":"appetizers","price":2000,"ingredients":"صحن مقبلات وسط مشكل (حمص، متبل، جاجيك، سلطة لهانة).","calories":"310 سعرة","isPopular":false,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":603,"name":"مقبلات مشكلة - حجم صغير","nameEn":"Small Mixed Appetizers","categoryId":"appetizers","price":1000,"ingredients":"صحن مقبلات فردي صغير مشكل طازج.","calories":"190 سعرة","isPopular":false,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":701,"name":"ببسي","nameEn":"Pepsi Can (330ml)","categoryId":"drinks","price":500,"ingredients":"مشروب غازي ببسي مثلج في كان معدني.","calories":"140 سعرة","isPopular":true,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":702,"name":"سفن أب","nameEn":"7-Up Can (330ml)","categoryId":"drinks","price":500,"ingredients":"مشروب غازي سفن أب مثلج بنكهة الليمون واللايم المنعشة.","calories":"140 سعرة","isPopular":true,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":703,"name":"ميراندا برتقال","nameEn":"Mirinda Orange Can","categoryId":"drinks","price":500,"ingredients":"مشروب غازي ميراندا برتقال بارد ومنعش.","calories":"150 سعرة","isPopular":false,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":704,"name":"شنينة (لبن عيران)","nameEn":"Fresh Ayran Shanina","categoryId":"drinks","price":500,"ingredients":"لبن عيران طبيعي بارد مع رشة نعناع وملح خفيف.","calories":"90 سعرة","isPopular":true,"isSpicy":false,"isVeg":true,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1584947914532-26113214578f?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_masgouf","name":"\u0633\u0645\u0643 \u0645\u0633\u0643\u0648\u0641 \u0639\u0631\u0627\u0642\u064a (\u0628\u0627\u0644\u0648\u0632\u0646)","nameEn":"Iraqi Masgouf Fish (By Weight)","categoryId":"fish","price":10000,"unitPrice":10000,"isWeighted":true,"ingredients":"\u0633\u0645\u0643 \u0643\u0627\u0631\u0628 \u0639\u0631\u0627\u0642\u064a \u062d\u064a \u0637\u0627\u0632\u062c \u064a\u0648\u0632\u0646 \u0648\u064a\u0634\u0648\u0649 \u0639\u0644\u0649 \u0627\u0644\u062d\u0637\u0628\u060c \u064a\u062d\u0633\u0628 \u0627\u0644\u0633\u0639\u0631 \u0648\u0641\u0642 \u0627\u0644\u0648\u0632\u0646 \u0627\u0644\u0641\u0639\u0644\u064a (10,000 \u062f.\u0639 \u0643\u063a\u0645) \u0645\u0639 \u0627\u0644\u062e\u0628\u0632 \u0627\u0644\u062d\u0627\u0631 \u0648\u0627\u0644\u0637\u0631\u0634\u064a \u0648\u0627\u0644\u0644\u064a\u0645\u0648\u0646 \u0648\u0627\u0644\u0639\u0645\u0628\u0629 \u0648\u0633\u064a\u0631\u0641\u064a\u0633 \u0627\u0644\u062e\u0636\u0627\u0631.","calories":"450 \u0633\u0639\u0631\u0629 / \u062d\u0635\u0629","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_bunni","name":"\u0633\u0645\u0643 \u0628\u0646\u064a \u062f\u062c\u0644\u0627\u0648\u064a \u0645\u0633\u0643\u0648\u0641","nameEn":"Masgouf Bunni Fish (By Weight)","categoryId":"fish","price":12000,"unitPrice":12000,"isWeighted":true,"ingredients":"\u0633\u0645\u0643 \u0628\u0646\u064a \u0639\u0631\u0627\u0642\u064a \u062f\u062c\u0644\u0627\u0648\u064a \u0637\u0627\u0632\u062c \u0645\u0634\u0648\u064a \u0639\u0644\u0649 \u0627\u0644\u062d\u0637\u0628 \u0628\u0646\u0643\u0647\u0629 \u0639\u0631\u0627\u0642\u064a\u0629 \u0623\u0635\u064a\u0644\u0629\u060c \u064a\u0642\u062f\u0645 \u0645\u0639 \u0627\u0644\u062e\u0628\u0632 \u0627\u0644\u062d\u0627\u0631 \u0648\u0627\u0644\u0645\u062e\u0644\u0644\u0627\u062a \u0648\u0627\u0644\u0644\u064a\u0645\u0648\u0646.","calories":"420 \u0633\u0639\u0631\u0629 / \u062d\u0635\u0629","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_gattan","name":"\u0633\u0645\u0643 \u0643\u0637\u0627\u0646 \u0645\u0633\u0643\u0648\u0641 \u0641\u0627\u062e\u0631","nameEn":"Masgouf Gattan Fish (By Weight)","categoryId":"fish","price":14000,"unitPrice":14000,"isWeighted":true,"ingredients":"\u0633\u0645\u0643 \u0643\u0637\u0627\u0646 \u0639\u0631\u0627\u0642\u064a \u0646\u0647\u0631\u064a \u0645\u0634\u0648\u064a \u0639\u0644\u0649 \u062c\u0645\u0631 \u0627\u0644\u062e\u0634\u0628 \u0645\u0639 \u062e\u0644\u0637\u0629 \u0627\u0644\u0634\u064a\u0641 \u0648\u0633\u064a\u0631\u0641\u064a\u0633 \u0643\u0627\u0645\u0644.","calories":"480 \u0633\u0639\u0631\u0629 / \u062d\u0635\u0629","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_shibbot","name":"\u0633\u0645\u0643 \u0634\u0628\u0648\u0637 \u0639\u0631\u0627\u0642\u064a (\u0628\u0627\u0644\u0648\u0632\u0646)","nameEn":"Iraqi Shibbot Fish (By Weight)","categoryId":"fish","price":11000,"unitPrice":11000,"isWeighted":true,"ingredients":"\u0633\u0645\u0643 \u0634\u0628\u0648\u0637 \u0639\u0631\u0627\u0642\u064a \u0646\u0647\u0631\u064a \u0637\u0627\u0632\u062c \u0645\u0634\u0648\u064a \u0639\u0644\u0649 \u0627\u0644\u062d\u0637\u0628 \u0623\u0648 \u0645\u0642\u0644\u064a \u062d\u0633\u0628 \u0627\u0644\u0637\u0644\u0628\u060c \u064a\u062d\u0633\u0628 \u0627\u0644\u0633\u0639\u0631 \u0628\u0627\u0644\u0648\u0632\u0646 \u0627\u0644\u0641\u0639\u0644\u064a \u0648\u064a\u0642\u062f\u0645 \u0645\u0639 \u0627\u0644\u062e\u0628\u0632 \u0627\u0644\u062d\u0627\u0631 \u0648\u0627\u0644\u0645\u062e\u0644\u0644\u0627\u062a \u0648\u0627\u0644\u0639\u0645\u0628\u0629.","calories":"460 \u0633\u0639\u0631\u0629 / \u062d\u0635\u0629","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_fried","name":"\u0633\u0645\u0643 \u0645\u0642\u0644\u064a \u0639\u0631\u0627\u0642\u064a \u0645\u0642\u0631\u0645\u0634 (\u0628\u0627\u0644\u0648\u0632\u0646)","nameEn":"Crispy Fried Fish (By Weight)","categoryId":"fish","price":10000,"unitPrice":10000,"isWeighted":true,"ingredients":"\u0642\u0637\u0639 \u0633\u0645\u0643 \u0637\u0627\u0632\u062c\u0629 \u0645\u0642\u0644\u064a\u0629 \u0630\u0647\u0628\u064a\u0629 \u0645\u0642\u0631\u0645\u0634\u0629 \u0648\u0645\u062a\u0628\u0644\u0629 \u0628\u0627\u0644\u0628\u0647\u0627\u0631\u0627\u062a \u0627\u0644\u0639\u0631\u0627\u0642\u064a\u0629 \u0645\u0639 \u0627\u0644\u0637\u0645\u0627\u0637\u0645 \u0648\u0627\u0644\u062e\u064a\u0627\u0631 \u0648\u0627\u0644\u0645\u062e\u0644\u0644\u0627\u062a \u0648\u0627\u0644\u0639\u0645\u0628\u0629 \u0648\u0627\u0644\u062e\u0628\u0632 \u0627\u0644\u062d\u0627\u0631.","calories":"520 \u0633\u0639\u0631\u0629 / \u062d\u0635\u0629","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1526470608268-f674ce90ebd4?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_shrimp_kg","name":"\u062c\u0645\u0628\u0631\u064a \u0645\u0642\u0644\u064a (\u0628\u0627\u0644\u0648\u0632\u0646)","nameEn":"Fried Shrimp (By Weight)","categoryId":"fish","price":15000,"unitPrice":15000,"isWeighted":true,"ingredients":"\u062c\u0645\u0628\u0631\u064a \u0637\u0627\u0632\u062c \u0643\u0628\u064a\u0631 \u0627\u0644\u062d\u062c\u0645 \u0645\u0642\u0644\u064a \u0628\u0627\u0644\u0632\u0628\u062f\u0629 \u0648\u0627\u0644\u062b\u0648\u0645 \u0648\u0627\u0644\u0644\u064a\u0645\u0648\u0646 \u0648\u0645\u062a\u0628\u0644 \u0628\u0627\u0644\u0628\u0647\u0627\u0631\u0627\u062a\u060c \u064a\u062d\u0633\u0628 \u0627\u0644\u0633\u0639\u0631 \u0628\u0627\u0644\u0648\u0632\u0646 \u0648\u064a\u0642\u062f\u0645 \u0645\u0639 \u0627\u0644\u062e\u0628\u0632 \u0648\u0627\u0644\u0635\u0644\u0635\u0627\u062a.","calories":"380 \u0633\u0639\u0631\u0629 / \u062d\u0635\u0629","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1565680018434-b75b2e2a78e4?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_shrimp_portion","name":"\u062d\u0635\u0629 \u062c\u0645\u0628\u0631\u064a \u0645\u0642\u0644\u064a","nameEn":"Fried Shrimp Portion","categoryId":"fish","price":8000,"isWeighted":false,"ingredients":"\u062d\u0635\u0629 \u0641\u0631\u062f\u064a\u0629 \u0645\u0646 \u0627\u0644\u062c\u0645\u0628\u0631\u064a \u0627\u0644\u0643\u0628\u064a\u0631 \u0627\u0644\u0645\u0642\u0644\u064a \u0628\u0627\u0644\u0632\u0628\u062f\u0629 \u0648\u0627\u0644\u062b\u0648\u0645 \u0648\u0627\u0644\u0644\u064a\u0645\u0648\u0646\u060c \u062a\u0642\u062f\u0645 \u0645\u0639 \u0635\u0644\u0635\u0629 \u0627\u0644\u062b\u0648\u0645 \u0648\u0627\u0644\u062e\u0628\u0632 \u0627\u0644\u062d\u0627\u0631.","calories":"320 \u0633\u0639\u0631\u0629","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1565680018434-b75b2e2a78e4?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_fillet","name":"\u0641\u064a\u0644\u064a\u0647 \u0633\u0645\u0643 \u0645\u0642\u0644\u064a","nameEn":"Crispy Fish Fillet","categoryId":"fish","price":6000,"isWeighted":false,"ingredients":"\u0641\u064a\u0644\u064a\u0647 \u0633\u0645\u0643 \u0637\u0627\u0632\u062c \u0628\u0627\u0646\u064a\u0647 \u0645\u0642\u0644\u064a \u0630\u0647\u0628\u064a \u0645\u0642\u0631\u0645\u0634 \u0645\u0639 \u0635\u0644\u0635\u0629 \u0627\u0644\u0637\u0631\u0637\u0627\u0631 \u0648\u0627\u0644\u0644\u064a\u0645\u0648\u0646 \u0648\u0627\u0644\u062e\u0628\u0632 \u0627\u0644\u062d\u0627\u0631.","calories":"490 \u0633\u0639\u0631\u0629","isPopular":false,"isSpicy":false,"isVeg":false,"isNew":false,"available":true,"image":"https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format\u0026fit=crop\u0026w=600\u0026q=80"},{"id":"fd_fish_calamari","name":"\u0643\u0627\u0644\u064a\u0645\u0627\u0631\u064a \u0645\u0642\u0644\u064a","nameEn":"Fried Calamari","categoryId":"fish","price":7000,"isWeighted":false,"ingredients":"\u062d\u0644\u0642\u0627\u062a \u0643\u0627\u0644\u064a\u0645\u0627\u0631\u064a \u0637\u0627\u0632\u062c\u0629 \u0628\u0627\u0646\u064a\u0647 \u0645\u0642\u0644\u064a\u0629 \u0630\u0647\u0628\u064a\u0629 \u0645\u0642\u0631\u0645\u0634\u0629 \u0645\u0639 \u0635\u0644\u0635\u0629 \u0627\u0644\u0637\u0631\u0637\u0627\u0631 \u0648\u062f\u0642\u0629 \u0627\u0644\u0644\u064a\u0645\u0648\u0646 \u0627\u0644\u062d\u0627\u0645\u0636.","calories":"410 \u0633\u0639\u0631\u0629","isPopular":true,"isSpicy":false,"isVeg":false,"isNew":true,"available":true,"image":"https://images.unsplash.com/photo-1615361200141-f45040f367be?auto=format\u0026fit=crop\u0026w=600\u0026q=80"}];

function getDefaultRestaurantConfig(restId) {
  if (restId === 'banan') {
    return {
      name: "مطعم بنان",
      nameEn: "Banan Restaurant",
      tagline: "أشهى المأكولات والمشروبات بنكهة مميزة",
      taglineEn: "Delicious Food & Drinks",
      currency: "د.ع",
      currencyEn: "IQD",
      phone: "+9647700000000",
      phone2: "",
      mapUrl: "",
      whatsappNumber: "+9647700000000",
      publishedUrl: "",
      allowDineInOrders: true,
      allowTakeawayOrders: true,
      takeawayPackageActive: true,
      planType: "pro",
      whatsappDirectOrderEnabled: false,
      whatsappLockReason: "للتواصل والطلب المباشر أو تفعيل الخدمات، يرجى الاتصال برقم الدعم الفني: 07702265652.",
      autoPrintKitchenTicket: true,
      printerPaperSize: "80mm",
      adminPin: "",
      wifiName: "Banan_WiFi",
      wifiPass: "banan2026",
      address: "العراق",
      workingHours: "10:00 صباحاً - 12:00 منتصف الليل",
      holidays: "مفتوح طوال أيام الأسبوع",
      tablesCount: 20,
      taxRate: 0,
      serviceCharge: 0,
      theme: "luxury",
      lang: "ar",
      logo: "banan-logo.jpg"
    };
  }
  if (restId === 'haidouri') {
    return {
      name: "لحم بعجين حيدوري",
      nameEn: "Haidouri Lahm Bi Ajeen",
      tagline: "أشهى لحم بعجين وصفيحة بالفرن الحجري والعصائر الطبيعية",
      taglineEn: "Delicious Fresh Lahm Bi Ajeen & Meat Pies",
      currency: "د.ع",
      currencyEn: "IQD",
      phone: "+9647700000000",
      phone2: "",
      mapUrl: "",
      whatsappNumber: "+9647700000000",
      publishedUrl: "",
      allowDineInOrders: true,
      allowTakeawayOrders: true,
      takeawayPackageActive: true,
      planType: "pro",
      whatsappDirectOrderEnabled: false,
      whatsappLockReason: "للتواصل والطلب المباشر أو تفعيل الخدمات، يرجى الاتصال برقم الدعم الفني: 07702265652.",
      autoPrintKitchenTicket: true,
      printerPaperSize: "80mm",
      adminPin: "",
      wifiName: "Haidouri_WiFi",
      wifiPass: "haidouri2026",
      address: "العراق - نينوى",
      workingHours: "08:00 صباحاً - 11:00 مساءً",
      holidays: "مفتوح طوال أيام الأسبوع",
      tablesCount: 15,
      taxRate: 0,
      serviceCharge: 0,
      theme: "luxury",
      lang: "ar",
      logo: "logo.svg"
    };
  }
  if (restId === 'fahma_dokhan') {
    return typeof DEFAULT_RESTAURANT_CONFIG !== 'undefined' ? DEFAULT_RESTAURANT_CONFIG : {};
  }
  return {
    name: "المنيو الرقمي الذكي",
    nameEn: "Smart E-Menu",
    tagline: "جاري تحميل تفاصيل المنيو...",
    taglineEn: "Loading menu details...",
    currency: "د.ع",
    currencyEn: "IQD",
    phone: "",
    phone2: "",
    mapUrl: "",
    whatsappNumber: "",
    publishedUrl: "",
    allowDineInOrders: true,
    allowTakeawayOrders: true,
    takeawayPackageActive: true,
    planType: "basic",
    whatsappDirectOrderEnabled: false,
    autoPrintKitchenTicket: true,
    printerPaperSize: "80mm",
    adminPin: "",
    wifiName: "",
    wifiPass: "",
    address: "",
    workingHours: "10:00 صباحاً - 11:00 مساءً",
    holidays: "مفتوح طوال أيام الأسبوع",
    tablesCount: 20,
    taxRate: 0,
    serviceCharge: 0,
    theme: "luxury",
    lang: "ar",
    logo: "logo.svg"
  };
}

// استرجاع أو حفظ البيانات في LocalStorage مع عزل كامل لكل مطعم (Multi-Tenant Scoped Storage)
function getScopedStorageKey(key) {
  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : (typeof DEFAULT_RESTAURANT_ID !== 'undefined' ? DEFAULT_RESTAURANT_ID : 'fahma_dokhan');
  const globalKeys = [
    'supabase_url',
    'supabase_anon_key',
    'master_pin',
    'super_assistants',
    'master_auth'
  ];
  if (globalKeys.includes(key)) {
    return 'smart_emenu_' + key;
  }
  return 'smart_emenu_' + restId + '_' + key;
}

function getStoredData(key, fallback) {
  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : (typeof DEFAULT_RESTAURANT_ID !== 'undefined' ? DEFAULT_RESTAURANT_ID : 'fahma_dokhan');
  try {
    const scopedKey = getScopedStorageKey(key);
    let item = localStorage.getItem(scopedKey);
    // ترحيل البيانات القديمة حصراً لمطعم فحمة ودخان إن لم تكن موجودة بالمفتاح الجديد
    if (item === null || item === undefined) {
      if (restId === 'fahma_dokhan') {
        item = localStorage.getItem('smart_emenu_' + key);
      }
    }
    if (item !== null && item !== undefined) {
      const parsed = JSON.parse(item);
      if (parsed !== null && parsed !== undefined) {
        if (key === 'dishes' && Array.isArray(parsed) && parsed.some(d => d.id >= 802 && d.id <= 836)) {
          const cleaned = parsed.filter(d => !(d.id >= 801 && d.id <= 836));
          const defaultFish = (typeof DEFAULT_DISHES !== 'undefined') ? DEFAULT_DISHES.filter(d => d.categoryId === 'fish') : [];
          const merged = [...cleaned, ...defaultFish];
          try { localStorage.setItem(scopedKey, JSON.stringify(merged)); } catch(e){}
          return merged;
        }
        if (key === 'dishes' && Array.isArray(parsed) && parsed.length === 0) {
          return (fallback && fallback.length > 0) ? fallback : DEFAULT_DISHES;
        }
        return parsed;
      }
    }
  } catch (e) {
    console.error("Storage error:", e);
  }

  // إذا لم توجد بيانات، تخصيص القيمة الافتراضية المناسبة لكل مطعم
  if (key === 'config') {
    return getDefaultRestaurantConfig(restId);
  }
  if (key === 'dishes') {
    return (fallback !== undefined && fallback !== null) ? fallback : DEFAULT_DISHES;
  }
  if (key === 'categories') {
    return (fallback !== undefined && fallback !== null) ? fallback : DEFAULT_CATEGORIES;
  }
  return fallback;
}

function setStoredData(key, data) {
  try {
    const scopedKey = getScopedStorageKey(key);
    localStorage.setItem(scopedKey, JSON.stringify(data));
  } catch (e) {
    console.error("Storage save error:", e);
  }
}

// -------------------------------------------------------------
// دالة التعرف الذكي التلقائي على أطباق الأسماك والأصناف المباعة بالوزن/الكيلوغرام
// -------------------------------------------------------------
function isDishWeighted(dish) {
  if (!dish) return false;
  if (dish.isWeighted === true || dish.pricingType === 'per_kg') return true;
  const cat = (dish.categoryId || dish.category || dish.category_id || '').toLowerCase();
  if (cat === 'fish' || cat === 'cat_fish' || cat.includes('fish')) return true;
  const t = ((dish.name || '') + ' ' + (dish.description || '') + ' ' + (dish.ingredients || '')).toLowerCase();
  return /سمك|مسكوف|سبريم|كطان|شبوط|بني|سلمون|سالمون|زبيدي|هامور|وزن|يوزن|بالكيلو|كيلوغرام|كغم/i.test(t);
}
window.isDishWeighted = isDishWeighted;

function migrateFishDishesToWeighted() {
  try {
    const dishes = getStoredData('dishes', DEFAULT_DISHES);
    let changed = false;
    dishes.forEach(d => {
      if (isDishWeighted(d)) {
        if (d.isWeighted !== true || d.pricingType !== 'per_kg') {
          d.isWeighted = true;
          d.pricingType = 'per_kg';
          d.unitPrice = Number(d.price) || Number(d.unitPrice) || 0;
          d.pricePerKg = d.unitPrice;
          changed = true;
        }
      }
    });
    if (changed) {
      setStoredData('dishes', dishes);
      console.log("✅ Main: All fish dishes migrated to weighted (per_kg) successfully.");
    }
  } catch (e) {
    console.warn("Fish migration notice:", e);
  }
}
window.migrateFishDishesToWeighted = migrateFishDishesToWeighted;
try { migrateFishDishesToWeighted(); } catch(e) {}

/**
 * Smart E-Menu - Supabase Cloud Authentication & User Management
 * إدارة تسجيل الدخول والمستخدمين السحابية عبر Supabase مع دعم تعدد المطاعم
 */

const DEFAULT_AUTH_CONFIG = {
  admin: {
    id: "u_admin_1",
    username: "admin",
    pin: "",
    name: "المدير العام (مطعم فحمة ودخان)",
    role: "admin",
    active: true
  },
  cashiers: [
    { id: "u_cashier_1", username: "cashier", name: "كاشير الصندوق الرئيسي", pin: "", role: "cashier", active: true }
  ],
  captains: [
    { id: "u_cap_1", username: "captain", name: "كابتن الصالة", pin: "", role: "captain", active: true }
  ]
};

// -------------------------------------------------------------
// 1. تعقيم وتنظيف المدخلات (XSS Protection)
// -------------------------------------------------------------
function sanitizeInput(str) {
  if (typeof str !== 'string') return str;
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

// -------------------------------------------------------------
// 2. نظام الحظر ضد التخمين (Brute-Force Rate Limiter)
// -------------------------------------------------------------
const ATTEMPTS_KEY = 'smart_emenu_auth_attempts';
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 3 * 60 * 1000; // 3 دقائق

function getAuthAttempts() {
  try {
    const data = localStorage.getItem(ATTEMPTS_KEY);
    return data ? JSON.parse(data) : { count: 0, lockedUntil: 0 };
  } catch (e) {
    return { count: 0, lockedUntil: 0 };
  }
}

function checkLockout() {
  const attempts = getAuthAttempts();
  const now = Date.now();
  if (attempts.lockedUntil > now) {
    const remainingSecs = Math.ceil((attempts.lockedUntil - now) / 1000);
    return {
      locked: true,
      remainingSecs,
      message: `تم حظر المحاولات مؤقتاً لحماية النظام! يرجى الانتظار (${remainingSecs} ثانية) للمحاولة مجدداً.`
    };
  }
  return { locked: false };
}

function recordFailedAttempt() {
  const attempts = getAuthAttempts();
  attempts.count = (attempts.count || 0) + 1;
  if (attempts.count >= MAX_FAILED_ATTEMPTS) {
    attempts.lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
    attempts.count = 0;
  }
  localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(attempts));
  return attempts;
}

function resetFailedAttempts() {
  localStorage.removeItem(ATTEMPTS_KEY);
}

// -------------------------------------------------------------
// 3. جلب وحفظ بيانات المستخدمين مع مطابقة سوبابيس وتطهير الذاكرة المحلية
// -------------------------------------------------------------
function getAuthConfig() {
  let data = getStoredData('auth_config', null);
  
  const isOldDummyData = data && (
    (Array.isArray(data.cashiers) && data.cashiers.some(c => c.username === 'cash' || c.pin === '20202020')) ||
    (Array.isArray(data.captains) && data.captains.some(c => ['ahmed', 'ali', 'mustafa'].includes(c.username) || ['11112222', '22223333', '33334444'].includes(c.pin)))
  );

  if (!data || isOldDummyData) {
    data = JSON.parse(JSON.stringify(DEFAULT_AUTH_CONFIG));
    setStoredData('auth_config', data);
    try {
      localStorage.setItem('smart_emenu_fahma_dokhan_auth_config', JSON.stringify(data));
      localStorage.setItem('smart_emenu_auth_config', JSON.stringify(data));
    } catch(e) {}
  }

  if (!data.cashiers || data.cashiers.length === 0) {
    data.cashiers = JSON.parse(JSON.stringify(DEFAULT_AUTH_CONFIG.cashiers));
  }
  if (!data.captains || data.captains.length === 0) {
    data.captains = JSON.parse(JSON.stringify(DEFAULT_AUTH_CONFIG.captains));
  }
  return data;
}

function saveAuthConfig(config) {
  setStoredData('auth_config', config);
  try {
    localStorage.setItem('smart_emenu_fahma_dokhan_auth_config', JSON.stringify(config));
    localStorage.setItem('smart_emenu_auth_config', JSON.stringify(config));
  } catch(e) {}
}

// جلب المستخدمين السحابيين من Supabase
async function fetchUsersFromSupabase() {
  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  if (!client) return getAuthConfig();

  try {
    const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : DEFAULT_RESTAURANT_ID;
    const { data, error } = await client
      .from('restaurant_users')
      .select('*')
      .eq('restaurant_id', restId);

    if (error || !data || data.length === 0) {
      return getAuthConfig();
    }

    const authConfig = {
      admin: { id: "u_admin_1", username: "admin", pin: "", name: "المدير العام", role: "admin", active: true },
      cashiers: [],
      captains: []
    };

    data.forEach(user => {
      const userObj = {
        id: user.id,
        username: user.username,
        pin: user.pin,
        name: user.full_name,
        role: user.role,
        active: user.active !== false
      };

      if (user.role === 'admin') {
        authConfig.admin = userObj;
      } else if (user.role === 'cashier') {
        authConfig.cashiers.push(userObj);
      } else if (user.role === 'captain') {
        authConfig.captains.push(userObj);
      }
    });

    if (authConfig.cashiers.length === 0) {
      authConfig.cashiers = DEFAULT_AUTH_CONFIG.cashiers;
    }

    saveAuthConfig(authConfig);
    return authConfig;
  } catch (e) {
    return getAuthConfig();
  }
}

function saveUserSession(session, rememberMe = true) {
  if (window.AuthCore && typeof window.AuthCore.saveSession === 'function') {
    window.AuthCore.saveSession(session, rememberMe);
  }
  const restId = (session && session.restaurantId) ? session.restaurantId.toLowerCase() : (typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan');
  try {
    const sStr = JSON.stringify(session);
    sessionStorage.setItem('smart_emenu_' + restId + '_session', sStr);
    sessionStorage.setItem('smart_emenu_session', sStr);
    sessionStorage.setItem('smart_emenu_restaurant_id', restId);
    // حفظ دائم ومستقر في localStorage لضمان عدم ضياع الجلسة عند التنقل بين الصفحات والتبويبات
    localStorage.setItem('smart_emenu_' + restId + '_session', sStr);
    localStorage.setItem('smart_emenu_session', sStr);
    localStorage.setItem('smart_emenu_restaurant_id', restId);
  } catch(e) {}
}

// -------------------------------------------------------------
// 4. تسجيل دخول الأدمن
// -------------------------------------------------------------
async function loginAdminAsync(pin, username = 'admin', rememberMe = true) {
  return loginUserAsync(username, pin, rememberMe);
}

// -------------------------------------------------------------
// 4. تسجيل دخول موحد وغير فاضح (Unified Flexible Discrete Login)
// -------------------------------------------------------------
async function loginUserAsync(username, password, rememberMe = true) {
  if (window.AuthCore && typeof window.AuthCore.loginUserAsync === 'function') {
    return await window.AuthCore.loginUserAsync(username, password, rememberMe);
  }
  if (!username || !username.trim()) {
    return { success: false, message: 'يرجى إدخال اسم المستخدم!' };
  }
  if (!password || password.trim().length < 4) {
    return { success: false, message: 'يرجى إدخال كلمة المرور (4 خانات على الأقل)!' };
  }

  const uName = username.trim().toLowerCase();
  const pwd = password.trim();

  const lockout = checkLockout();
  if (lockout.locked) return { success: false, message: lockout.message };

  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : DEFAULT_RESTAURANT_ID;

  // المصادقة السحابية الحصرية عبر سوبابيس (لا توجد أي كلمات مرور برمجية ثابتة)
  if (window.AuthCore && typeof window.AuthCore.loginUserAsync === 'function') {
    return await window.AuthCore.loginUserAsync(username, password, rememberMe);
  }

  // 2. الفحص والتحقق من سحابة Supabase الحية
  if (client) {
    try {
      let { data, error } = await client
        .from('restaurant_users')
        .select('*')
        .eq('restaurant_id', restId);

      if ((error || !data || data.length === 0) && restId !== 'fahma_dokhan') {
        const retry = await client
          .from('restaurant_users')
          .select('*')
          .eq('restaurant_id', 'fahma_dokhan');
        if (!retry.error && retry.data && retry.data.length > 0) {
          data = retry.data;
        }
      }

      if (Array.isArray(data) && data.length > 0) {
        // تحديث وتزامن الـ cache المحلي بالبيانات الحية
        const authConfig = {
          admin: { id: "u_admin_1", username: "admin", pin: "", name: "المدير العام", role: "admin", active: true },
          cashiers: [],
          captains: []
        };

        data.forEach(user => {
          const userObj = {
            id: user.id,
            username: user.username,
            pin: user.pin,
            name: user.full_name,
            role: user.role,
            active: user.active !== false
          };
          if (user.role === 'admin') authConfig.admin = userObj;
          else if (user.role === 'cashier') authConfig.cashiers.push(userObj);
          else if (user.role === 'captain') authConfig.captains.push(userObj);
        });
        saveAuthConfig(authConfig);

        // البحث عن المستخدم بمرونة
        const matched = data.find(u => 
          (u.username && u.username.toLowerCase() === uName) || 
          (u.full_name && u.full_name.toLowerCase() === uName) || 
          (u.id && u.id.toLowerCase() === uName) ||
          (uName === 'admin' && u.role === 'admin') ||
          (uName === 'مدير' && u.role === 'admin') ||
          (uName === 'المدير' && u.role === 'admin') ||
          (uName === 'cashier' && u.role === 'cashier') ||
          (uName === 'كاشير' && u.role === 'cashier') ||
          (uName === 'الكاشير' && u.role === 'cashier')
        );

        if (matched) {
          if (matched.active === false) {
            return { success: false, message: 'هذا الحساب معطل حالياً من قبل الإدارة.' };
          }

          const pinMatch = (matched.pin && matched.pin.trim() === pwd);

          if (pinMatch) {
            resetFailedAttempts();
            const roleName = (matched.username === 'super_admin' || matched.role === 'super_admin') ? 'super_admin' : matched.role;
            const session = {
              role: roleName,
              userId: matched.id,
              captainId: matched.role === 'captain' ? matched.id : null,
              name: matched.full_name,
              username: matched.username,
              restaurantId: matched.restaurant_id || restId,
              loginTime: Date.now(),
              rememberMe: true,
              token: `${matched.role ? matched.role.substring(0,3) : 'usr'}_${generateSecureToken()}`
            };
            saveUserSession(session, true);
            return { success: true, session, role: roleName, restaurantId: matched.restaurant_id || restId };
          } else {
            recordFailedAttempt();
            return { success: false, message: 'كلمة المرور غير صحيحة!' };
          }
        }
      }
    } catch (e) {
      console.warn("Supabase live auth notice:", e);
    }
  }

  // 3. الفحص المحلي الشامل
  const localConfig = getAuthConfig();
  if (localConfig.admin) {
    const adm = localConfig.admin;
    if (((adm.username && adm.username.toLowerCase() === uName) ||
         (adm.name && adm.name.toLowerCase() === uName) ||
         uName === 'admin' || uName === 'المدير' || uName === 'مدير') &&
        (adm.pin && adm.pin.trim() === pwd)) {
      resetFailedAttempts();
      const session = {
        role: 'admin',
        userId: adm.id || 'u_admin_1',
        name: adm.name || 'المدير العام',
        username: adm.username || 'admin',
        restaurantId: restId,
        loginTime: Date.now(),
        rememberMe: true,
        token: 'adm_' + generateSecureToken()
      };
      saveUserSession(session, true);
      return { success: true, session, role: 'admin', restaurantId: restId };
    }
  }

  if (localConfig.cashiers && Array.isArray(localConfig.cashiers)) {
    const csh = localConfig.cashiers.find(c => 
      ((c.username && c.username.toLowerCase() === uName) || 
       (c.name && c.name.toLowerCase() === uName) || 
       (c.id && c.id.toLowerCase() === uName) ||
       (uName === 'cashier' || uName === 'كاشير' || uName === 'الكاشير')) &&
      (c.pin && c.pin.trim() === pwd)
    );
    if (csh) {
      if (csh.active === false) return { success: false, message: 'هذا الحساب معطل حالياً.' };
      resetFailedAttempts();
      const session = {
        role: 'cashier',
        userId: csh.id || 'u_cashier_1',
        name: csh.name || 'كاشير الصندوق الرئيسي',
        username: csh.username || 'cashier',
        restaurantId: restId,
        loginTime: Date.now(),
        rememberMe: true,
        token: 'csh_' + generateSecureToken()
      };
      saveUserSession(session, true);
      return { success: true, session, role: 'cashier', restaurantId: restId };
    }
  }

  if (localConfig.captains && Array.isArray(localConfig.captains)) {
    const cap = localConfig.captains.find(c => 
      ((c.username && c.username.toLowerCase() === uName) || 
       (c.name && c.name.toLowerCase() === uName) || 
       (c.id && c.id.toLowerCase() === uName) ||
       (uName === 'captain' || uName === 'كابتن')) &&
      (c.pin && c.pin.trim() === pwd)
    );
    if (cap) {
      if (cap.active === false) return { success: false, message: 'هذا الحساب معطل حالياً.' };
      resetFailedAttempts();
      const session = {
        role: 'captain',
        userId: cap.id,
        captainId: cap.id,
        name: cap.name,
        username: cap.username || cap.name,
        restaurantId: restId,
        loginTime: Date.now(),
        rememberMe: true,
        token: 'cap_' + generateSecureToken()
      };
      saveUserSession(session, true);
      return { success: true, session, role: 'captain', restaurantId: restId };
    }
  }

  recordFailedAttempt();
  return { success: false, message: 'اسم المستخدم أو كلمة المرور غير صحيحة!' };
}

// -------------------------------------------------------------
// 5. دوال تسجيل الدخول التوافقية
// -------------------------------------------------------------
async function loginCashierAsync(pin, username = 'cashier', rememberMe = true) {
  return loginUserAsync(username, pin, rememberMe);
}

// -------------------------------------------------------------
// 6. تسجيل دخول الكابتن عبر المعرف السريع
// -------------------------------------------------------------
async function loginCaptainByIdAsync(captainId, pin, rememberMe = true) {
  const lockout = checkLockout();
  if (lockout.locked) return { success: false, message: lockout.message };

  const client = typeof getSupabase === 'function' ? getSupabase() : null;

  if (client) {
    try {
      const { data, error } = await client
        .from('restaurant_users')
        .select('*')
        .eq('id', captainId)
        .limit(1);

      if (!error && data && data.length > 0) {
        const cap = data[0];
        if (!cap.active) {
          return { success: false, message: 'هذا الحساب معطل حالياً من قبل الإدارة.' };
        }
        if (cap.pin.trim() !== pin.trim()) {
          recordFailedAttempt();
          return { success: false, message: 'رمز المرور غير صحيح!' };
        }

        resetFailedAttempts();
        const session = {
          role: 'captain',
          userId: cap.id,
          captainId: cap.id,
          name: cap.full_name,
          username: cap.username || cap.full_name,
          restaurantId: cap.restaurant_id || restId,
          loginTime: Date.now(),
          rememberMe: !!rememberMe,
          token: 'cap_' + generateSecureToken()
        };
        saveUserSession(session, rememberMe);
        return { success: true, session };
      }
    } catch (e) {}
  }

  // الفحص المحلي في حال انقطاع النت
  const localConfig = getAuthConfig();
  const captain = localConfig.captains.find(c => c.id === captainId);
  if (!captain) return { success: false, message: 'لم يتم العثور على حساب الكابتن!' };
  if (!captain.active) return { success: false, message: 'هذا الحساب معطل حالياً.' };
  if (captain.pin.trim() !== pin.trim()) {
    recordFailedAttempt();
    return { success: false, message: 'رمز المرور غير صحيح!' };
  }

  resetFailedAttempts();
  const session = {
    role: 'captain',
    userId: captain.id,
    captainId: captain.id,
    name: captain.name,
    username: captain.username || captain.name,
    restaurantId: restId,
    loginTime: Date.now(),
    rememberMe: !!rememberMe,
    token: 'cap_' + generateSecureToken()
  };
  saveUserSession(session, rememberMe);
  return { success: true, session };
}

// -------------------------------------------------------------
// 7. تغيير رمز PIN للأدمن في Supabase
// -------------------------------------------------------------
async function changeAdminPinAsync(newPin) {
  if (!newPin || newPin.trim().length < 8) {
    return { success: false, message: 'يجب أن يتكون الرمز السري الجديد من 8 أحرف أو أرقام على الأقل لتعزيز الأمان!' };
  }

  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : DEFAULT_RESTAURANT_ID;

  if (client) {
    try {
      await client
        .from('restaurant_users')
        .update({ pin: newPin.trim(), updated_at: new Date().toISOString() })
        .eq('restaurant_id', restId)
        .eq('role', 'admin');
    } catch (e) {
      console.warn("Supabase update error:", e);
    }
  }

  // تحديث محلي
  const config = getAuthConfig();
  config.admin.pin = newPin.trim();
  saveAuthConfig(config);

  const restConfig = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  restConfig.adminPin = newPin.trim();
  setStoredData('config', restConfig);

  return { success: true };
}

// -------------------------------------------------------------
// 8. إضافة وتعديل وحذف الموظفين (الكاشير والكباتن) في Supabase والمحلي
// -------------------------------------------------------------
async function addStaffUserAsync(name, username, pin, role = 'captain') {
  const cleanName = name ? name.trim() : '';
  if (!cleanName) return { success: false, message: 'يرجى إدخال اسم صحيح للموظف!' };
  if (!pin || pin.trim().length < 8) return { success: false, message: 'يجب أن يتكون رمز المرور من 8 خانات على الأقل!' };

  const finalUsername = username && username.trim() 
    ? username.trim().toLowerCase() 
    : (role === 'cashier' ? 'cashier_' + Math.floor(100 + Math.random() * 900) : 'cap_' + Math.floor(100 + Math.random() * 900));

  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : DEFAULT_RESTAURANT_ID;
  const newId = (role === 'cashier' ? 'u_csh_' : 'u_cap_') + Date.now();
  
  const newUser = {
    id: newId,
    restaurant_id: restId,
    username: finalUsername,
    pin: pin.trim(),
    full_name: cleanName,
    role: role,
    active: true
  };

  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  if (client) {
    try {
      await client.from('restaurant_users').insert([newUser]);
    } catch (e) {
      console.warn("Supabase insert error:", e);
    }
  }

  const local = getAuthConfig();
  if (role === 'cashier') {
    if (!local.cashiers) local.cashiers = [];
    local.cashiers.push({
      id: newId,
      username: finalUsername,
      name: cleanName,
      pin: pin.trim(),
      role: 'cashier',
      active: true
    });
  } else {
    if (!local.captains) local.captains = [];
    local.captains.push({
      id: newId,
      username: finalUsername,
      name: cleanName,
      pin: pin.trim(),
      role: 'captain',
      active: true
    });
  }
  saveAuthConfig(local);

  return { success: true, user: newUser };
}

async function updateStaffUserAsync(id, { name, username, pin, role }) {
  if (!name || !name.trim()) return { success: false, message: 'يرجى إدخال اسم صحيح!' };
  if (pin && pin.trim().length < 8) return { success: false, message: 'يجب أن يتكون الرمز السري من 8 خانات على الأقل!' };

  const local = getAuthConfig();
  let found = null;
  let targetList = 'captains';

  if (local.cashiers && local.cashiers.some(c => c.id === id)) {
    found = local.cashiers.find(c => c.id === id);
    targetList = 'cashiers';
  } else if (local.captains && local.captains.some(c => c.id === id)) {
    found = local.captains.find(c => c.id === id);
    targetList = 'captains';
  }

  if (found) {
    found.name = name.trim();
    if (username) found.username = username.trim().toLowerCase();
    if (pin) found.pin = pin.trim();
    if (role) found.role = role;
    saveAuthConfig(local);
  }

  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  if (client) {
    try {
      const updateData = { full_name: name.trim(), updated_at: new Date().toISOString() };
      if (username) updateData.username = username.trim().toLowerCase();
      if (pin) updateData.pin = pin.trim();
      if (role) updateData.role = role;
      await client.from('restaurant_users').update(updateData).eq('id', id);
    } catch (e) {}
  }

  return { success: true };
}

async function toggleStaffUserActiveAsync(id, role = 'captain') {
  const local = getAuthConfig();
  let item = null;

  if (local.cashiers && local.cashiers.some(c => c.id === id)) {
    item = local.cashiers.find(c => c.id === id);
  } else if (local.captains && local.captains.some(c => c.id === id)) {
    item = local.captains.find(c => c.id === id);
  }

  if (!item) return { success: false };

  item.active = !item.active;
  const newState = item.active;
  saveAuthConfig(local);

  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  if (client) {
    try {
      await client
        .from('restaurant_users')
        .update({ active: newState, updated_at: new Date().toISOString() })
        .eq('id', id);
    } catch (e) {}
  }

  return { success: true, newState };
}

async function deleteStaffUserAsync(id) {
  const local = getAuthConfig();
  if (local.cashiers) {
    local.cashiers = local.cashiers.filter(c => c.id !== id);
  }
  if (local.captains) {
    local.captains = local.captains.filter(c => c.id !== id);
  }
  saveAuthConfig(local);

  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  if (client) {
    try {
      await client.from('restaurant_users').delete().eq('id', id);
    } catch (e) {}
  }

  return { success: true };
}

// دوال التوافق القديمة
async function addCaptainAsync(name, pin) {
  return addStaffUserAsync(name, '', pin, 'captain');
}

async function toggleCaptainActiveStateAsync(id) {
  return toggleStaffUserActiveAsync(id, 'captain');
}

async function deleteCaptainAsync(id) {
  return deleteStaffUserAsync(id);
}

// -------------------------------------------------------------
// دوال مساعدة للجلسات وتوليد التوكن
// -------------------------------------------------------------
function generateSecureToken() {
  const array = new Uint32Array(4);
  if (window.crypto && window.crypto.getRandomValues) {
    window.crypto.getRandomValues(array);
    return Array.from(array, dec => dec.toString(36)).join('');
  }
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

function getCurrentSession() {
  if (window.AuthCore && typeof window.AuthCore.getCurrentSession === 'function') {
    return window.AuthCore.getCurrentSession();
  }
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan';
  try {
    if (sessionStorage.getItem('is_super_admin_logged_in') === 'true' || 
        localStorage.getItem('is_super_admin_logged_in') === 'true' ||
        sessionStorage.getItem('emattec_master_auth') === 'true' ||
        localStorage.getItem('emattec_master_auth') === 'true') {
      const superUser = sessionStorage.getItem('super_admin_user') || localStorage.getItem('super_admin_user') || 'super_admin';
      return {
        role: 'super_admin',
        userId: 'master_super_admin',
        name: 'مدير المنظومة والمنصة المركزي (Super Admin)',
        username: superUser,
        restaurantId: restId,
        loginTime: Date.now(),
        rememberMe: true,
        token: 'sup_master_sync'
      };
    }

    let sessionStr = sessionStorage.getItem('smart_emenu_' + restId + '_session') 
                  || sessionStorage.getItem('smart_emenu_session')
                  || localStorage.getItem('smart_emenu_' + restId + '_session')
                  || localStorage.getItem('smart_emenu_session');

    if (!sessionStr) return null;
    const session = JSON.parse(sessionStr);

    if (session && session.role) {
      if (session.loginTime && (Date.now() - session.loginTime > 30 * 24 * 60 * 60 * 1000)) {
        logoutSession(null);
        return null;
      }
      return session;
    }
    return null;
  } catch (e) {
    return null;
  }
}

function logoutSession(redirectUrl = 'index.html') {
  if (window.AuthCore && typeof window.AuthCore.logoutSession === 'function') {
    return window.AuthCore.logoutSession(redirectUrl);
  }
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan';
  try {
    sessionStorage.removeItem('smart_emenu_' + restId + '_session');
    sessionStorage.removeItem('smart_emenu_session');
    localStorage.removeItem('smart_emenu_' + restId + '_session');
    localStorage.removeItem('smart_emenu_session');
  } catch (e) {}
  if (redirectUrl) {
    const restParam = restId ? `?rest=${encodeURIComponent(restId)}` : '';
    const cleanUrl = redirectUrl.includes('?') ? redirectUrl : (redirectUrl + restParam);
    window.location.href = cleanUrl;
  }
}

function togglePasswordVisibility(inputId, btnEl) {
  const input = document.getElementById(inputId);
  if (!input) return;

  if (input.type === "password") {
    input.type = "text";
    if (btnEl) btnEl.textContent = "🔓";
  } else {
    input.type = "password";
    if (btnEl) btnEl.textContent = "👁️";
  }
}

/* === db.js === */
/**
 * Smart E-Menu - Database, Backup & Data Migration Module
 * نظام حفظ وتصدير واسترجاع البيانات لمنع فقدان البيانات عند التحديث
 */

const DB_VERSION = "2.1.0";

// سحب نسخة احتياطية لمعلومات وهوية المطعم فقط (بدون الأفراد وحساباتهم وبدون المنيو)
function exportFullDatabaseBackup() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  
  // استخراج وتطهير معلومات وهوية المطعم فقط بدون أي حسابات أو أرقام سرية للموظفين
  const cleanConfig = {
    id: (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan',
    name: config.name || '',
    nameEn: config.nameEn || '',
    tagline: config.tagline || '',
    taglineEn: config.taglineEn || '',
    currency: config.currency || 'د.ع',
    currencyEn: config.currencyEn || 'IQD',
    phone: config.phone || '',
    phone2: config.phone2 || '',
    mapUrl: config.mapUrl || '',
    whatsappNumber: config.whatsappNumber || '',
    publishedUrl: config.publishedUrl || '',
    address: config.address || '',
    workingHours: config.workingHours || '',
    holidays: config.holidays || '',
    tablesCount: config.tablesCount || 20,
    theme: config.theme || 'luxury',
    lang: config.lang || 'ar',
    logo: config.logo || 'logo.svg',
    allowDineInOrders: config.allowDineInOrders !== false,
    allowTakeawayOrders: config.allowTakeawayOrders !== false,
    takeawayPackageActive: config.takeawayPackageActive !== false
  };

  const backupData = {
    app: "Smart E-Menu",
    type: "restaurant_info_only",
    note: "نسخة احتياطية لمعلومات وهوية المطعم فقط (بدون الأفراد وحساباتهم وبدون المنيو أو الأصناف)",
    exportDate: new Date().toISOString(),
    restaurantName: cleanConfig.name,
    restaurant_info: cleanConfig,
    restaurant: cleanConfig
  };

  const jsonStr = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  const filename = `restaurant_info_${cleanConfig.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.json`;
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return { success: true, filename };
}

// استيراد واسترجاع معلومات المطعم و/أو المنيو من ملف JSON
function importDatabaseBackup(file, callback) {
  if (!file) {
    if (callback) callback({ success: false, message: "لم يتم تحديد أي ملف!" });
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const backup = JSON.parse(e.target.result);
      let restoredItems = [];

      // 1. استرجاع معلومات المطعم إذا كانت موجودة في الملف
      const info = backup.restaurant_info || backup.restaurant || (backup.data && backup.data.config);
      if (info && (info.name || info.id)) {
        const currentConfig = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
        const mergedConfig = {
          ...currentConfig,
          name: info.name || currentConfig.name,
          nameEn: info.nameEn || info.name_en || currentConfig.nameEn,
          tagline: info.tagline || currentConfig.tagline,
          taglineEn: info.taglineEn || info.tagline_en || currentConfig.taglineEn,
          currency: info.currency || currentConfig.currency,
          currencyEn: info.currencyEn || info.currency_en || currentConfig.currencyEn,
          phone: info.phone || currentConfig.phone,
          phone2: info.phone2 || currentConfig.phone2,
          mapUrl: info.mapUrl || info.map_url || currentConfig.mapUrl,
          whatsappNumber: info.whatsappNumber || info.whatsapp_number || currentConfig.whatsappNumber,
          publishedUrl: info.publishedUrl || info.published_url || currentConfig.publishedUrl,
          address: info.address || currentConfig.address,
          workingHours: info.workingHours || info.working_hours || currentConfig.workingHours,
          holidays: info.holidays || currentConfig.holidays,
          tablesCount: info.tablesCount || info.tables_count || currentConfig.tablesCount,
          logo: info.logo || currentConfig.logo,
          theme: info.theme || currentConfig.theme,
          lang: info.lang || currentConfig.lang
        };
        setStoredData('config', mergedConfig);
        restoredItems.push("معلومات وهوية المطعم");
      }

      // 2. استرجاع قائمة الطعام (الأطباق والأقسام) إذا كانت موجودة في الملف
      const dishes = backup.dishes || (backup.data && backup.data.dishes);
      const categories = backup.categories || (backup.data && backup.data.categories);
      if (dishes && Array.isArray(dishes) && dishes.length > 0) {
        setStoredData('dishes', dishes);
        if (categories && Array.isArray(categories)) {
          setStoredData('categories', categories);
        }
        restoredItems.push(`قائمة الطعام (${dishes.length} طبق)`);
      }

      if (restoredItems.length === 0) {
        throw new Error("الملف لا يحتوي على بيانات مطعم أو منيو صالحة!");
      }

      window.dispatchEvent(new Event('storage'));
      if (typeof renderAdminDishesTable === 'function') renderAdminDishesTable();

      if (callback) callback({ 
        success: true, 
        message: `تمت استعادة البيانات بنجاح: [ ${restoredItems.join(' + ')} ] بدون المساس بحسابات الأفراد! ✅` 
      });
    } catch (err) {
      if (callback) callback({ success: false, message: "خطأ في قراءة الملف: " + err.message });
    }
  };
  reader.readAsText(file);
}

// -------------------------------------------------------------
// سحب وتحميل قائمة الطعام (المنيو والأقسام) بصيغة JSON
// -------------------------------------------------------------
function exportMenuDishesBackup() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const categories = getStoredData('categories', DEFAULT_CATEGORIES);
  const dishes = getStoredData('dishes', DEFAULT_DISHES);

  const menuPackage = {
    app: "Smart E-Menu",
    type: "menu_dishes_only",
    note: "نسخة احتياطية لقائمة طعام المطعم (الأقسام، الأطباق، الأسعار، المكونات، الصور)",
    exportDate: new Date().toISOString(),
    restaurantName: config.name || "مطعم فحمة ودخان",
    currency: config.currency || "د.ع",
    totalCategories: (categories || []).length,
    totalDishes: (dishes || []).length,
    categories: categories || [],
    dishes: dishes || []
  };

  const jsonStr = JSON.stringify(menuPackage, null, 2);
  const blob = new Blob([jsonStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  const filename = `menu_dishes_${(config.name || 'restaurant').replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.json`;
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return { success: true, filename, count: (dishes || []).length };
}

// -------------------------------------------------------------
// تصدير قائمة الطعام كملف إكسل / CSV (يدعم اللغة العربية في Excel)
// -------------------------------------------------------------
function exportMenuDishesCSV() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const categories = getStoredData('categories', DEFAULT_CATEGORIES);
  const dishes = getStoredData('dishes', DEFAULT_DISHES);

  const catMap = {};
  (categories || []).forEach(c => { catMap[c.id] = c.name; });

  let csv = "\uFEFF"; // UTF-8 BOM for Arabic in Excel
  csv += `قائمة طعام,${config.name || 'المطعم'},تاريخ الاستخراج,${new Date().toLocaleDateString('ar-EG')}\n`;
  csv += `رقم الصنف,اسم الطبق,الاسم بالإنجليزية,القسم,السعر (${config.currency || 'د.ع'}),السعرات,المكونات,الحالة\n`;

  (dishes || []).forEach(d => {
    const catName = catMap[d.categoryId] || d.categoryId || 'عام';
    const cleanName = (d.name || '').replace(/,/g, ' - ');
    const cleanEn = (d.nameEn || '').replace(/,/g, ' - ');
    const cleanIng = (d.ingredients || '').replace(/,/g, ' - ').replace(/\n/g, ' ');
    const status = d.available !== false ? 'متوفر' : 'غير متوفر';
    csv += `"${d.id}","${cleanName}","${cleanEn}","${catName}","${d.price || 0}","${d.calories || ''}","${cleanIng}","${status}"\n`;
  });

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const filename = `menu_excel_${(config.name || 'restaurant').replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return { success: true, filename, count: (dishes || []).length };
}

// -------------------------------------------------------------
// استيراد واسترجاع قائمة الطعام من ملف JSON
// -------------------------------------------------------------
function importMenuDishesBackup(file, callback) {
  if (!file) {
    if (callback) callback({ success: false, message: "لم يتم تحديد أي ملف!" });
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const backup = JSON.parse(e.target.result);
      const dishes = backup.dishes || (backup.data && backup.data.dishes);
      const categories = backup.categories || (backup.data && backup.data.categories);

      if (!dishes || !Array.isArray(dishes) || dishes.length === 0) {
        throw new Error("الملف لا يحتوي على أصناف طعام صالحة!");
      }

      setStoredData('dishes', dishes);
      if (categories && Array.isArray(categories) && categories.length > 0) {
        setStoredData('categories', categories);
      }

      window.dispatchEvent(new Event('storage'));
      if (typeof renderAdminDishesTable === 'function') renderAdminDishesTable();

      if (callback) callback({
        success: true,
        message: `تم استيراد واسترجاع قائمة الطعام بنجاح (${dishes.length} طبق)! 🎉`
      });
    } catch (err) {
      if (callback) callback({ success: false, message: "خطأ في قراءة ملف المنيو: " + err.message });
    }
  };
  reader.readAsText(file);
}

// -------------------------------------------------------------
// سحب شامل لمعلومات المطعم والمنيو معاً (بدون أي أفراد أو حسابات)
// -------------------------------------------------------------
function exportRestaurantAndMenuBackup() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const categories = getStoredData('categories', DEFAULT_CATEGORIES);
  const dishes = getStoredData('dishes', DEFAULT_DISHES);

  const cleanConfig = {
    id: (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan',
    name: config.name || '',
    nameEn: config.nameEn || '',
    tagline: config.tagline || '',
    taglineEn: config.taglineEn || '',
    currency: config.currency || 'د.ع',
    currencyEn: config.currencyEn || 'IQD',
    phone: config.phone || '',
    phone2: config.phone2 || '',
    mapUrl: config.mapUrl || '',
    whatsappNumber: config.whatsappNumber || '',
    publishedUrl: config.publishedUrl || '',
    address: config.address || '',
    workingHours: config.workingHours || '',
    holidays: config.holidays || '',
    tablesCount: config.tablesCount || 20,
    theme: config.theme || 'luxury',
    lang: config.lang || 'ar',
    logo: config.logo || 'logo.svg',
    allowDineInOrders: config.allowDineInOrders !== false,
    allowTakeawayOrders: config.allowTakeawayOrders !== false,
    takeawayPackageActive: config.takeawayPackageActive !== false
  };

  const backupData = {
    app: "Smart E-Menu",
    type: "restaurant_and_menu_backup",
    note: "نسخة احتياطية شاملة لمعلومات المطعم وقائمة الطعام (خالية تماماً من حسابات الأفراد أو كلمات المرور)",
    exportDate: new Date().toISOString(),
    restaurantName: cleanConfig.name,
    restaurant_info: cleanConfig,
    categories: categories || [],
    dishes: dishes || []
  };

  const jsonStr = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  const filename = `full_menu_${cleanConfig.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.json`;
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return { success: true, filename, count: (dishes || []).length };
}

// -------------------------------------------------------------
// دوال استدعاء التصدير والاستيراد للمنيو من واجهة المستخدم
// -------------------------------------------------------------
function triggerMenuExport() {
  const res = exportMenuDishesBackup();
  if (res.success) {
    alert(`✅ تم تحميل وتنزيل قائمة الطعام كاملة (${res.count} طبق) بنجاح!\nاسم الملف: ${res.filename}`);
  }
}

function triggerMenuExportCSV() {
  const res = exportMenuDishesCSV();
  if (res.success) {
    alert(`✅ تم تصدير قائمة الطعام كملف إكسل (${res.filename}) بنجاح!\nيمكنك فتحه في برنامج Excel مباشرة.`);
  }
}

function triggerMenuImport() {
  const fileInput = document.getElementById('menu-import-file-input');
  if (!fileInput || !fileInput.files[0]) return;
  if (confirm("سيتم استرجاع وتحديث قائمة أطباق المنيو من الملف. هل تود المتابعة؟")) {
    importMenuDishesBackup(fileInput.files[0], (res) => {
      alert(res.message);
      if (res.success) location.reload();
    });
  }
}

function triggerCombinedExport() {
  const res = exportRestaurantAndMenuBackup();
  if (res.success) {
    alert(`✅ تم تنزيل النسخة الشاملة (المطعم + المنيو) بنجاح (${res.filename})!\nتحتوي على معلومات المطعم وقائمة الأطباق كاملة بدون أي حسابات للأفراد.`);
  }
}

// تهيئة وفحص البيانات عند إقلاع أي صفحة
function initDatabase() {
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan';
  // تهيئة البيانات الافتراضية الأولية لمطعم فحمة ودخان فقط (المطعم الافتراضي)
  if (restId === 'fahma_dokhan') {
    const existingConfig = localStorage.getItem('smart_emenu_fahma_dokhan_config') || localStorage.getItem('smart_emenu_config');
    if (!existingConfig) {
      setStoredData('config', DEFAULT_RESTAURANT_CONFIG);
    }
    const existingCategories = localStorage.getItem('smart_emenu_fahma_dokhan_categories') || localStorage.getItem('smart_emenu_categories');
    if (!existingCategories) {
      setStoredData('categories', DEFAULT_CATEGORIES);
    }
    const existingDishes = localStorage.getItem('smart_emenu_fahma_dokhan_dishes') || localStorage.getItem('smart_emenu_dishes');
    if (!existingDishes || existingDishes === '[]' || existingDishes === 'null') {
      setStoredData('dishes', DEFAULT_DISHES);
    }
    const existingAuth = localStorage.getItem('smart_emenu_fahma_dokhan_auth_config') || localStorage.getItem('smart_emenu_auth_config');
    if (!existingAuth) {
      setStoredData('auth_config', DEFAULT_AUTH_CONFIG);
    }
  }
  const existingAuth = localStorage.getItem(getScopedStorageKey('auth_config')) || localStorage.getItem('smart_emenu_auth_config');
  if (existingAuth) {
    // تنظيف أسماء الكباتن وفصل رمز الكاشير عن رمز المدير
    try {
      const auth = JSON.parse(existingAuth);
      let changed = false;
      if (auth && auth.cashiers) {
        auth.cashiers.forEach(c => {
          if (c.pin === '20262026' || c.pin === '12341234') {
            c.pin = '';
            changed = true;
          }
        });
      }
      if (auth && auth.captains) {
        auth.captains.forEach(c => {
          const clean = c.name.replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, '').trim();
          if (clean !== c.name) {
            c.name = clean;
            changed = true;
          }
        });
      }
      if (changed) {
        setStoredData('auth_config', auth);
      }
    } catch(e) {}
  }
}

// -------------------------------------------------------------
// -------------------------------------------------------------
// نظام إعدادات الطابعة الحرارية وتخصيص نوع وحجم الورق
// -------------------------------------------------------------
// =============================================================
// نظام إعدادات الطابعة الحرارية وتخصيص الطابعتين (100 كاشير + 101 مطبخ)
// =============================================================
const DEFAULT_PRINT_SETTINGS = {
  paperSize: '80mm',      // '80mm' | '58mm'
  ticketType: 'customer', // 'kitchen' (طابعة 101) | 'customer' (طابعة 100) - منع الطباعة المزدوجة
  autoDirectPrint: true,
  silentPrint: true,      // طباعة صامتة فورية
  bridgeUrl: 'http://127.0.0.1:8080',

  // 1. طابعة الكاشير (فواتير وحساب الزبائن)
  cashierMode: 'ip',      // 'ip' | 'windows'
  cashierIp: '192.168.1.100',
  cashierPort: 9100,
  cashierPrinterName: '', // اسم طابعة ويندوز USB إذا تم اختيارها

  // 2. طابعة المطبخ (بونات التحضير والأطباق)
  kitchenMode: 'ip',
  kitchenIp: '192.168.1.101',
  kitchenPort: 9100,
  kitchenPrinterName: 'Generic / Text Only'
};

function getPrintSettings() {
  const current = getStoredData('print_settings', DEFAULT_PRINT_SETTINGS);
  if (!current.cashierIp) current.cashierIp = '192.168.1.100';
  if (!current.kitchenIp || current.kitchenIp === '192.168.1.100') current.kitchenIp = '192.168.1.101';
  if (!current.cashierPort) current.cashierPort = 9100;
  if (!current.kitchenPort) current.kitchenPort = 9100;
  if (!current.cashierMode) current.cashierMode = 'ip';
  return current;
}

function savePrintSettings(settings) {
  setStoredData('print_settings', settings);
}


function getKitchenTicketHtml(order, config, timeStr, dateStr, typeBadge, isSmallPaper = false) {
  let kitchenItemsHtml = '';
  order.items.forEach(item => {
    kitchenItemsHtml += `
      <tr>
        <td class="ticket-item-qty" style="font-size: ${isSmallPaper ? '12px' : '14px'}; font-weight: 900;">${item.quantity}</td>
        <td>
          <div style="font-weight: 900; font-size: ${isSmallPaper ? '11px' : '13px'};">${item.name}</div>
          <div style="font-size: ${isSmallPaper ? '8px' : '9px'}; color: #444;">سعر الصنف: ${item.price.toLocaleString()} ${config.currency || 'د.ع'}</div>
        </td>
      </tr>
    `;
  });

  return `
    <div class="thermal-receipt kitchen-ticket" style="width: ${isSmallPaper ? '48mm' : '72mm'}; margin: 0 auto;">
      <div class="ticket-header">
        <h2 style="font-size: ${isSmallPaper ? '14px' : '17px'}; font-weight: 900;">${config.name}</h2>
        <div class="ticket-subtitle">👨‍🍳 بون تحضير المطبخ / KITCHEN</div>
        <div class="ticket-badge-box">
          ${typeBadge}
        </div>
      </div>

      <div class="ticket-info" style="font-size: ${isSmallPaper ? '10px' : '11px'};">
        <div class="info-row">
          <span>رقم البون: <b>#${order.id}</b></span>
          <span>الوقت: <b>${timeStr}</b></span>
        </div>
        <div class="info-row">
          <span>التاريخ: ${dateStr}</span>
          <span>المرسل: <b>${order.captainName || 'كاشير المطعم'}</b></span>
        </div>
        ${order.customerInfo || order.customerName ? `
          <div class="customer-highlight" style="margin-top: 2px;">
            الزبون: <b>${order.customerInfo || order.customerName}</b>
          </div>
        ` : ''}
        ${order.customerPhone ? `
          <!-- هاتف الزبون بارز ومكبر جداً -->
          <div style="margin: 6px 0; padding: 8px 10px; background: #000; color: #fff !important; border: 2px solid #000; border-radius: 8px; text-align: center; -webkit-print-color-adjust: exact; print-color-adjust: exact;">
            <div style="font-size: ${isSmallPaper ? '12px' : '14px'}; font-weight: 800; margin-bottom: 2px;">📞 هاتف الزبون والتوصيل:</div>
            <div style="font-size: ${isSmallPaper ? '24px' : '30px'}; font-weight: 900; font-family: monospace; letter-spacing: 2px; direction: ltr;">${order.customerPhone}</div>
          </div>
        ` : ''}
      </div>

      <div class="ticket-items">
        <table>
          <thead>
            <tr>
              <th style="width: 25%; text-align: center;">العدد</th>
              <th style="width: 75%;">الصنف والوجبة المطلوبة</th>
            </tr>
          </thead>
          <tbody>
            ${kitchenItemsHtml}
          </tbody>
        </table>
      </div>

      ${order.notes ? `
        <div class="ticket-kitchen-notes" style="font-size: ${isSmallPaper ? '10px' : '12px'}; border: 1px solid #000; padding: 4px; margin-top: 5px; font-weight: bold;">
          ⚠️ ملاحظات وإضافات للطلب: ${order.notes}
        </div>
      ` : ''}

      <!-- المجموع الكلي البارز في بون المطبخ -->
      <div style="margin-top: 8px; border: 2px solid #000; padding: 5px 8px; display: flex; justify-content: space-between; align-items: center; font-weight: 900; font-size: ${isSmallPaper ? '13px' : '15px'}; background: #f0f0f0; -webkit-print-color-adjust: exact; print-color-adjust: exact;">
        <span>المجموع الكلي:</span>
        <span style="font-family: monospace; font-size: ${isSmallPaper ? '14px' : '17px'};">${(order.total || 0).toLocaleString()} ${config.currency || 'د.ع'}</span>
      </div>

      <div class="ticket-footer">
        <div>--- نهاية بون تحضير المطبخ ---</div>
      </div>
    </div>
  `;
}

// -------------------------------------------------------------
// توليد كود HTML لفاتورة وحساب الزبون والتوصيل فائقة التفصيل
// -------------------------------------------------------------
function getCustomerTicketHtml(order, config, timeStr, dateStr, typeBadge, currency, isSmallPaper = false) {
  let customerItemsHtml = '';
  let subtotal = 0;

  order.items.forEach(item => {
    const itemTotal = item.price * item.quantity;
    subtotal += itemTotal;

    customerItemsHtml += `
      <tr style="border-bottom: 1px dashed #ddd;">
        <td class="ticket-item-qty" style="font-size: ${isSmallPaper ? '11px' : '13px'}; font-weight: 900; text-align: center; vertical-align: top; padding: 4px 2px;">
          ${item.quantity}
        </td>
        <td style="vertical-align: top; padding: 4px 2px;">
          <div style="font-weight: 800; font-size: ${isSmallPaper ? '11px' : '12px'};">${item.name}</div>
          <div style="font-size: ${isSmallPaper ? '8px' : '9px'}; color: #555;">
            سعر المفرد: ${item.price.toLocaleString()} ${currency}
          </div>
        </td>
        <td style="text-align: left; font-weight: 900; font-size: ${isSmallPaper ? '10px' : '11px'}; vertical-align: top; padding: 4px 2px; white-space: nowrap;">
          ${itemTotal.toLocaleString()} ${currency}
        </td>
      </tr>
    `;
  });

  const isTakeawayOrDelivery = (order.type === 'takeaway' || order.type === 'delivery');
  const deliveryFee = order.deliveryFee !== undefined ? order.deliveryFee : (isTakeawayOrDelivery ? 0 : null);

  return `
    <div class="thermal-receipt customer-invoice" style="width: ${isSmallPaper ? '48mm' : '72mm'}; margin: 0 auto; color: #000; font-family: 'Cairo', monospace, sans-serif;">
      <div class="ticket-header">
        <h2 style="font-size: ${isSmallPaper ? '14px' : '17px'}; font-weight: 900;">${config.name}</h2>
        ${config.tagline ? `<div class="tagline-print" style="font-size: 8px; color: #333;">${config.tagline}</div>` : ''}
        <div class="ticket-subtitle">🧾 فاتورة وحساب الزبون / INVOICE</div>
        <div class="ticket-badge-box">
          ${typeBadge}
        </div>
      </div>

      <div class="ticket-info" style="font-size: ${isSmallPaper ? '9px' : '11px'};">
        <div class="info-row">
          <span>رقم الفاتورة: <b>#${order.id}</b></span>
          <span>الوقت: <b>${timeStr}</b></span>
        </div>
        <div class="info-row">
          <span>التاريخ: ${dateStr}</span>
          <span>الكاشير / الخدمة: <b>${order.captainName || 'كاشير المطعم'}</b></span>
        </div>

        ${(order.customerInfo || order.customerName) ? `
          <div class="customer-highlight" style="margin-top: 3px; font-size: ${isSmallPaper ? '10px' : '12px'};">
            👤 اسم الزبون: <b>${order.customerInfo || order.customerName}</b>
          </div>
        ` : ''}

        ${order.customerPhone ? `
          <!-- هاتف الزبون بارز ومكبر جداً -->
          <div style="margin: 6px 0; padding: 8px 10px; background: #000; color: #fff !important; border: 2px solid #000; border-radius: 8px; text-align: center; -webkit-print-color-adjust: exact; print-color-adjust: exact;">
            <div style="font-size: ${isSmallPaper ? '12px' : '14px'}; font-weight: 800; margin-bottom: 2px;">📞 هاتف الزبون والتوصيل:</div>
            <div style="font-size: ${isSmallPaper ? '24px' : '30px'}; font-weight: 900; font-family: monospace; letter-spacing: 2px; direction: ltr;">${order.customerPhone}</div>
          </div>
        ` : ''}

        ${order.customerAddress ? `
          <div class="info-row" style="margin-top: 3px; font-size: ${isSmallPaper ? '9px' : '11px'};">
            <span>📍 عنوان التوصيل:</span> <b>${order.customerAddress}</b>
          </div>
        ` : ''}

        ${config.phone ? `
          <div class="info-row" style="margin-top: 2px; font-size: ${isSmallPaper ? '8px' : '10px'}; color: #444;">
            <span>هاتف المطعم:</span> <b>${config.phone}</b>
          </div>
        ` : ''}
      </div>

      <div class="ticket-items">
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="border-bottom: 2px solid #000;">
              <th style="width: 15%; text-align: center; font-size: ${isSmallPaper ? '9px' : '11px'};">العدد</th>
              <th style="width: 55%; text-align: right; font-size: ${isSmallPaper ? '9px' : '11px'};">الصنف وسعر الوجبة</th>
              <th style="width: 30%; text-align: left; font-size: ${isSmallPaper ? '9px' : '11px'};">المجموع</th>
            </tr>
          </thead>
          <tbody>
            ${customerItemsHtml}
          </tbody>
        </table>
      </div>

      <!-- تفصيل الحساب والمجاميع وأجور التوصيل -->
      <div class="ticket-summary" style="margin-top: 6px; border-top: 1px solid #000; padding-top: 4px; font-size: ${isSmallPaper ? '9px' : '11px'};">
        <div class="info-row" style="margin-bottom: 2px;">
          <span>المجموع الفرعي للوجبات:</span>
          <b>${subtotal.toLocaleString()} ${currency}</b>
        </div>

        ${isTakeawayOrDelivery ? `
          <div class="info-row" style="margin-bottom: 2px;">
            <span>أجور التوصيل:</span>
            <b>${deliveryFee && deliveryFee > 0 ? `${deliveryFee.toLocaleString()} ${currency}` : '0 ' + currency + ' (توصيل مجاني 🛵)'}</b>
          </div>
        ` : ''}

        ${order.discount && order.discount > 0 ? `
          <div class="info-row" style="margin-bottom: 2px; color: #c00;">
            <span>الخصم / التخفيض:</span>
            <b>-${order.discount.toLocaleString()} ${currency}</b>
          </div>
        ` : ''}

        <div class="summary-row total-row" style="font-size: ${isSmallPaper ? '13px' : '16px'}; font-weight: 900; border: 2px solid #000; margin-top: 6px; padding: 5px 8px; background: #f0f0f0; -webkit-print-color-adjust: exact; print-color-adjust: exact; display: flex; justify-content: space-between; align-items: center;">
          <span>المجموع الكلي المطلوب:</span>
          <span style="font-family: monospace; font-size: ${isSmallPaper ? '14px' : '18px'}; font-weight: 900;">${order.total.toLocaleString()} ${currency}</span>
        </div>
      </div>

      ${order.notes ? `
        <div style="margin-top: 4px; font-size: ${isSmallPaper ? '8px' : '10px'}; border: 1px dashed #666; padding: 3px;">
          <b>ملاحظات الزبون:</b> ${order.notes}
        </div>
      ` : ''}

      ${order.mapUrl ? `
        <!-- قسم باركود الخريطة والملاحة لعامل التوصيل -->
        <div style="text-align: center; margin-top: 6px; padding-top: 5px; border-top: 1px dashed #000;">
          <div style="font-weight: 900; font-size: ${isSmallPaper ? '9px' : '11px'}; margin-bottom: 3px;">🗺️ باركود موقع الزبون على الخريطة GPS:</div>
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(order.mapUrl)}" style="width: ${isSmallPaper ? '80px' : '100px'}; height: ${isSmallPaper ? '80px' : '100px'}; margin: 0 auto; display: block; border: 1px solid #000; padding: 2px;" alt="QR Map" />
          <div style="font-size: 8px; font-weight: bold; margin-top: 2px;">امسح الباركود بكاميرا الهاتف للملاحة وتوجيه السائق</div>
        </div>
      ` : ''}

      <div class="ticket-footer" style="margin-top: 6px; border-top: 1px dashed #000; padding-top: 4px; text-align: center;">
        <div class="thank-you-msg" style="font-weight: bold; font-size: ${isSmallPaper ? '9px' : '11px'};">❤️ نتشرف بزيارتكم وبالصحة والعافية! ❤️</div>
        <div style="font-size: 8px; color: #444; margin-top: 2px;">نظام إدارة المطاعم الذكي - ${config.name}</div>
      </div>
    </div>
  `;
}

// -------------------------------------------------------------
// محرك الطباعة المباشر الذكي وفق إعدادات الكاشير / الكابتن
// -------------------------------------------------------------
function centerTicketText(text, width = 42) {
  text = String(text || '');
  const len = text.length;
  if (len >= width) return text;
  const pad = Math.floor((width - len) / 2);
  return " ".repeat(pad) + text;
}

function formatKitchenTextTicket(order, config, isSmallPaper = false) {
  const width = isSmallPaper ? 30 : 42;
  const div = "=".repeat(width);
  const subDiv = "-".repeat(width);
  const dateObj = new Date(order.timestamp || Date.now());
  const timeStr = dateObj.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const dateStr = dateObj.toLocaleDateString('ar-EG');
  
  let typeText = "سفري / خارجي";
  if (order.type === 'dine-in') {
    typeText = `صالة - طاولة [ ${order.tableNumber || 1} ]`;
  } else if (order.type === 'delivery') {
    typeText = "طلب توصيل دليفري";
  }

  let lines = [
    div,
    centerTicketText(config.name || "مطعم فحمة ودخان", width),
    centerTicketText("بون تحضير المطبخ / KITCHEN", width),
    div,
    `رقم البون: #${order.id}   الوقت: ${timeStr}`,
    `التاريخ: ${dateStr}`,
    `نوع الطلب: ${typeText}`,
    `المرسل: ${order.captainName || 'كاشير المطعم'}`,
    subDiv,
    "العدد | الصنف المطلوب",
    subDiv
  ];

  (order.items || []).forEach(item => {
    lines.push(` [${item.quantity}]  ${item.name}`);
  });

  if (order.notes) {
    lines.push(subDiv);
    lines.push(`ملاحظات: ${order.notes}`);
  }

  lines.push(subDiv);
  lines.push(`المجموع الكلي: ${(order.total || 0).toLocaleString()} ${config.currency || 'د.ع'}`);
  lines.push(div);
  lines.push(centerTicketText("--- نهاية بون تحضير المطبخ ---", width));
  return lines.join("\r\n");
}

function formatCashierTextTicket(order, config, isSmallPaper = false) {
  const width = isSmallPaper ? 30 : 42;
  const div = "=".repeat(width);
  const subDiv = "-".repeat(width);
  const dateObj = new Date(order.timestamp || Date.now());
  const timeStr = dateObj.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const dateStr = dateObj.toLocaleDateString('ar-EG');
  const currency = order.currency || config.currency || 'د.ع';

  let typeText = "سفري / خارجي";
  if (order.type === 'dine-in') {
    typeText = `صالة - طاولة [ ${order.tableNumber || 1} ]`;
  } else if (order.type === 'delivery') {
    typeText = "طلب توصيل دليفري";
  }

  let lines = [
    div,
    centerTicketText(config.name || "مطعم فحمة ودخان", width),
    centerTicketText("فاتورة حساب وبون محاسبة", width),
    div,
    `رقم الفاتورة: #${order.id}   الوقت: ${timeStr}`,
    `التاريخ: ${dateStr}`,
    `نوع الطلب: ${typeText}`,
    `المحاسب: ${order.captainName || 'كاشير المطعم'}`
  ];

  if (order.customerInfo || order.customerName) {
    lines.push(`الزبون: ${order.customerInfo || order.customerName}`);
  }
  if (order.customerPhone) {
    lines.push(`هاتف الزبون: ${order.customerPhone}`);
  }

  lines.push(subDiv);
  lines.push("العدد | الصنف                      | الإجمالي");
  lines.push(subDiv);

  let subtotal = 0;
  (order.items || []).forEach(item => {
    const itemTotal = item.price * item.quantity;
    subtotal += itemTotal;
    lines.push(` [${item.quantity}]  ${item.name}`);
    lines.push(`      ${item.price.toLocaleString()} x ${item.quantity} = ${itemTotal.toLocaleString()} ${currency}`);
  });

  lines.push(subDiv);
  lines.push(`المجموع الفرعي: ${subtotal.toLocaleString()} ${currency}`);

  if (order.deliveryFee && order.deliveryFee > 0) {
    lines.push(`أجور التوصيل: ${order.deliveryFee.toLocaleString()} ${currency}`);
  }
  if (order.discount && order.discount > 0) {
    lines.push(`الخصم والتخفيض: -${order.discount.toLocaleString()} ${currency}`);
  }

  lines.push(div);
  lines.push(`المجموع النهائي المطلوب: ${(order.total || 0).toLocaleString()} ${currency}`);
  lines.push(div);
  if (order.notes) {
    lines.push(`ملاحظات: ${order.notes}`);
  }
  lines.push(centerTicketText("شكراً لزيارتكم وبالصحة والعافية", width));
  lines.push(div);
  return lines.join("\r\n");
}

function showSilentPrintToast(msg) {
  let toast = document.getElementById('silent-print-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'silent-print-toast';
    toast.className = 'fixed bottom-5 left-5 z-[9999] bg-emerald-600 text-white font-black text-xs px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 transition-all duration-300 transform translate-y-10 opacity-0 pointer-events-none';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span>🖨️</span><span>${msg}</span>`;
  toast.classList.remove('translate-y-10', 'opacity-0');
  setTimeout(() => {
    toast.classList.add('translate-y-10', 'opacity-0');
  }, 3500);
}



// دالة الطباعة المباشرة الذكية للأوردر
async function printOrderDirect(order, overrideTicketType = null) {
  if (!order) return;

  const ticketEl = document.getElementById('kitchen-print-ticket');
  const printSettings = getPrintSettings();

  const isSmallPaper = (printSettings.paperSize === '58mm');
  // منع الطباعة المزدوجة نهائياً: إما مطبخ 101 أو حساب 100 فقط
  let ticketType = overrideTicketType;
  if (!ticketType || ticketType === 'separate' || ticketType === 'both' || ticketType === 'combined') {
    ticketType = (printSettings.ticketType === 'kitchen') ? 'kitchen' : 'customer';
  }

  const dateObj = new Date(order.timestamp || Date.now());
  const timeStr = dateObj.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const dateStr = dateObj.toLocaleDateString('ar-EG');
  const currency = order.currency || config.currency || 'د.ع';

  let typeBadge = "🛵 سفري / خارجي";
  if (order.type === 'dine-in') {
    typeBadge = `🍽️ صالة داخلية - طاولة [ ${order.tableNumber || 1} ]`;
  } else if (order.type === 'delivery') {
    typeBadge = `🛵 طلب توصيل دليفري`;
  }

  // تحديث محتوى عنصر الطباعة للمتصفح (فردي محدد فقط)
  if (ticketEl) {
    if (ticketType === 'kitchen') {
      ticketEl.innerHTML = `<div class="thermal-dual-container">${getKitchenTicketHtml(order, config, timeStr, dateStr, typeBadge, isSmallPaper)}</div>`;
    } else {
      ticketEl.innerHTML = `<div class="thermal-dual-container">${getCustomerTicketHtml(order, config, timeStr, dateStr, typeBadge, currency, isSmallPaper)}</div>`;
    }
  }

  // محاولة الطباعة الصامتة عبر وسيط ويندوز المحلي إذا كانت مفعلة (طابعة فردية فقط)
  if (printSettings.silentPrint !== false) {
    const bridgeUrl = printSettings.bridgeUrl || 'http://127.0.0.1:8080';
    try {
      if (ticketType === 'kitchen') {
        // بون المطبخ فقط (101)
        const kitchenText = formatKitchenTextTicket(order, config, isSmallPaper);
        const res = await fetch(`${bridgeUrl}/print-kitchen`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mode: 'ip',
            ip: printSettings.kitchenIp || '192.168.1.101',
            port: printSettings.kitchenPort || 9100,
            text: kitchenText
          })
        }).catch(e => null);
        if (res && res.ok) {
          showSilentPrintToast("تم إرسال بون المطبخ فقط (101) 👨‍🍳✅");
          return;
        }
      } else {
        // فاتورة الكاشير فقط (100)
        const cashierText = formatCashierTextTicket(order, config, isSmallPaper);
        const res = await fetch(`${bridgeUrl}/print-cashier`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mode: printSettings.cashierMode || 'ip',
            ip: printSettings.cashierIp || '192.168.1.100',
            port: printSettings.cashierPort || 9100,
            printerName: printSettings.cashierPrinterName,
            text: cashierText
          })
        }).catch(e => null);
        if (res && res.ok) {
          showSilentPrintToast("تم إرسال فاتورة الحساب فقط (100) 🧾✅");
          return;
        }
      }
    } catch (err) {
      console.warn("Silent bridge error, falling back to window.print:", err);
    }
  }

  // في حال تعذر وسيط الطباعة، التحويل لنافذة الطباعة العادية
  window.print();
}

function printDualThermalReceipt(order) {
  // منع الطباعة المزدوجة: توجيه تلقائي لفاتورة الحساب الفردية
  printOrderDirect(order, 'customer');
}

function renderAndPrintKitchenTicket(order) {
  printOrderDirect(order, 'kitchen');
}

function renderAndPrintCashierTicket(order) {
  printOrderDirect(order, 'customer');
}

// -------------------------------------------------------------
// نافذة إعدادات الطابعات والطباعة الصامتة (100 كاشير + 101 مطبخ)
// -------------------------------------------------------------
function openPrinterSettingsModal() {
  let modal = document.getElementById('printer-settings-modal');
  const currentSettings = getPrintSettings();

  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'printer-settings-modal';
    modal.className = 'fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto';
    modal.innerHTML = `
      <div class="max-w-lg w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 text-right relative my-8 max-h-[90vh] overflow-y-auto">
        
        <!-- Header -->
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div class="flex items-center gap-2">
            <span class="text-2xl">🖨️</span>
            <div>
              <h3 class="text-base font-black text-white">إعدادات الطابعات والطباعة الصامتة</h3>
              <p class="text-xs text-slate-400">تخصيص طابعة 1 (الكاشير 100) وطابعة 2 (المطبخ 101)</p>
            </div>
          </div>
          <button onclick="closePrinterSettingsModal()" class="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center font-bold">
            ✕
          </button>
        </div>

        <!-- مؤشر اتصال وسيط الطباعة المحلي -->
        <div id="ps-bridge-indicator" class="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-center justify-between text-xs">
          <div class="flex items-center gap-2">
            <span id="ps-status-dot" class="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse"></span>
            <span id="ps-status-text" class="text-slate-300 font-bold">جاري فحص وسيط الطباعة المحلي...</span>
          </div>
          <button onclick="checkBridgeAndRefreshPrinters()" class="text-[11px] text-rose-400 font-bold hover:underline flex items-center gap-1">
            <span>🔄</span> <span>إعادة فحص</span>
          </button>
        </div>

        <!-- زر اختبار سريع لكلا الطابعتين معاً -->
        <button type="button" onclick="testBothPrinters()" class="w-full py-2.5 px-3 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 rounded-2xl text-xs font-black transition flex items-center justify-center gap-2 shadow-lg">
          <span>⚡</span> <span>تجربة الطابعتين معاً (100 كاشير + 101 مطبخ)</span>
        </button>

        <!-- 1. قسم طابعة الكاشير (طابعة 1: 192.168.1.100) -->
        <div class="p-4 bg-slate-950 border border-emerald-900/40 rounded-2xl space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2 text-emerald-400 font-black text-xs">
              <span>💵</span>
              <span>1. طابعة الكاشير وفواتير الحساب (طابعة 1):</span>
            </div>
            <button type="button" onclick="testCashierPrinter()" class="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 border border-emerald-500/30 rounded-lg text-[10px] font-bold transition flex items-center gap-1">
              <span>🧪</span> <span>تجربة طابعة الكاشير (100)</span>
            </button>
          </div>

          <div class="p-3 bg-slate-900/90 border border-slate-800 rounded-xl space-y-2">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
              <div class="md:col-span-2 space-y-1">
                <label class="block text-[10px] text-slate-400 font-bold">عنوان IP طابعة الكاشير:</label>
                <input type="text" id="ps-cashier-ip" placeholder="192.168.1.100" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-emerald-400 font-mono text-xs text-left placeholder:text-slate-600 focus:outline-none focus:border-emerald-500" dir="ltr" />
              </div>
              <div class="space-y-1">
                <label class="block text-[10px] text-slate-400 font-bold">المنفذ (Port):</label>
                <input type="number" id="ps-cashier-port" placeholder="9100" value="9100" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs text-center focus:outline-none focus:border-emerald-500" dir="ltr" />
              </div>
            </div>

            <!-- خيار اختياري لطابعة ويندوز USB -->
            <div class="pt-2 border-t border-slate-800/80">
              <label class="block text-[10px] text-slate-400 mb-1">أو اختر طابعة USB مثبتة في ويندوز (اختياري):</label>
              <select id="ps-cashier-printer-select" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-[11px] focus:outline-none focus:border-emerald-500">
                <option value="">[ استخدام طابعة الشبكة IP 192.168.1.100 ]</option>
              </select>
            </div>
          </div>
        </div>

        <!-- 2. قسم طابعة المطبخ (طابعة 2: 192.168.1.101) -->
        <div class="p-4 bg-slate-950 border border-rose-900/40 rounded-2xl space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2 text-rose-400 font-black text-xs">
              <span>👨‍🍳</span>
              <span>2. طابعة المطبخ وبونات التحضير (طابعة 2):</span>
            </div>
            <button type="button" onclick="testKitchenPrinter()" class="px-2.5 py-1 bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 rounded-lg text-[10px] font-bold transition flex items-center gap-1">
              <span>🧪</span> <span>تجربة طابعة المطبخ (101)</span>
            </button>
          </div>

          <div class="p-3 bg-slate-900/90 border border-slate-800 rounded-xl space-y-2">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
              <div class="md:col-span-2 space-y-1">
                <label class="block text-[10px] text-slate-400 font-bold">عنوان IP طابعة المطبخ:</label>
                <input type="text" id="ps-kitchen-ip" placeholder="192.168.1.101" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-rose-400 font-mono text-xs text-left placeholder:text-slate-600 focus:outline-none focus:border-rose-500" dir="ltr" />
              </div>
              <div class="space-y-1">
                <label class="block text-[10px] text-slate-400 font-bold">المنفذ (Port):</label>
                <input type="number" id="ps-kitchen-port" placeholder="9100" value="9100" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs text-center focus:outline-none focus:border-rose-500" dir="ltr" />
              </div>
            </div>
            <p class="text-[10px] text-slate-500">يتصل النظام بطابعة المطبخ (192.168.1.101) لإطلاق صفارة التنبيه وقص بون الطباخ آلياً.</p>
          </div>
        </div>

        <!-- 3. آلية توزيع الطباعة التلقائية (فردية لكل طابعة) -->
        <div class="p-4 bg-slate-950 border border-slate-800/80 rounded-2xl space-y-2">
          <div class="flex items-center justify-between">
            <span class="block text-xs font-black text-white">3. نظام الطباعة المنفصل (منع الطباعة المزدوجة نهائياً):</span>
            <span class="text-[10px] text-emerald-400 font-bold">كل طابعة بزر مستقل ✨</span>
          </div>
          <p class="text-[11px] text-slate-400 leading-relaxed">
            تم توفير أزرار مستقلة في جميع الشاشات: زر لإرسال بون المطبخ (101)، وزر لطباعة فاتورة الحساب (100).
          </p>
          <div class="grid grid-cols-2 gap-2 pt-1">
            <label class="p-2.5 bg-slate-900 border border-slate-800 rounded-xl cursor-pointer hover:border-rose-500 transition flex items-center gap-2">
              <input type="radio" name="printer-type-radio" value="kitchen" id="ps-type-kitchen" class="accent-rose-600" />
              <div>
                <div class="text-xs font-black text-white">👨‍🍳 بون المطبخ (101)</div>
              </div>
            </label>
            <label class="p-2.5 bg-slate-900 border border-slate-800 rounded-xl cursor-pointer hover:border-rose-500 transition flex items-center gap-2">
              <input type="radio" name="printer-type-radio" value="customer" id="ps-type-customer" class="accent-rose-600" />
              <div>
                <div class="text-xs font-black text-amber-300">🧾 فاتورة الحساب (100)</div>
              </div>
            </label>
          </div>
        </div>

        <!-- 4. خيارات إضافية: الحجم والطباعة الصامتة -->
        <div class="grid grid-cols-2 gap-2">
          <div class="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
            <span class="block text-[11px] font-bold text-slate-300">مقاس الورق الحراري:</span>
            <div class="flex gap-2 text-xs">
              <label class="flex items-center gap-1 cursor-pointer">
                <input type="radio" name="printer-size-radio" value="80mm" id="ps-size-80" class="accent-rose-600" />
                <span class="text-white text-xs">80mm عريض</span>
              </label>
              <label class="flex items-center gap-1 cursor-pointer">
                <input type="radio" name="printer-size-radio" value="58mm" id="ps-size-58" class="accent-rose-600" />
                <span class="text-white text-xs">58mm صغير</span>
              </label>
            </div>
          </div>

          <label class="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex items-center gap-2 cursor-pointer hover:border-rose-500 transition">
            <input type="checkbox" id="ps-silent-toggle" class="w-4 h-4 accent-rose-600 rounded" />
            <div>
              <div class="text-xs font-black text-white">الطباعة الصامتة الفورية</div>
              <div class="text-[10px] text-slate-400">تخطي شاشة المعاينة تماماً</div>
            </div>
          </label>
        </div>

        <!-- زر الحفظ النهائي -->
        <button onclick="savePrinterSettingsFromModal()" class="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-600/30 transition active:scale-95">
          حفظ التفضيلات وتثبيت الطابعتين ✅
        </button>

      </div>
    `;
    document.body.appendChild(modal);
  }

  // تعبئة الحقول بالقيم المخزنة الحالية
  const cashierIpInput = document.getElementById('ps-cashier-ip');
  if (cashierIpInput) cashierIpInput.value = currentSettings.cashierIp || '192.168.1.100';

  const cashierPortInput = document.getElementById('ps-cashier-port');
  if (cashierPortInput) cashierPortInput.value = currentSettings.cashierPort || 9100;

  const kitchenIpInput = document.getElementById('ps-kitchen-ip');
  if (kitchenIpInput) kitchenIpInput.value = currentSettings.kitchenIp || '192.168.1.101';

  const kitchenPortInput = document.getElementById('ps-kitchen-port');
  if (kitchenPortInput) kitchenPortInput.value = currentSettings.kitchenPort || 9100;

  const silentToggle = document.getElementById('ps-silent-toggle');
  if (silentToggle) silentToggle.checked = (currentSettings.silentPrint !== false);

  const sizeRadio = modal.querySelector(`input[name="printer-size-radio"][value="${currentSettings.paperSize || '80mm'}"]`);
  if (sizeRadio) sizeRadio.checked = true;

  const typeRadio = modal.querySelector(`input[name="printer-type-radio"][value="${currentSettings.ticketType || 'separate'}"]`);
  if (typeRadio) typeRadio.checked = true;

  modal.classList.remove('hidden');

  // فحص الوسيط وجلب الطابعات
  checkBridgeAndRefreshPrinters();
}

// دالة فحص اتصال الوسيط وجلب الطابعات
async function checkBridgeAndRefreshPrinters() {
  const currentSettings = getPrintSettings();
  const dot = document.getElementById('ps-status-dot');
  const txt = document.getElementById('ps-status-text');
  const sel = document.getElementById('ps-cashier-printer-select');

  if (dot && txt) {
    dot.className = 'w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse';
    txt.innerText = 'جاري التحقق من وسيط الطباعة المحلي...';
  }

  const probeUrls = [currentSettings.bridgeUrl, 'http://127.0.0.1:8080', 'http://127.0.0.1:9090', 'http://localhost:8080', 'http://localhost:9090'].filter(Boolean);
  let activeUrl = null;

  for (const u of [...new Set(probeUrls)]) {
    try {
      const res = await fetch(`${u}/status`, { method: 'GET' });
      if (res.ok) {
        activeUrl = u;
        break;
      }
    } catch (e) {}
  }

  if (activeUrl) {
    currentSettings.bridgeUrl = activeUrl;
    savePrintSettings(currentSettings);

    if (dot && txt) {
      dot.className = 'w-2.5 h-2.5 rounded-full bg-emerald-500';
      const portNum = activeUrl.split(':').pop().replace(/\D/g, '');
      txt.innerHTML = `<span class="text-emerald-400 font-bold">وسيط الطباعة متصل ويعمل بنجاح 🟢 (المنفذ ${portNum}) - الطباعة الصامتة نشطة</span>`;
    }

    try {
      const prRes = await fetch(`${activeUrl}/printers`);
      if (prRes.ok && sel) {
        const printers = await prRes.json();
        sel.innerHTML = '<option value="">[ استخدام طابعة الشبكة IP 192.168.1.100 ]</option>';
        printers.forEach(p => {
          const opt = document.createElement('option');
          opt.value = p.name;
          opt.innerText = `${p.name} ${p.port ? `(${p.port})` : ''}`;
          if (p.name === currentSettings.cashierPrinterName) {
            opt.selected = true;
          }
          sel.appendChild(opt);
        });
      }
    } catch (e) {}
    return;
  }

  if (dot && txt) {
    dot.className = 'w-2.5 h-2.5 rounded-full bg-rose-500';
    txt.innerHTML = '<span class="text-rose-400 font-bold">وسيط الطباعة غير متصل 🔴</span> <span class="text-[10px] text-slate-400">(شغّل ملف "تشغيل_وسيط_الطباعة.bat" بالمجلد)</span>';
  }
}

// اختبار طابعة الكاشير (طابعة 1: 192.168.1.100)
async function testCashierPrinter() {
  const ip = (document.getElementById('ps-cashier-ip')?.value || '192.168.1.100').trim();
  const port = parseInt(document.getElementById('ps-cashier-port')?.value || '9100', 10);
  const sel = document.getElementById('ps-cashier-printer-select');
  const printerName = sel ? sel.value : '';
  const currentSettings = getPrintSettings();
  const bridgeUrl = currentSettings.bridgeUrl || 'http://127.0.0.1:8080';

  try {
    const res = await fetch(`${bridgeUrl}/test-print`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'cashier',
        ip: ip,
        port: port,
        printerName: printerName,
        mode: printerName ? 'windows' : 'ip'
      })
    });
    const data = await res.json();
    if (data.success) {
      alert(`✅ تم إرسال أمر الطباعة التجريبي لطابعة الكاشير (${printerName ? printerName : ip}) بنجاح!`);
    } else {
      alert("❌ تعذر الاتصال بطابعة الكاشير: " + (data.error || "تأكد من عنوان IP وتشغيل الطابعة واتصال الشبكة"));
    }
  } catch (err) {
    alert("❌ تعذر الوصول لوسيط الطباعة المحلي. تأكد من تشغيل ملف 'تشغيل_وسيط_الطباعة.bat' أولاً على المنفذ 8080.");
  }
}

// اختبار طابعة المطبخ (طابعة 2: 192.168.1.101)
async function testKitchenPrinter() {
  const ip = (document.getElementById('ps-kitchen-ip')?.value || '192.168.1.101').trim();
  const port = parseInt(document.getElementById('ps-kitchen-port')?.value || '9100', 10);
  const currentSettings = getPrintSettings();
  const bridgeUrl = currentSettings.bridgeUrl || 'http://127.0.0.1:8080';

  try {
    const res = await fetch(`${bridgeUrl}/test-print`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'kitchen',
        ip: ip,
        port: port
      })
    });
    const data = await res.json();
    if (data.success) {
      alert(`✅ تم إرسال أمر الطباعة التجريبي لطابعة المطبخ (${ip}) بنجاح (مع إطلاق صفارة التنبيه)!`);
    } else {
      alert("❌ تعذر الاتصال بطابعة المطبخ: " + (data.error || "تأكد من عنوان IP وتشغيل الطابعة واتصال الشبكة"));
    }
  } catch (err) {
    alert("❌ تعذر الوصول لوسيط الطباعة المحلي. تأكد من تشغيل ملف 'تشغيل_وسيط_الطباعة.bat' أولاً على المنفذ 8080.");
  }
}

// اختبار الطابعتين معاً (100 كاشير + 101 مطبخ)
async function testBothPrinters() {
  const cashierIp = (document.getElementById('ps-cashier-ip')?.value || '192.168.1.100').trim();
  const kitchenIp = (document.getElementById('ps-kitchen-ip')?.value || '192.168.1.101').trim();
  const cashierPort = parseInt(document.getElementById('ps-cashier-port')?.value || '9100', 10);
  const sel = document.getElementById('ps-cashier-printer-select');
  const printerName = sel ? sel.value : '';
  const currentSettings = getPrintSettings();
  const bridgeUrl = currentSettings.bridgeUrl || 'http://127.0.0.1:8080';

  try {
    const res = await fetch(`${bridgeUrl}/test-print`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'both',
        cashierIp: cashierIp,
        kitchenIp: kitchenIp,
        port: cashierPort,
        printerName: printerName,
        mode: printerName ? 'windows' : 'ip'
      })
    });
    const data = await res.json();
    if (data.success) {
      alert(`✅ تم إرسال أمر الطباعة التجريبي للطابعتين معاً بنجاح:\n- طابعة 1 (الكاشير): ${printerName ? printerName : cashierIp}\n- طابعة 2 (المطبخ): ${kitchenIp}`);
    } else {
      alert("❌ حدث خطأ في أحد الطابعتين أو كلاهما: " + (data.error || "تحقق من اتصال الشبكة للطابعات"));
    }
  } catch (err) {
    alert("❌ تعذر الوصول لوسيط الطباعة المحلي. تأكد من تشغيل ملف 'تشغيل_وسيط_الطباعة.bat' أولاً.");
  }
}

function closePrinterSettingsModal() {
  const modal = document.getElementById('printer-settings-modal');
  if (modal) modal.classList.add('hidden');
}

function savePrinterSettingsFromModal() {
  const sizeChecked = document.querySelector('input[name="printer-size-radio"]:checked');
  const typeChecked = document.querySelector('input[name="printer-type-radio"]:checked');
  const cashierIp = (document.getElementById('ps-cashier-ip')?.value || '192.168.1.100').trim();
  const cashierPort = parseInt(document.getElementById('ps-cashier-port')?.value || '9100', 10);
  const kitchenIp = (document.getElementById('ps-kitchen-ip')?.value || '192.168.1.101').trim();
  const kitchenPort = parseInt(document.getElementById('ps-kitchen-port')?.value || '9100', 10);
  const cashierPrinter = document.getElementById('ps-cashier-printer-select')?.value || '';
  const silentPrint = document.getElementById('ps-silent-toggle')?.checked ?? true;

  const current = getPrintSettings();
  const settings = {
    ...current,
    paperSize: sizeChecked ? sizeChecked.value : '80mm',
    ticketType: typeChecked ? typeChecked.value : 'customer',
    cashierMode: cashierPrinter ? 'windows' : 'ip',
    cashierIp: cashierIp,
    cashierPort: cashierPort,
    cashierPrinterName: cashierPrinter,
    kitchenMode: 'ip',
    kitchenIp: kitchenIp,
    kitchenPort: kitchenPort,
    silentPrint: silentPrint,
    autoDirectPrint: true
  };

  savePrintSettings(settings);
  closePrinterSettingsModal();
  alert(`✅ تم حفظ إعدادات الطابعات بنجاح!\n- طابعة 1 (الكاشير): ${cashierPrinter ? cashierPrinter : cashierIp}\n- طابعة 2 (المطبخ): ${kitchenIp}\n- نظام الطباعة الصامتة نشط.`);
}

// =============================================================

function getAccountingReport(filterPreset = 'today', customDateStr = null) {
  const activeOrders = getStoredData('orders', []);
  const archivedOrders = getStoredData('accounting_archive', []);
  const orderMap = new Map();
  archivedOrders.forEach(o => { if (o && o.id) orderMap.set(String(o.id), o); });
  activeOrders.forEach(o => { if (o && o.id) orderMap.set(String(o.id), o); });
  const orders = Array.from(orderMap.values());
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const now = new Date();
  
  // تحديد نطاق التاريخ
  let startDate = new Date();
  let endDate = new Date();
  let reportTitle = "تقرير مبيعات اليوم";

  if (customDateStr) {
    const parts = customDateStr.split('-');
    startDate = new Date(parts[0], parts[1] - 1, parts[2], 0, 0, 0, 0);
    endDate = new Date(parts[0], parts[1] - 1, parts[2], 23, 59, 59, 999);
    reportTitle = `تقرير يوم: ${customDateStr}`;
  } else if (filterPreset === 'today') {
    startDate.setHours(0, 0, 0, 0);
    endDate.setHours(23, 59, 59, 999);
    reportTitle = `تقرير مبيعات اليوم (${now.toLocaleDateString('ar-IQ')})`;
  } else if (filterPreset === 'yesterday') {
    startDate.setDate(startDate.getDate() - 1);
    startDate.setHours(0, 0, 0, 0);
    endDate.setDate(endDate.getDate() - 1);
    endDate.setHours(23, 59, 59, 999);
    reportTitle = "تقرير مبيعات الأمس";
  } else if (filterPreset === 'week') {
    startDate.setDate(startDate.getDate() - 7);
    startDate.setHours(0, 0, 0, 0);
    reportTitle = "تقرير آخر 7 أيام";
  } else if (filterPreset === 'month') {
    startDate.setDate(1);
    startDate.setHours(0, 0, 0, 0);
    reportTitle = "تقرير الشهر الحالي";
  } else if (filterPreset === 'all') {
    startDate = new Date(0);
    reportTitle = "التقرير المالي الشامل (كافة الفترات)";
  }

  // تصفية الطلبات
  const filteredOrders = orders.filter(o => {
    const oTime = o.timestamp ? new Date(o.timestamp) : new Date(o.createdAt || Date.now());
    return oTime >= startDate && oTime <= endDate;
  });

  // الحسابات المالية
  let totalRevenue = 0;
  let dineInSales = 0;
  let dineInCount = 0;
  let takeawaySales = 0;
  let takeawayCount = 0;
  let deliverySales = 0;
  let deliveryCount = 0;

  const dishMap = {};

  filteredOrders.forEach(o => {
    const orderTotal = parseFloat(o.total) || 0;
    totalRevenue += orderTotal;

    const type = (o.type || '').toLowerCase();
    if (type === 'dinein' || type === 'dine-in' || o.tableNumber) {
      dineInSales += orderTotal;
      dineInCount++;
    } else if (type === 'delivery') {
      deliverySales += orderTotal;
      deliveryCount++;
    } else {
      takeawaySales += orderTotal;
      takeawayCount++;
    }

    if (Array.isArray(o.items)) {
      o.items.forEach(item => {
        const dishId = item.id || item.name;
        if (!dishMap[dishId]) {
          dishMap[dishId] = {
            id: item.id,
            name: item.name,
            price: item.price || 0,
            quantity: 0,
            totalRevenue: 0
          };
        }
        const q = parseInt(item.quantity) || 1;
        const p = parseFloat(item.price) || 0;
        dishMap[dishId].quantity += q;
        dishMap[dishId].totalRevenue += (q * p);
      });
    }
  });

  const topDishes = Object.values(dishMap).sort((a, b) => b.totalRevenue - a.totalRevenue);
  const avgOrderValue = filteredOrders.length > 0 ? Math.round(totalRevenue / filteredOrders.length) : 0;

  return {
    title: reportTitle,
    generatedAt: new Date().toLocaleString('ar-IQ'),
    startDate: startDate.toLocaleDateString('ar-IQ'),
    endDate: endDate.toLocaleDateString('ar-IQ'),
    currency: config.currency,
    restaurantName: config.name,
    totalRevenue,
    totalOrders: filteredOrders.length,
    dineInSales,
    dineInCount,
    takeawaySales,
    takeawayCount,
    deliverySales,
    deliveryCount,
    avgOrderValue,
    topDishes,
    orders: filteredOrders
  };
}

function getEndOfDayTicketHtml(report) {
  const settings = getPrintSettings();
  const is58mm = settings.paperSize === '58mm';
  const widthClass = is58mm ? 'max-w-[58mm] text-[10px]' : 'max-w-[80mm] text-xs';

  let dishesRows = report.topDishes.map((d, i) => `
    <tr style="border-bottom: 1px dashed #bbb; font-size: ${is58mm ? '9px' : '11px'};">
      <td style="padding: 3px 0; text-align: right;">${i + 1}. ${d.name}</td>
      <td style="padding: 3px 0; text-align: center; font-weight: bold;">×${d.quantity}</td>
      <td style="padding: 3px 0; text-align: left; font-weight: bold;">${d.totalRevenue.toLocaleString()}</td>
    </tr>
  `).join('');

  if (!dishesRows) {
    dishesRows = `<tr><td colspan="3" style="text-align: center; padding: 10px; color: #888;">لا توجد مبيعات مسجلة لهذه الفترة</td></tr>`;
  }

  return `
    <div class="thermal-ticket ${widthClass}" style="margin: 0 auto; padding: 8px; font-family: monospace, sans-serif; color: #000; background: #fff; direction: rtl; text-align: right;">
      <div style="text-align: center; border-bottom: 2px dashed #000; padding-bottom: 8px; margin-bottom: 8px;">
        <h2 style="font-size: ${is58mm ? '13px' : '16px'}; font-weight: 900; margin: 0;">${report.restaurantName}</h2>
        <div style="font-size: ${is58mm ? '10px' : '12px'}; font-weight: bold; margin-top: 4px; background: #000; color: #fff; padding: 2px 6px; border-radius: 4px; display: inline-block;">
          📋 تقرير نهاية اليوم (Z-Report)
        </div>
        <div style="font-size: 10px; margin-top: 4px; color: #444;">
          الفترة: ${report.title}
        </div>
        <div style="font-size: 9px; color: #666;">
          وقت الطباعة: ${report.generatedAt}
        </div>
      </div>

      <!-- الملخص المالي -->
      <div style="border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; font-size: ${is58mm ? '10px' : '11px'};">
        <div style="display: flex; justify-content: space-between; font-weight: bold; margin-bottom: 3px;">
          <span>إجمالي المبيعات الكلية:</span>
          <span style="font-size: ${is58mm ? '12px' : '14px'}; font-weight: 900;">${report.totalRevenue.toLocaleString()} ${report.currency}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 2px; color: #333;">
          <span>عدد الفواتير المنفذة:</span>
          <span style="font-weight: bold;">${report.totalOrders} طلب</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 2px; color: #333;">
          <span>متوسط قيمة الفاتورة:</span>
          <span style="font-weight: bold;">${report.avgOrderValue.toLocaleString()} ${report.currency}</span>
        </div>
      </div>

      <!-- تفصيل القنوات -->
      <div style="border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; font-size: 10px;">
        <div style="font-weight: bold; margin-bottom: 3px;">📊 تفصيل قنوات البيع:</div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
          <span>🍽️ مبيعات الصالة (${report.dineInCount} طلب):</span>
          <span style="font-weight: bold;">${report.dineInSales.toLocaleString()} ${report.currency}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
          <span>🛵 مبيعات التوصيل والسفري (${report.takeawayCount + report.deliveryCount} طلب):</span>
          <span style="font-weight: bold;">${(report.takeawaySales + report.deliverySales).toLocaleString()} ${report.currency}</span>
        </div>
      </div>

      <!-- الأصناف المباعة -->
      <div style="border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 8px;">
        <div style="font-weight: bold; font-size: 10px; margin-bottom: 4px;">🍽️ الأصناف الأكثر مبيعاً:</div>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="border-bottom: 1px solid #000; font-size: 9px; font-weight: bold;">
              <th style="text-align: right; padding-bottom: 2px;">الصنف</th>
              <th style="text-align: center; padding-bottom: 2px;">الكمية</th>
              <th style="text-align: left; padding-bottom: 2px;">المجموع</th>
            </tr>
          </thead>
          <tbody>
            ${dishesRows}
          </tbody>
        </table>
      </div>

      <!-- التوقيع والإغلاق -->
      <div style="text-align: center; font-size: 9px; color: #555; margin-top: 10px;">
        <div style="display: flex; justify-content: space-between; margin-top: 15px; padding-top: 15px; border-top: 1px dotted #888;">
          <span>توقيع الكاشير: ...............</span>
          <span>توقيع المدير: ...............</span>
        </div>
        <div style="margin-top: 10px; font-weight: bold; font-size: 8px;">
          تم استخراج التقرير بواسطة نظام Smart E-Menu (emattec 07702265652)
        </div>
      </div>
    </div>
  `;
}

function printEndOfDayReportDirect(filterPreset = 'today', customDateStr = null) {
  const report = getAccountingReport(filterPreset, customDateStr);
  const ticketHtml = getEndOfDayTicketHtml(report);

  let printContainer = document.getElementById('kitchen-print-ticket');
  if (!printContainer) {
    printContainer = document.createElement('div');
    printContainer.id = 'kitchen-print-ticket';
    printContainer.className = 'print-only';
    document.body.appendChild(printContainer);
  }

  printContainer.innerHTML = ticketHtml;
  setTimeout(() => {
    window.print();
  }, 100);
}

function exportAccountingReportCSV(filterPreset = 'today', customDateStr = null) {
  const report = getAccountingReport(filterPreset, customDateStr);
  
  let csvContent = "\uFEFF"; // UTF-8 BOM for Arabic support in Excel
  csvContent += `تقرير مبيعات المطعم,${report.restaurantName}\n`;
  csvContent += `الفترة,${report.title}\n`;
  csvContent += `تاريخ التوليد,${report.generatedAt}\n\n`;
  
  csvContent += "المؤشر المالي,القيمة,العملة\n";
  csvContent += `إجمالي المبيعات الكلية,${report.totalRevenue},${report.currency}\n`;
  csvContent += `عدد الطلبات والفواتير,${report.totalOrders},طلب\n`;
  csvContent += `مبيعات الصالة,${report.dineInSales},${report.currency}\n`;
  csvContent += `مبيعات التوصيل والسفري,${report.takeawaySales + report.deliverySales},${report.currency}\n`;
  csvContent += `متوسط قيمة الفاتورة,${report.avgOrderValue},${report.currency}\n\n`;

  csvContent += "الأصناف الأكثر مبيعاً:\n";
  csvContent += "اسم الصنف,الكمية المباعة,سعر الوحدة,إجمالي الإيراد\n";
  report.topDishes.forEach(d => {
    csvContent += `"${d.name}",${d.quantity},${d.price},${d.totalRevenue}\n`;
  });

  csvContent += "\nسجل الفواتير التفصيلي:\n";
  csvContent += "رقم الطلب,الوقت والتاريخ,نوع الطلب,المبلغ الإجمالي,الحالة\n";
  report.orders.forEach(o => {
    const oTime = o.timestamp ? new Date(o.timestamp).toLocaleTimeString('ar-IQ') : '-';
    csvContent += `"${o.id || '-'}",${oTime},"${o.type || '-'}",${o.total || 0},"${o.status || '-'}"\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `EOD_Report_${report.restaurantName}_${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// -------------------------------------------------------------
// 10. دوال إدارة صور الأطباق (معاينة، رفع من الجهاز، وتنزيل)
// -------------------------------------------------------------
function handleDishImageUpload(fileInput, targetUrlInputId, previewImgId) {
  if (!fileInput || !fileInput.files || fileInput.files.length === 0) return;
  const file = fileInput.files[0];

  // التحقق من أن الملف صورة
  if (!file.type.startsWith('image/')) {
    alert("يرجى اختيار ملف صورة صالح (PNG, JPG, WEBP) 📸");
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    const base64Data = e.target.result;
    const urlInput = document.getElementById(targetUrlInputId);
    const previewImg = document.getElementById(previewImgId);

    if (urlInput) urlInput.value = base64Data;
    if (previewImg) previewImg.src = base64Data;
  };
  reader.readAsDataURL(file);
}

function updateDishImagePreview(url, previewImgId) {
  const previewImg = document.getElementById(previewImgId);
  if (!previewImg) return;
  if (url && url.trim()) {
    previewImg.src = url.trim();
  } else {
    previewImg.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=120';
  }
}

async function downloadCurrentDishImage(urlInputId, nameInputId) {
  const urlInput = document.getElementById(urlInputId);
  const nameInput = document.getElementById(nameInputId);
  
  const imgUrl = urlInput ? urlInput.value.trim() : '';
  const dishName = (nameInput ? nameInput.value.trim() : '') || 'dish-image';

  if (!imgUrl) {
    alert("لا توجد صورة محددة لتنزيلها حالياً! 📸");
    return;
  }

  try {
    if (imgUrl.startsWith('data:image/')) {
      // صورة Base64 مرفوعة من الجهاز
      const a = document.createElement('a');
      a.href = imgUrl;
      a.download = `${dishName}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      // صورة من رابط إنترنت (URL)
      const response = await fetch(imgUrl);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = `${dishName}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
    }
  } catch (err) {
    // في حال وجود قيود CORS في بعض الروابط الخارجية، يتم فتح الصورة في نافذة جديدة
    window.open(imgUrl, '_blank');
  }
}

// تشغيل التهيئة
initDatabase();


/* === qr.js === */
/**
 * Smart E-Menu - Table QR Generator & Image Downloader
 * توليد باركود الطاولات استناداً لرابط موقع المطعم وتنزيل الصور للطباعة
 */

function getMenuTargetBaseUrl() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  if (config.publishedUrl && config.publishedUrl.trim()) {
    let url = config.publishedUrl.trim();
    // إزالة علامة / أو index.html من النهاية لضمان التنسيق
    url = url.replace(/\/index\.html$/i, '').replace(/\/$/, '');
    return url;
  }
  // في حال لم يتم تحديد رابط النشر، استخدام الرابط الحالي
  return window.location.origin + window.location.pathname.replace(/\/admin\.html$/i, '').replace(/\/cashier\.html$/i, '').replace(/\/captain\.html$/i, '').replace(/\/$/, '');
}

function generateTableQRCode(tableNumber) {
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : (typeof DEFAULT_RESTAURANT_ID !== 'undefined' ? DEFAULT_RESTAURANT_ID : 'fahma_dokhan');
  const baseUrl = getMenuTargetBaseUrl();
  
  let targetUrl = '';
  try {
    const fullBase = baseUrl.startsWith('http') ? baseUrl : (window.location.origin + (baseUrl.startsWith('/') ? '' : '/') + baseUrl);
    const parsed = new URL(fullBase);
    parsed.pathname = parsed.pathname.replace(/\/index\.html$/i, '').replace(/\/$/, '') + '/index.html';
    parsed.searchParams.set('rest', restId);
    if (tableNumber !== null && tableNumber !== undefined && tableNumber !== '' && tableNumber !== 0) {
      parsed.searchParams.set('table', tableNumber);
    } else {
      parsed.searchParams.delete('table');
    }
    targetUrl = parsed.toString();
  } catch (e) {
    const cleanBase = baseUrl.replace(/\/index\.html$/i, '').replace(/\/$/, '');
    const tableParam = (tableNumber !== null && tableNumber !== undefined && tableNumber !== '' && tableNumber !== 0) ? `&table=${tableNumber}` : '';
    targetUrl = `${cleanBase}/index.html?rest=${encodeURIComponent(restId)}${tableParam}`;
  }
  
  // توليد صورة باركود عالية الدقة والوضوح قابلة للطباعة
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(targetUrl)}&color=0b1120&bgcolor=ffffff&margin=2`;
  
  return {
    tableNumber,
    targetUrl,
    qrImageUrl
  };
}

function renderTableQRCardsContainer(containerId, customCount = null) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan';
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const tablesCount = customCount !== null ? parseInt(customCount) : (parseInt(config.tablesCount) || 20);

  let html = '';

  // 1. بطاقة الباركود العام للمطعم (للسفري / التوصيل / الملصقات الإعلانية / واجهة المحل)
  const generalQR = generateTableQRCode(null);
  html += `
    <div class="bg-gradient-to-b from-rose-50 to-white text-slate-900 rounded-3xl p-5 shadow-xl border-2 border-rose-500 text-center flex flex-col items-center justify-between relative group transition">
      <div class="w-full border-b border-rose-200 pb-2 mb-3">
        <div class="inline-block px-2.5 py-0.5 bg-rose-600 text-white rounded-full text-[10px] font-black tracking-wider mb-1 shadow-sm">⭐ الباركود العام</div>
        <div class="text-[11px] font-extrabold text-rose-700 tracking-wider">${config.name}</div>
        <div class="text-base font-black text-slate-900 mt-0.5">منيو المطعم العام (سفري / صالة)</div>
      </div>

      <div class="p-2 bg-white rounded-2xl shadow-inner border border-rose-200 mb-3 relative">
        <img src="${generalQR.qrImageUrl}" alt="QR General" class="w-40 h-40 mx-auto object-contain" loading="lazy" />
      </div>

      <div class="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded-lg mb-2 max-w-full truncate dir-ltr" title="${generalQR.targetUrl}">
        ${generalQR.targetUrl}
      </div>

      <div class="text-[11px] text-slate-600 font-medium mb-3 leading-tight">
        امسح الرمز لتصفح المنيو بدون تحديد طاولة (مناسب لطلبات السفري والمدخل) 📱🍽️
      </div>

      <div class="flex gap-2 w-full pt-2 border-t border-rose-100">
        <button onclick="downloadQRCodeImageDirectly(0, '${generalQR.qrImageUrl}')" class="flex-1 py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow">
          <span>تنزيل صورة</span>
          <span>💾</span>
        </button>
        <button onclick="printSingleTableQR(0, '${generalQR.qrImageUrl}', '${generalQR.targetUrl}')" class="py-2 px-3 bg-white text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-bold transition border border-rose-300">
          🖨️ طباعة
        </button>
      </div>
    </div>
  `;

  // 2. بطاقات باركود الطاولات من طاولة 1 إلى الحد الأقصى
  for (let i = 1; i <= tablesCount; i++) {
    const qrData = generateTableQRCode(i);
    html += `
      <div class="bg-white text-slate-900 rounded-3xl p-5 shadow-xl border-2 border-slate-200 text-center flex flex-col items-center justify-between relative group hover:border-rose-500 transition">
        
        <div class="w-full border-b border-slate-200 pb-2 mb-3">
          <div class="text-[11px] font-extrabold text-rose-600 tracking-wider">${config.name}</div>
          <div class="text-xl font-black text-slate-900 mt-0.5">طاولة رقم [ ${i} ]</div>
        </div>

        <div class="p-2 bg-white rounded-2xl shadow-inner border border-slate-200 mb-3 relative">
          <img src="${qrData.qrImageUrl}" alt="QR Table ${i}" class="w-40 h-40 mx-auto object-contain" loading="lazy" />
        </div>

        <div class="text-[10px] font-mono text-slate-400 bg-slate-50 px-2 py-0.5 rounded mb-2 max-w-full truncate dir-ltr" title="${qrData.targetUrl}">
          ${qrData.targetUrl}
        </div>

        <div class="text-[11px] text-slate-600 font-medium mb-3 leading-tight">
          امسح الرمز لعرض المنيو والطلب من طاولة ${i} مباشرة 🍽️
        </div>

        <div class="flex gap-2 w-full pt-2 border-t border-slate-100">
          <button onclick="downloadQRCodeImageDirectly(${i}, '${qrData.qrImageUrl}')" class="flex-1 py-2 px-3 bg-slate-900 hover:bg-rose-600 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow">
            <span>تنزيل صورة</span>
            <span>💾</span>
          </button>
          <button onclick="printSingleTableQR(${i}, '${qrData.qrImageUrl}', '${qrData.targetUrl}')" class="py-2 px-3 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-xl text-xs font-bold transition border border-rose-200">
            🖨️ طباعة
          </button>
        </div>

      </div>
    `;
  }
  container.innerHTML = html;
}

// تنزيل صورة الباركود كملف PNG/JPG بجودة عالية
function downloadQRCodeImageDirectly(tableNumber, qrImageUrl) {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const label = (tableNumber && tableNumber !== 0) ? `طاولة-${tableNumber}` : 'المنيو-العام';
  
  // إنشاء رابط تحميل مباشر
  fetch(qrImageUrl)
    .then(response => response.blob())
    .then(blob => {
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = blobUrl;
      a.download = `QR-${label}-${config.name.replace(/\s+/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(blobUrl);
      document.body.removeChild(a);
    })
    .catch(() => {
      window.open(qrImageUrl, '_blank');
    });
}

function printSingleTableQR(tableNumber, qrUrl, targetUrl = '') {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const isGeneral = (!tableNumber || tableNumber === 0);
  const titleText = isGeneral ? 'منيو المطعم الرقمي (سفري / صالة)' : `طاولة رقم [ ${tableNumber} ]`;
  const hintText = isGeneral 
    ? 'امسح الباركود بكاميرا هاتفك لتصفح المنيو والطلب مباشرة 📱🍽️' 
    : `امسح الباركود بكاميرا هاتفك لتصفح المنيو والطلب من طاولة ${tableNumber} مباشرة 📱🍽️`;

  const printWindow = window.open('', '_blank', 'width=500,height=680');
  printWindow.document.write(`
    <!DOCTYPE html>
    <html dir="rtl">
    <head>
      <title>${titleText} - ${config.name}</title>
      <style>
        body { font-family: system-ui, -apple-system, sans-serif; text-align: center; padding: 30px; margin: 0; background: #fff; }
        .card { border: 3px solid #e11d48; border-radius: 24px; padding: 25px; max-width: 320px; margin: 0 auto; box-shadow: 0 4px 15px rgba(0,0,0,0.08); }
        .logo { font-size: 16px; font-weight: bold; color: #e11d48; margin-bottom: 4px; }
        .title { font-size: 22px; font-weight: 900; margin-bottom: 12px; color: #0f172a; }
        .qr { width: 220px; height: 220px; margin: 8px auto; display: block; }
        .hint { font-size: 12px; color: #475569; margin-top: 12px; font-weight: 500; }
        .url { font-size: 9px; font-family: monospace; color: #94a3b8; margin-top: 8px; direction: ltr; word-break: break-all; }
        .footer { font-size: 10px; color: #94a3b8; margin-top: 12px; border-top: 1px dashed #cbd5e1; padding-top: 8px; }
        @media print { body { padding: 0; } }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="logo">${config.name}</div>
        <div class="title">${titleText}</div>
        <img src="${qrUrl}" class="qr" onload="window.print();" />
        <div class="hint">${hintText}</div>
        ${targetUrl ? `<div class="url">${targetUrl}</div>` : ''}
        <div class="footer">المنيو الرقمي الذكي - نظام إدارة المطاعم</div>
      </div>
    </body>
    </html>
  `);
  printWindow.document.close();
}

/* === admin.js === */
/**
 * Smart E-Menu - Super Admin & Kitchen Management Module
 * لوحة التحكم الشاملة لصاحب المطعم: إدارة الأصناف، الكباتن، المطبخ، والنسخ الاحتياطي
 */

// -------------------------------------------------------------
// درج القائمة الجانبي للأدمن (--- زر)
// -------------------------------------------------------------
function openAdminMenuSidebar() {
  const m = document.getElementById('admin-menu-sidebar');
  if (m) { m.classList.remove('hidden'); document.body.style.overflow = 'hidden'; }
}
function closeASidebar() {
  const m = document.getElementById('admin-menu-sidebar');
  if (m) { m.classList.add('hidden'); document.body.style.overflow = 'auto'; }
}

document.addEventListener('DOMContentLoaded', () => {
  if (typeof fetchUsersFromSupabase === 'function') fetchUsersFromSupabase();
  initSuperAdmin();
});

function initSuperAdmin() {
  const loginView = document.getElementById('admin-login-view');
  const dashView = document.getElementById('admin-dashboard-view');
  if (!loginView && !dashView) return; // ليس في صفحة الأدمن

  const session = getCurrentSession();

  // فحص تسجيل دخول الأدمن
  if (!session || session.role !== 'admin') {
    showAdminLoginScreen();
    return;
  }

  showAdminDashboard();
}

function showAdminLoginScreen() {
  const loginView = document.getElementById('admin-login-view');
  const dashView = document.getElementById('admin-dashboard-view');
  if (loginView) loginView.classList.remove('hidden');
  if (dashView) dashView.classList.add('hidden');

  // إفراغ حقول الدخول تماماً لضمان الخصوصية والأمان
  const usernameInput = document.getElementById('superadmin-username-input');
  const pinInput = document.getElementById('superadmin-pin-input');
  const rememberCheckbox = document.getElementById('superadmin-remember-me');
  if (usernameInput) usernameInput.value = '';
  if (pinInput) pinInput.value = '';
  if (rememberCheckbox) rememberCheckbox.checked = false;
}

async function handleSuperAdminLogin(event) {
  if (event) event.preventDefault();
  const usernameInput = document.getElementById('superadmin-username-input');
  const input = document.getElementById('superadmin-pin-input');
  const errorEl = document.getElementById('superadmin-login-error');
  const rememberCheckbox = document.getElementById('superadmin-remember-me');
  const btn = document.getElementById('admin-login-btn');

  const username = usernameInput ? usernameInput.value.trim() : '';
  const pin = input ? input.value : '';
  const rememberMe = rememberCheckbox ? rememberCheckbox.checked : false;

  if (!username) {
    if (errorEl) {
      errorEl.textContent = 'يرجى إدخال اسم المستخدم!';
      errorEl.classList.remove('hidden');
    }
    return;
  }

  if (btn) btn.textContent = 'جاري التحقق... ⏳';

  const res = typeof loginUserAsync === 'function' 
    ? await loginUserAsync(username, pin, rememberMe) 
    : { success: false, message: 'تعذر التحقق من تسجيل الدخول' };
  
  if (btn) btn.textContent = 'تسجيل الدخول 🚀';

  if (res.success) {
    if (errorEl) errorEl.classList.add('hidden');

    const activeRest = res.restaurantId || (typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan');
    const restParam = activeRest ? `?rest=${encodeURIComponent(activeRest)}` : '';

    if (res.role === 'cashier') {
      window.location.href = 'cashier.html' + restParam;
      return;
    } else if (res.role === 'captain') {
      window.location.href = 'captain.html' + restParam;
      return;
    } else if (res.role === 'super_admin' || res.role === 'assistant_super_admin') {
      window.location.href = 'super-admin.html';
      return;
    }
    showAdminDashboard();
  } else {
    if (errorEl) {
      errorEl.textContent = res.message;
      errorEl.classList.remove('hidden');
    }
  }
}

function showAdminDashboard() {
  const loginView = document.getElementById('admin-login-view');
  const dashView = document.getElementById('admin-dashboard-view');
  if (loginView) loginView.classList.add('hidden');
  if (dashView) dashView.classList.remove('hidden');

  loadAdminOrders();
  loadAdminDishes();
  loadAdminCaptains();
  loadAdminSettings();
  
  if (typeof renderTableQRCardsContainer === 'function') {
    loadAdminQR();
  }
}

function loadAdminQR() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const count = parseInt(config.tablesCount) || 20;
  const countInput = document.getElementById('admin-qr-tables-count');
  if (countInput) countInput.value = count;
  renderTableQRCardsContainer('admin-qr-grid', count);
}

function updateQRTablesCountFromAdmin(newCount) {
  const count = parseInt(newCount) || 20;
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  config.tablesCount = count;
  setStoredData('config', config);
  
  const settingInput = document.getElementById('setting-tables');
  if (settingInput) settingInput.value = count;

  renderTableQRCardsContainer('admin-qr-grid', count);
}

// -------------------------------------------------------------
// إدارة طاقم العمل والكاشير والكباتن (Staff & Users Management)
// -------------------------------------------------------------
async function loadAdminCaptains() {
  const container = document.getElementById('admin-captains-table-body');
  if (!container) return;

  if (typeof fetchUsersFromSupabase === 'function') {
    await fetchUsersFromSupabase();
  }

  const auth = getAuthConfig();
  const allStaff = [];

  // 1. إضافة الكاشير
  if (auth.cashiers && auth.cashiers.length > 0) {
    auth.cashiers.forEach(c => allStaff.push({ ...c, role: 'cashier' }));
  }

  // 2. إضافة الكباتن
  if (auth.captains && auth.captains.length > 0) {
    auth.captains.forEach(c => allStaff.push({ ...c, role: 'captain' }));
  }

  if (allStaff.length === 0) {
    container.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-6 text-slate-500">لا يوجد موظفين مسجلين حالياً</td>
      </tr>
    `;
    return;
  }

  container.innerHTML = allStaff.map(member => {
    const isCashier = member.role === 'cashier';
    const roleBadge = isCashier
      ? `<span class="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-lg font-bold text-[11px] flex items-center gap-1 w-fit">💻 كاشير المطعم</span>`
      : `<span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2.5 py-0.5 rounded-lg font-bold text-[11px] flex items-center gap-1 w-fit">👨‍🍳 كابتن صالة</span>`;

    return `
      <tr class="border-b border-slate-800 hover:bg-slate-800/40 transition">
        <td class="p-3">
          <div class="font-bold text-white text-sm flex items-center gap-2">
            <span>${member.name}</span>
          </div>
        </td>
        <td class="p-3">
          ${roleBadge}
        </td>
        <td class="p-3">
          <span class="font-mono text-slate-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">${member.username || '-'}</span>
        </td>
        <td class="p-3">
          <span class="font-mono bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-rose-400 font-bold text-xs">${member.pin}</span>
        </td>
        <td class="p-3">
          <button onclick="handleToggleStaffStatus('${member.id}', '${member.role}')" class="px-3 py-1 rounded-full text-xs font-bold transition ${member.active ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30'}">
            ${member.active ? 'مفعل (نشط) ✅' : 'معطل (موقوف) ❌'}
          </button>
        </td>
        <td class="p-3 text-left">
          <div class="flex items-center gap-1.5 justify-end">
            <button onclick="openEditStaffModal('${member.id}', '${member.role}')" class="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold transition flex items-center gap-1">
              <span>✏️ تعديل</span>
            </button>
            <button onclick="handleDeleteStaff('${member.id}', '${member.role}')" class="py-1 px-2.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-lg text-xs font-bold transition flex items-center gap-1">
              <span>🗑️ حذف</span>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function openAddStaffModal() {
  document.getElementById('staff-modal-title').textContent = "إضافة موظف جديد (كاشير / كابتن)";
  document.getElementById('staff-form-id').value = "";
  document.getElementById('staff-form-role').value = "cashier";
  document.getElementById('staff-form-name').value = "";
  document.getElementById('staff-form-username').value = "";
  document.getElementById('staff-form-pin').value = "";
  document.getElementById('staff-edit-modal').classList.remove('hidden');
}

function openAddCaptainModal() {
  openAddStaffModal();
}

function openEditStaffModal(id, role = 'captain') {
  const auth = getAuthConfig();
  let member = null;

  if (role === 'cashier' && auth.cashiers) {
    member = auth.cashiers.find(x => x.id === id);
  } else if (auth.captains) {
    member = auth.captains.find(x => x.id === id);
  }

  if (!member) return;

  document.getElementById('staff-modal-title').textContent = `تعديل بيانات: ${member.name}`;
  document.getElementById('staff-form-id').value = member.id;
  document.getElementById('staff-form-role').value = member.role || role;
  document.getElementById('staff-form-name').value = member.name;
  document.getElementById('staff-form-username').value = member.username || '';
  document.getElementById('staff-form-pin').value = member.pin;
  document.getElementById('staff-edit-modal').classList.remove('hidden');
}

function openEditCaptainModal(id) {
  openEditStaffModal(id, 'captain');
}

function closeStaffModal() {
  document.getElementById('staff-edit-modal').classList.add('hidden');
}

function closeCaptainModal() {
  closeStaffModal();
}

async function saveStaffFromForm(e) {
  e.preventDefault();
  const id = document.getElementById('staff-form-id').value;
  const role = document.getElementById('staff-form-role').value;
  const name = document.getElementById('staff-form-name').value.trim();
  const username = document.getElementById('staff-form-username').value.trim();
  const pin = document.getElementById('staff-form-pin').value.trim();

  if (id) {
    const res = typeof updateStaffUserAsync === 'function'
      ? await updateStaffUserAsync(id, { name, username, pin, role })
      : { success: false, message: 'خطأ في التحديث' };
    if (!res.success) { alert(res.message); return; }
  } else {
    const res = typeof addStaffUserAsync === 'function' 
      ? await addStaffUserAsync(name, username, pin, role) 
      : { success: false, message: 'خطأ في الإضافة' };
    if (!res.success) { alert(res.message); return; }
  }

  closeStaffModal();
  loadAdminCaptains();
  alert("تم حفظ وتحديث بيانات الموظف بنجاح! ✅");
}

function saveCaptainFromForm(e) {
  saveStaffFromForm(e);
}

async function handleToggleStaffStatus(id, role = 'captain') {
  if (typeof toggleStaffUserActiveAsync === 'function') {
    await toggleStaffUserActiveAsync(id, role);
  } else if (typeof toggleCaptainActiveStateAsync === 'function') {
    await toggleCaptainActiveStateAsync(id);
  }
  loadAdminCaptains();
}

function handleToggleCaptainStatus(id) {
  handleToggleStaffStatus(id, 'captain');
}

async function handleDeleteStaff(id, role = 'captain') {
  if (confirm("هل أنت متأكد من حذف هذا الحساب نهائياً من النظام؟")) {
    if (typeof deleteStaffUserAsync === 'function') {
      await deleteStaffUserAsync(id);
    } else if (typeof deleteCaptainAsync === 'function') {
      await deleteCaptainAsync(id);
    }
    loadAdminCaptains();
  }
}

function handleDeleteCaptain(id) {
  handleDeleteStaff(id, 'captain');
}

async function handleUpdateAdminPin(e) {
  e.preventDefault();
  const newPinInput = document.getElementById('admin-new-pin');
  const newPin = newPinInput ? newPinInput.value.trim() : '';

  const res = typeof changeAdminPinAsync === 'function' ? await changeAdminPinAsync(newPin) : changeAdminPin(newPin);
  if (res.success) {
    alert("تم حفظ وتحديث الرمز السري الجديد بنجاح! ✅");
    if (newPinInput) newPinInput.value = '';
  } else {
    alert(res.message);
  }
}

// -------------------------------------------------------------
// إدارة النسخ الاحتياطي واستيراد/تصدير البيانات (Backup / Restore)
// -------------------------------------------------------------
function triggerDatabaseExport() {
  const res = exportFullDatabaseBackup();
  if (res.success) {
    alert(`✅ تم تنزيل ملف النسخة الاحتياطية (${res.filename}) بنجاح على جهازك! احتفظ به دائماً لحماية بياناتك.`);
  }
}

function triggerDatabaseImport() {
  const fileInput = document.getElementById('backup-file-input');
  if (!fileInput || !fileInput.files[0]) {
    alert("يرجى اختيار ملف النسخة الاحتياطية (JSON) أولاً!");
    return;
  }

  if (confirm("⚠️ تنبيه: استرجاع النسخة الاحتياطية سيقوم بتحديث كافة الأصناف والأسعار والإعدادات الحالية. هل تود المتابعة؟")) {
    importDatabaseBackup(fileInput.files[0], (res) => {
      alert(res.message);
      if (res.success) {
        location.reload();
      }
    });
  }
}

// -------------------------------------------------------------
// إدارة الطلبات وشاشة المطبخ (Orders & Kitchen Screen)
// -------------------------------------------------------------
function loadAdminOrders(filterStatus = 'all') {
  const ordersListEl = document.getElementById('admin-orders-list');
  const emptyEl = document.getElementById('admin-orders-empty');
  if (!ordersListEl) return;

  const orders = getStoredData('orders', []);
  
  let filtered = orders;
  if (filterStatus !== 'all') {
    filtered = orders.filter(o => o.status === filterStatus);
  }

  if (filtered.length === 0) {
    ordersListEl.innerHTML = '';
    if (emptyEl) emptyEl.classList.remove('hidden');
    return;
  }

  if (emptyEl) emptyEl.classList.add('hidden');

  let html = '';
  filtered.forEach(order => {
    const isDineIn = order.type === 'dine-in';
    const statusBadge = getOrderStatusBadge(order.status);
    const dateFormatted = new Date(order.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

    let itemsRows = '';
    order.items.forEach(item => {
      itemsRows += `
        <div class="flex justify-between items-center py-1 border-b border-slate-700/40 text-xs">
          <div class="flex items-center gap-1.5">
            <span class="bg-rose-500/20 text-rose-400 font-bold px-1.5 py-0.5 rounded text-[11px]">x${item.quantity}</span>
            <span class="font-bold text-slate-100">${item.name}</span>
          </div>
          <span class="text-slate-400">${(item.price * item.quantity).toLocaleString()} ${order.currency || 'د.ع'}</span>
        </div>
      `;
    });

    html += `
      <div class="glass-card rounded-2xl p-4 border border-slate-700/60 relative flex flex-col justify-between">
        <div>
          <div class="flex items-start justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
            <div>
              <div class="flex items-center gap-2">
                <span class="text-[11px] font-mono text-slate-400">#${order.id}</span>
                <span class="text-[11px] text-slate-400">🕒 ${dateFormatted}</span>
              </div>
              <div class="text-base font-black text-white mt-0.5 flex items-center gap-1.5">
                ${isDineIn ? `🍽️ <span class="text-rose-400">طاولة رقم ${order.tableNumber}</span>` : `🛵 <span class="text-amber-400">طلب خارجي</span>`}
              </div>
              ${order.captainName ? `<div class="text-[11px] text-amber-300 font-bold">👨‍🍳 الكابتن: ${order.captainName}</div>` : ''}
            </div>
            <div>
              ${statusBadge}
            </div>
          </div>

          <div class="space-y-1 mb-3">
            ${itemsRows}
          </div>

          ${order.notes ? `
            <div class="p-2 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs text-amber-300 mb-3">
              📝 <b>ملاحظة:</b> ${order.notes}
            </div>
          ` : ''}
        </div>

        <div>
          <div class="flex justify-between items-center pt-2 border-t border-slate-800 mb-3">
            <span class="text-slate-400 text-xs">المجموع:</span>
            <span class="text-base font-black text-rose-400">${order.total.toLocaleString()} ${order.currency || 'د.ع'}</span>
          </div>

          <div class="grid grid-cols-2 gap-2">
            <button onclick="printKitchenTicketById('${order.id}')" class="bg-slate-800 hover:bg-slate-700 text-white py-1.5 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 border border-slate-600">
              <span>🖨️ طباعة</span>
            </button>

            ${order.status === 'new' ? `
              <button onclick="updateOrderStatus('${order.id}', 'preparing')" class="bg-amber-600 hover:bg-amber-500 text-white py-1.5 px-2 rounded-xl text-xs font-bold transition">
                <span>👨‍🍳 تحضير</span>
              </button>
            ` : order.status === 'preparing' ? `
              <button onclick="updateOrderStatus('${order.id}', 'completed')" class="bg-emerald-600 hover:bg-emerald-500 text-white py-1.5 px-2 rounded-xl text-xs font-bold transition">
                <span>✅ تم التجهيز</span>
              </button>
            ` : `
              <button onclick="reopenOrderToCashier('${order.id}')" class="bg-slate-700 hover:bg-rose-700 text-slate-200 hover:text-white py-1.5 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1">
                <span>🔄 إعادة فتح للكاشير</span>
              </button>
            `}
          </div>
        </div>
      </div>
    `;
  });

  ordersListEl.innerHTML = html;
}

function getOrderStatusBadge(status) {
  switch (status) {
    case 'new':
      return `<span class="bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[11px] font-black px-2 py-0.5 rounded-full animate-pulse">جديد 🔥</span>`;
    case 'preparing':
      return `<span class="bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[11px] font-black px-2 py-0.5 rounded-full">تحضير ⏳</span>`;
    case 'completed':
      return `<span class="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] font-black px-2 py-0.5 rounded-full">مكتمل ✅</span>`;
    default:
      return `<span class="bg-slate-700 text-slate-300 text-[11px] px-2 py-0.5 rounded-full">${status}</span>`;
  }
}

async function updateOrderStatus(orderId, newStatus) {
  const orders = getStoredData('orders', []);
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx !== -1) {
    orders[idx].status = newStatus;
    setStoredData('orders', orders);
    loadAdminOrders();
    window.dispatchEvent(new Event('storage'));

    const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
    const client = (typeof getSupabase === 'function') ? getSupabase() : null;

    if (client) {
      try {
        await client.from('restaurant_orders').update({
          status: newStatus,
          updated_at: new Date().toISOString()
        }).eq('id', String(orderId));
      } catch (e) {
        console.warn("Supabase updateOrderStatus error:", e);
      }
    }

    try {
      if ('BroadcastChannel' in window) {
        const bc = new BroadcastChannel('smart_emenu_channel');
        bc.postMessage({ type: 'ORDERS_CHANGED', orderId: orderId, status: newStatus });
        bc.close();
      }
    } catch (e) {}

    if (client) {
      try {
        const ch = client.channel(`orders_channel_${restId}`);
        ch.send({
          type: 'broadcast',
          event: 'table_order_update',
          payload: { orderId: orderId, status: newStatus }
        });
      } catch (e) {}
    }
  }
}
window.updateOrderStatus = updateOrderStatus;

async function reopenOrderToCashier(orderId) {
  if (!confirm("هل أنت متأكد من إعادة فتح هذا الطلب وإرجاعه إلى شاشة الكاشير للتعديل عليه؟")) {
    return;
  }

  const orders = getStoredData('orders', []);
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) {
    alert("لم يتم العثور على الطلب!");
    return;
  }

  const targetOrder = orders[idx];
  targetOrder.status = 'new';
  delete targetOrder.paidAt;

  setStoredData('orders', orders);

  const archive = getStoredData('accounting_archive', []);
  const archIdx = archive.findIndex(o => o && o.id === orderId);
  if (archIdx !== -1) {
    archive[archIdx].status = 'new';
    delete archive[archIdx].paidAt;
    setStoredData('accounting_archive', archive);
  }

  window.dispatchEvent(new Event('storage'));

  loadAdminOrders();
  if (typeof loadAdminAccounting === 'function') loadAdminAccounting();
  if (typeof renderStats === 'function') renderStats();

  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const client = (typeof getSupabase === 'function') ? getSupabase() : null;

  if (client) {
    try {
      await client.from('restaurant_orders').update({
        status: 'new',
        updated_at: new Date().toISOString()
      }).eq('id', String(orderId));
    } catch (e) {
      console.warn("Supabase reopenOrder error:", e);
    }
  }

  try {
    if ('BroadcastChannel' in window) {
      const bc = new BroadcastChannel('smart_emenu_channel');
      bc.postMessage({ 
        type: 'ORDER_REOPENED', 
        orderId: orderId,
        tableNumber: targetOrder.tableNumber,
        order: targetOrder
      });
      bc.postMessage({ type: 'ORDERS_CHANGED' });
      bc.close();
    }
  } catch (e) {}

  if (client) {
    try {
      const ch = client.channel(`orders_channel_${restId}`);
      await ch.send({
        type: 'broadcast',
        event: 'order_reopened',
        payload: {
          id: orderId,
          tableNumber: targetOrder.tableNumber,
          order: targetOrder
        }
      });
    } catch (e) {}
  }

  const tableInfo = targetOrder.tableNumber ? `لطاولة [ ${targetOrder.tableNumber} ]` : '';
  alert(`✅ تم إعادة فتح الطلب #${orderId} ${tableInfo} بنجاح!\nتم إرجاعه إلى شاشة الكاشير ليتمكن من التعديل عليه.`);
}
window.reopenOrderToCashier = reopenOrderToCashier;

function clearCompletedOrders() {
  if (confirm("هل أنت متأكد من حذف وأرشفة الطلبات المكتملة؟")) {
    const orders = getStoredData('orders', []);
    const active = orders.filter(o => o.status !== 'completed');
    setStoredData('orders', active);
    loadAdminOrders();
  }
}

function printKitchenTicketById(orderId) {
  const orders = getStoredData('orders', []);
  const order = orders.find(o => o.id === orderId);
  if (order) {
    renderAndPrintKitchenTicket(order);
  }
}

function renderAndPrintKitchenTicket(order) {
  if (typeof printOrderDirect === 'function') {
    printOrderDirect(order, 'kitchen');
  } else {
    window.print();
  }
}

// -------------------------------------------------------------
// إدارة الأصناف والأسعار (Dishes Management)
// -------------------------------------------------------------
function loadAdminDishes() {
  const tableBody = document.getElementById('admin-dishes-table-body');
  if (!tableBody) return;

  const dishes = getStoredData('dishes', DEFAULT_DISHES);
  const categories = getStoredData('categories', DEFAULT_CATEGORIES);
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);

  let html = '';
  dishes.forEach(dish => {
    const cat = categories.find(c => c.id === dish.categoryId) || { name: dish.categoryId };
    html += `
      <tr class="border-b border-slate-800 hover:bg-slate-800/40 transition text-xs">
        <td class="p-3">
          <img src="${dish.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100'}" class="w-10 h-10 rounded-xl object-cover border border-slate-700" loading="lazy" />
        </td>
        <td class="p-3">
          <div class="font-bold text-white">${dish.name}</div>
          <div class="text-[10px] text-slate-400">${dish.nameEn || ''}</div>
        </td>
        <td class="p-3">
          <span class="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">${cat.name}</span>
        </td>
        <td class="p-3">
          <span class="font-black text-rose-400">${dish.price.toLocaleString()} ${config.currency}</span>
        </td>
        <td class="p-3">
          <button onclick="toggleDishAvailability(${dish.id})" class="px-2 py-0.5 rounded-full text-[11px] font-bold transition ${dish.available ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'}">
            ${dish.available ? 'متوفر ✅' : 'نفذ ❌'}
          </button>
        </td>
        <td class="p-3 text-left">
          <div class="flex items-center gap-1.5 justify-end">
            <button onclick="editDishModal(${dish.id})" class="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs transition" title="تعديل">
              ✏️
            </button>
            <button onclick="deleteDish(${dish.id})" class="p-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-lg text-xs transition" title="حذف">
              🗑️
            </button>
          </div>
        </td>
      </tr>
    `;
  });

  tableBody.innerHTML = html;
}

function toggleDishAvailability(dishId) {
  const dishes = getStoredData('dishes', DEFAULT_DISHES);
  const idx = dishes.findIndex(d => d.id === dishId);
  if (idx !== -1) {
    dishes[idx].available = !dishes[idx].available;
    setStoredData('dishes', dishes);
    loadAdminDishes();
  }
}

function deleteDish(dishId) {
  if (confirm("هل أنت متأكد من حذف هذا الصنف من المنيو؟")) {
    let dishes = getStoredData('dishes', DEFAULT_DISHES);
    dishes = dishes.filter(d => d.id !== dishId);
    setStoredData('dishes', dishes);
    loadAdminDishes();
  }
}

function openAddDishModal() {
  const title = document.getElementById('dish-modal-title');
  if (title) title.textContent = "إضافة صنف جديد للمنيو";
  const form = document.getElementById('dish-form');
  if (form) form.reset();
  const idInput = document.getElementById('dish-form-id');
  if (idInput) idInput.value = "";
  const ingInput = document.getElementById('dish-form-ingredients');
  if (ingInput) ingInput.value = "";
  updateDishImagePreview('', 'dish-form-preview-img');
  populateCategorySelect();
  const modal = document.getElementById('dish-edit-modal');
  if (modal) modal.classList.remove('hidden');
}

function editDishModal(dishId) {
  const dishes = getStoredData('dishes', DEFAULT_DISHES);
  const dish = dishes.find(d => d.id == dishId);
  if (!dish) {
    alert("لم يتم العثور على بيانات الصنف!");
    return;
  }

  const title = document.getElementById('dish-modal-title');
  if (title) title.textContent = "تعديل بيانات الصنف: " + dish.name;
  
  populateCategorySelect(dish.categoryId);
  
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val !== undefined && val !== null ? val : '';
  };
  const setCheck = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.checked = !!val;
  };

  setVal('dish-form-id', dish.id);
  setVal('dish-form-name', dish.name);
  setVal('dish-form-name-en', dish.nameEn);
  setVal('dish-form-price', dish.price);
  setVal('dish-form-old-price', dish.oldPrice);
  setVal('dish-form-calories', dish.calories);
  setVal('dish-form-ingredients', dish.ingredients);
  setVal('dish-form-desc', dish.description);
  setVal('dish-form-image', dish.image);

  updateDishImagePreview(dish.image, 'dish-form-preview-img');

  setCheck('dish-form-free-delivery', dish.freeDelivery);
  setCheck('dish-form-popular', dish.isPopular);
  setCheck('dish-form-spicy', dish.isSpicy);
  setCheck('dish-form-veg', dish.isVeg);
  setCheck('dish-form-new', dish.isNew);

  const modal = document.getElementById('dish-edit-modal');
  if (modal) modal.classList.remove('hidden');
}

function closeDishModal() {
  const modal = document.getElementById('dish-edit-modal');
  if (modal) modal.classList.add('hidden');
}

// -------------------------------------------------------------
// تصفير الحسابات والبدء من جديد (Reset Accounts & Orders)
// -------------------------------------------------------------
function confirmResetAllAccounts() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const pin = prompt("⚠️ تحذير تصفير الحسابات والبدء من جديد:\nسيتم مسح كافة طلبات وفواتير الصندوق وإعادة تصفير الإيرادات اليومية ونهاية اليوم.\nلتأكيد التصفير، يرجى إدخال رمز PIN الإداري:");
  if (!pin) return;
  
  const validPin = config.adminPin || '';
  if (pin !== validPin && pin !== '') {
    alert("❌ رمز PIN غير صحيح! تم إلغاء عملية التصفير للحفاظ على أمان البيانات.");
    return;
  }

  // تصفير الطلبات
  setStoredData('orders', []);
  window.dispatchEvent(new Event('storage'));

  loadAdminAccounting();
  if (typeof loadAdminOrders === 'function') loadAdminOrders();
  if (typeof renderStats === 'function') renderStats();

  alert("تم تصفير كافة الحسابات والطلبات بنجاح! السجل الآن نظيف 100% وجاهز لبدء العمل من جديد ✅");
}

function populateCategorySelect(selectedId = null) {
  const select = document.getElementById('dish-form-category');
  if (!select) return;
  const categories = getStoredData('categories', DEFAULT_CATEGORIES).filter(c => c.id !== 'all');
  
  select.innerHTML = categories.map(c => `
    <option value="${c.id}" ${c.id === selectedId ? 'selected' : ''}>${c.name}</option>
  `).join('');
}

function saveDishFromForm(event) {
  event.preventDefault();
  const idVal = document.getElementById('dish-form-id')?.value;
  let dishes = getStoredData('dishes', DEFAULT_DISHES);

  const getVal = (id) => document.getElementById(id)?.value?.trim() || '';
  const getCheck = (id) => !!document.getElementById(id)?.checked;
  const oldPriceInput = getVal('dish-form-old-price');

  const dishData = {
    name: getVal('dish-form-name'),
    nameEn: getVal('dish-form-name-en'),
    categoryId: document.getElementById('dish-form-category')?.value || 'grills',
    price: parseFloat(document.getElementById('dish-form-price')?.value) || 0,
    oldPrice: oldPriceInput ? parseFloat(oldPriceInput) : null,
    calories: getVal('dish-form-calories'),
    ingredients: getVal('dish-form-ingredients'),
    description: getVal('dish-form-desc'),
    image: getVal('dish-form-image') || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600',
    freeDelivery: getCheck('dish-form-free-delivery'),
    isPopular: getCheck('dish-form-popular'),
    isSpicy: getCheck('dish-form-spicy'),
    isVeg: getCheck('dish-form-veg'),
    isNew: getCheck('dish-form-new'),
    available: true
  };

  if (!dishData.name) {
    alert("يرجى إدخال اسم الصنف!");
    return;
  }

  if (idVal) {
    const idx = dishes.findIndex(d => d.id == idVal);
    if (idx !== -1) {
      dishes[idx] = { ...dishes[idx], ...dishData };
    }
  } else {
    dishData.id = Date.now();
    dishes.push(dishData);
  }

  setStoredData('dishes', dishes);
  closeDishModal();
  loadAdminDishes();
  alert("تم حفظ وتحديث بيانات الصنف بنجاح! ✅");
}

// -------------------------------------------------------------
// إعدادات المطعم والطابعة (Restaurant Settings)
// -------------------------------------------------------------
function applyRestaurantPreset(type) {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);

  if (type === 'grills') {
    config.name = "مطعم فحمة ودخان";
    config.nameEn = "Fahma & Dokhan Restaurant";
    config.tagline = "أشهى المشاوي والدجاج على الفحم، البركر، الساندويشات الغربية والريزو";
  } else if (type === 'burger') {
    config.name = "مطعم ومطبخ البرجر الملكي";
    config.nameEn = "Royal Burger & Fast Food";
    config.tagline = "برجر مشوي على اللهب، بطاطا مقرمشة، وأشهى الساندويشات";
  } else if (type === 'pizza') {
    config.name = "مطعم بيانو بيتزا وباستا";
    config.nameEn = "Piano Pizza & Italian Food";
    config.tagline = "بيتزا إيطالية على الحطب، باستا طازجة ومقبلات شهية";
  } else if (type === 'cafe') {
    config.name = "كافيه ومقهى الرواق";
    config.nameEn = "Al-Rawaq Specialty Coffee";
    config.tagline = "قهوة مختصة، مشروبات ساخنة وباردة، وحلويات فرنسية فاخرة";
  }

  setStoredData('config', config);
  loadRestaurantSettings();
  alert(`تم تطبيق قالب (${config.name}) بنجاح! يمكنك الآن تعديل القائمة والأسعار بكل سهولة.`);
}

function toggleDineInBadge(checked) {
  const badge = document.getElementById('dinein-status-badge');
  if (badge) {
    if (checked) {
      badge.textContent = "مفعل (يمكن للزبائن الطلب)";
      badge.className = "px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30";
    } else {
      badge.textContent = "مقفل (المنيو للعرض فقط)";
      badge.className = "px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30";
    }
  }
}

function toggleTakeawayBadge(checked) {
  const badge = document.getElementById('takeaway-pkg-badge');
  if (badge) {
    if (checked) {
      badge.textContent = "الباقة مفعلة ✅";
      badge.className = "px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30";
    } else {
      badge.textContent = "يتطلب تفعيل الباقة 🔒";
      badge.className = "px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30";
    }
  }
}

function loadRestaurantSettings() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val !== undefined ? val : '';
  };
  const setCheck = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.checked = !!val;
  };

  setVal('setting-name', config.name);
  setVal('setting-name-en', config.nameEn);
  setVal('setting-tagline', config.tagline);
  setVal('setting-published-url', config.publishedUrl || '');
  setVal('setting-currency', config.currency);
  setVal('setting-tables', config.tablesCount);
  setVal('setting-phone', config.phone);
  setVal('setting-address', config.address || 'العراق - بغداد - الكرادة');
  setVal('setting-hours', config.workingHours || '12:00 ظهراً - 02:00 بعد منتصف الليل');
  setVal('setting-holidays', config.holidays || 'مفتوح طوال أيام الأسبوع');
  setVal('setting-wifi-name', config.wifiName || 'Fahma_Dokhan_WiFi');
  setVal('setting-wifi-pass', config.wifiPass || 'fahma2026');

  // إعدادات الطباعة
  const printSettings = typeof getPrintSettings === 'function' ? getPrintSettings() : { paperSize: '80mm', ticketType: 'dual' };
  setVal('setting-printer-paper', printSettings.paperSize || '80mm');
  setVal('setting-ticket-type', printSettings.ticketType || 'dual');
  setCheck('setting-autoprint', config.autoPrintKitchenTicket !== false);

  setCheck('setting-allow-dinein', config.allowDineInOrders);
  toggleDineInBadge(config.allowDineInOrders);

  setCheck('setting-takeaway-pkg', config.takeawayPackageActive);
  toggleTakeawayBadge(config.takeawayPackageActive);
}

async function saveRestaurantSettings(e) {
  if (e) e.preventDefault();
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);

  config.name = document.getElementById('setting-name')?.value?.trim() || config.name;
  config.nameEn = document.getElementById('setting-name-en')?.value?.trim() || config.nameEn;
  config.tagline = document.getElementById('setting-tagline')?.value?.trim() || config.tagline;
  config.publishedUrl = document.getElementById('setting-published-url')?.value?.trim() || config.publishedUrl;
  config.currency = document.getElementById('setting-currency')?.value?.trim() || config.currency;
  config.phone = document.getElementById('setting-phone')?.value?.trim() || config.phone;
  config.address = document.getElementById('setting-address')?.value?.trim() || config.address;
  config.tablesCount = parseInt(document.getElementById('setting-tables')?.value) || 20;

  config.workingHours = document.getElementById('setting-hours')?.value?.trim() || config.workingHours;
  config.holidays = document.getElementById('setting-holidays')?.value?.trim() || config.holidays;
  config.wifiName = document.getElementById('setting-wifi-name')?.value?.trim() || config.wifiName;
  config.wifiPass = document.getElementById('setting-wifi-pass')?.value?.trim() || config.wifiPass;
  
  config.allowDineInOrders = !!document.getElementById('setting-allow-dinein')?.checked;
  config.takeawayPackageActive = !!document.getElementById('setting-takeaway-pkg')?.checked;
  config.allowTakeawayOrders = config.takeawayPackageActive;
  
  const autoPrintCheck = document.getElementById('setting-autoprint');
  if (autoPrintCheck) config.autoPrintKitchenTicket = autoPrintCheck.checked;

  // حفظ إعدادات الطباعة
  const paperSize = document.getElementById('setting-printer-paper')?.value || '80mm';
  const ticketType = document.getElementById('setting-ticket-type')?.value || 'dual';
  if (typeof savePrintSettings === 'function') {
    savePrintSettings({ paperSize, ticketType });
  }

  setStoredData('config', config);

  // إرسال إشعار لتحديث جميع الصفحات المفتوحة في المتصفح فوراً
  window.dispatchEvent(new Event('storage'));

  // مزامنة مع سحابة Supabase إذا توفر العميل
  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : DEFAULT_RESTAURANT_ID;
  if (client) {
    try {
      await client.from('restaurants').upsert([{
        id: restId,
        name: config.name,
        name_en: config.nameEn,
        tagline: config.tagline,
        currency: config.currency,
        tables_count: config.tablesCount,
        phone: config.phone,
        address: config.address,
        published_url: config.publishedUrl,
        working_hours: config.workingHours,
        wifi_name: config.wifiName,
        wifi_pass: config.wifiPass,
        allow_dinein_orders: config.allowDineInOrders,
        allow_takeaway_orders: config.allowTakeawayOrders,
        takeaway_package_active: config.takeawayPackageActive,
        auto_print: config.autoPrintKitchenTicket,
        updated_at: new Date().toISOString()
      }]);
    } catch (err) {
      console.warn("Supabase rest update:", err);
    }
  }
  
  if (typeof renderTableQRCardsContainer === 'function') {
    renderTableQRCardsContainer('admin-qr-grid', config.tablesCount);
  }
  
  alert("تم حفظ وتطبيق كافة الإعدادات بنجاح ومزامنتها على جميع شاشات النظام والسحابة! ✅");
}

// -------------------------------------------------------------
// قسم المحاسبة وتقرير نهاية اليوم (Accounting & End of Day Report)
// -------------------------------------------------------------
let currentAdminAccountingPreset = 'today';
let currentAdminAccountingCustomDate = null;

function filterAdminAccounting(preset) {
  currentAdminAccountingPreset = preset;
  currentAdminAccountingCustomDate = null;

  document.querySelectorAll('.acc-filter-btn').forEach(btn => {
    btn.className = 'acc-filter-btn px-3 py-2 rounded-xl text-xs font-bold bg-slate-900 text-slate-300 hover:text-white transition flex items-center gap-1';
  });

  const activeBtn = document.getElementById(`acc-btn-${preset}`);
  if (activeBtn) {
    activeBtn.className = 'acc-filter-btn px-3 py-2 rounded-xl text-xs font-black bg-emerald-600 text-white transition flex items-center gap-1';
  }

  const customInput = document.getElementById('admin-accounting-custom-date');
  if (customInput) customInput.value = '';

  loadAdminAccounting();
}

function filterAdminAccountingByCustomDate(dateVal) {
  if (!dateVal) return;
  currentAdminAccountingCustomDate = dateVal;
  currentAdminAccountingPreset = 'custom';

  document.querySelectorAll('.acc-filter-btn').forEach(btn => {
    btn.className = 'acc-filter-btn px-3 py-2 rounded-xl text-xs font-bold bg-slate-900 text-slate-300 hover:text-white transition flex items-center gap-1';
  });

  const customInput = document.getElementById('admin-accounting-custom-date');
  if (customInput) customInput.value = dateVal;

  loadAdminAccounting();
}

function navigateAdminAccountingDay(offset) {
  let baseDate = new Date();
  if (currentAdminAccountingCustomDate) {
    baseDate = new Date(currentAdminAccountingCustomDate);
  } else if (currentAdminAccountingPreset === 'yesterday') {
    baseDate.setDate(baseDate.getDate() - 1);
  }

  baseDate.setDate(baseDate.getDate() + offset);
  const yyyy = baseDate.getFullYear();
  const mm = String(baseDate.getMonth() + 1).padStart(2, '0');
  const dd = String(baseDate.getDate()).padStart(2, '0');
  const formattedDate = `${yyyy}-${mm}-${dd}`;

  filterAdminAccountingByCustomDate(formattedDate);
}

function loadAdminAccounting() {
  const report = getAccountingReport(currentAdminAccountingPreset, currentAdminAccountingCustomDate);
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);

  // تحديث شارة الفترة المعروضة
  const labelEl = document.getElementById('acc-active-period-label');
  if (labelEl) {
    if (currentAdminAccountingPreset === 'today') {
      labelEl.textContent = `اليوم الحالي (${new Date().toLocaleDateString('ar-EG')})`;
    } else if (currentAdminAccountingPreset === 'yesterday') {
      const yDate = new Date();
      yDate.setDate(yDate.getDate() - 1);
      labelEl.textContent = `يوم أمس (${yDate.toLocaleDateString('ar-EG')})`;
    } else if (currentAdminAccountingPreset === 'week') {
      labelEl.textContent = `آخر 7 أيام`;
    } else if (currentAdminAccountingPreset === 'month') {
      labelEl.textContent = `هذا الشهر`;
    } else if (currentAdminAccountingPreset === 'all') {
      labelEl.textContent = `كامل السجل المحاسبي`;
    } else if (currentAdminAccountingCustomDate) {
      const cDate = new Date(currentAdminAccountingCustomDate);
      labelEl.textContent = `تاريخ مخصص: ${cDate.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`;
    }
  }

  // 1. تحديث بطاقات الأرقام والمؤشرات
  const setElText = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };

  setElText('acc-stat-total-revenue', `${report.totalRevenue.toLocaleString()} ${report.currency}`);
  setElText('acc-stat-total-orders', report.totalOrders);
  setElText('acc-stat-dinein-sales', `${report.dineInSales.toLocaleString()} ${report.currency}`);
  setElText('acc-stat-dinein-count', `${report.dineInCount} طلب صالة`);
  setElText('acc-stat-takeaway-sales', `${(report.takeawaySales + report.deliverySales).toLocaleString()} ${report.currency}`);
  setElText('acc-stat-takeaway-count', `${report.takeawayCount + report.deliveryCount} طلب سفري وتوصيل`);

  // 2. تحديث جدول الأصناف الأكثر مبيعاً
  const topDishesTable = document.getElementById('acc-top-dishes-table-body');
  const topDishesCount = document.getElementById('acc-top-dishes-count');
  if (topDishesCount) topDishesCount.textContent = `${report.topDishes.length} صنف`;

  if (topDishesTable) {
    if (report.topDishes.length === 0) {
      topDishesTable.innerHTML = `
        <tr>
          <td colspan="3" class="text-center py-8 text-slate-500 text-xs">لا توجد مبيعات مسجلة لهذه الفترة</td>
        </tr>
      `;
    } else {
      topDishesTable.innerHTML = report.topDishes.map((dish, i) => `
        <tr class="border-b border-slate-800/60 hover:bg-slate-800/40 transition">
          <td class="p-2.5">
            <div class="font-bold text-white text-xs">${i + 1}. ${dish.name}</div>
            <div class="text-[10px] text-slate-400">سعر الصنف: ${dish.price.toLocaleString()} ${report.currency}</div>
          </td>
          <td class="p-2.5 text-center font-black text-amber-400 text-xs">
            ${dish.quantity}
          </td>
          <td class="p-2.5 text-left font-black text-emerald-400 text-xs">
            ${dish.totalRevenue.toLocaleString()} ${report.currency}
          </td>
        </tr>
      `).join('');
    }
  }

  // 3. تحديث جدول سجل الفواتير المفصل
  const invoicesTable = document.getElementById('acc-invoices-table-body');
  const invoicesCount = document.getElementById('acc-invoices-count');
  if (invoicesCount) invoicesCount.textContent = `${report.orders.length} فاتورة`;

  if (invoicesTable) {
    if (report.orders.length === 0) {
      invoicesTable.innerHTML = `
        <tr>
          <td colspan="4" class="text-center py-8 text-slate-500 text-xs">لا توجد طلبات مسجلة لهذه الفترة</td>
        </tr>
      `;
    } else {
      invoicesTable.innerHTML = report.orders.map(order => {
        const isDineIn = order.type === 'dine-in' || order.type === 'dinein' || order.tableNumber;
        const typeBadge = isDineIn
          ? `<span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded text-[10px] font-bold">🍽️ طاولة ${order.tableNumber || '-'}</span>`
          : `<span class="bg-rose-500/20 text-rose-400 border border-rose-500/30 px-2 py-0.5 rounded text-[10px] font-bold">🛵 سفري/توصيل</span>`;

        const timeStr = order.timestamp ? new Date(order.timestamp).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }) : '-';

        return `
          <tr class="border-b border-slate-800/60 hover:bg-slate-800/40 transition">
            <td class="p-2.5">
              <div class="font-bold text-white text-xs">${order.id || 'ORD-000'}</div>
              <div class="text-[10px] text-slate-400 font-mono">${timeStr}</div>
            </td>
            <td class="p-2.5">
              ${typeBadge}
            </td>
            <td class="p-2.5 font-black text-rose-400 text-xs">
              ${(order.total || 0).toLocaleString()} ${report.currency}
            </td>
            <td class="p-2.5 text-left">
              <button onclick="printOrderDirectById('${order.id}')" class="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-bold transition flex items-center gap-1">
                <span>🖨️ طباعة</span>
              </button>
            </td>
          </tr>
        `;
      }).join('');
    }
  }
}

function printAdminEndOfDayReport() {
  printEndOfDayReportDirect(currentAdminAccountingPreset, currentAdminAccountingCustomDate);
}

function exportAdminReportCSV() {
  exportAccountingReportCSV(currentAdminAccountingPreset, currentAdminAccountingCustomDate);
}

function printOrderDirectById(orderId) {
  const orders = getStoredData('orders', []);
  const order = orders.find(o => o.id === orderId);
  if (order) {
    if (typeof printOrderDirect === 'function') {
      printOrderDirect(order);
    } else {
      window.print();
    }
  }
}

/* === app.js === */
/**
 * Smart E-Menu - Client Engine & Cart Controller
 * محرك المنيو الرقمي، السلة، البحث، وإدارة الطلب الداخلي وطباعة المطبخ
 */

// State
let cart = [];
let currentCategory = 'all';
let currentFilter = 'all'; // all, popular, offers, veg, spicy
let searchQuery = '';
let selectedTableNumber = null;
let currentOrderType = 'dine-in'; // dine-in, takeaway, delivery

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  // 1. فحص معلمة الطاولة من الرابط مثل ?table=4 أو من الجلسة المحفوظة
  const urlParams = new URLSearchParams(window.location.search);
  const tableParam = urlParams.get('table');
  if (tableParam) {
    const parsed = parseInt(tableParam);
    if (!isNaN(parsed) && parsed > 0) {
      selectedTableNumber = parsed;
      sessionStorage.setItem('customer_table_number', parsed);
    }
  } else {
    const savedTable = sessionStorage.getItem('customer_table_number');
    if (savedTable) {
      const parsedSaved = parseInt(savedTable);
      if (!isNaN(parsedSaved) && parsedSaved > 0) {
        selectedTableNumber = parsedSaved;
      }
    }
  }

  if (selectedTableNumber && !isNaN(selectedTableNumber) && selectedTableNumber > 0) {
    const tableBadge = document.getElementById('customer-table-badge');
    if (tableBadge) {
      tableBadge.textContent = `طاولة رقم ${selectedTableNumber}`;
      tableBadge.classList.remove('hidden');
    }

    // إظهار شريط خدمة الطاولة السريعة (نداء الكابتن 🛎️ وطلب الفاتورة 💳)
    const quickBar = document.getElementById('quick-table-service-bar');
    const quickIndicator = document.getElementById('quick-table-indicator');
    if (quickBar) {
      quickBar.classList.remove('hidden');
      quickBar.style.display = 'flex';
    }
    if (quickIndicator) {
      quickIndicator.textContent = `طاولة رقم [ ${selectedTableNumber} ]`;
    }
  }

  const currentRest = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  let storedDishes = getStoredData('dishes', DEFAULT_DISHES);

  const defaultCats = DEFAULT_CATEGORIES;
  let storedCategories = getStoredData('categories', defaultCats);
  if (!storedCategories || storedCategories.length === 0) {
    storedCategories = defaultCats;
    setStoredData('categories', defaultCats);
  }

  let storedConfig = getStoredData('config', null);
  if (!storedConfig) {
    storedConfig = getDefaultRestaurantConfig(currentRest);
    if (currentRest === 'fahma_dokhan') {
      setStoredData('config', storedConfig);
    }
  }

  // 2. تحديث هوية المطعم
  updateAppBranding();

  // 3. عرض الفئات والأطباق
  renderCategories();
  renderMenuDishes();

  // مزامنة حالة الباقة والإعدادات من Supabase
  syncRestaurantConfigFromSupabase();
  syncMenuFromSupabase();

  // 4. استرجاع السلة السابقة إن وجدت
  cart = getStoredData('cart', []);
  updateCartUI();

  // 5. تجهيز أرقام الطاولات في قائمة السلة
  populateTableOptions();

  // 6. تجهيز شارات المطبخ والإدارة
  updateKitchenBadge();

  // 7. ربط أحداث البحث وسلايدر الأقسام مع الحماية من الإكمال التلقائي
  const searchInput = document.getElementById('menu-search-input');
  if (searchInput) {
    // تنظيف أي إكمال تلقائي خاطئ لبيانات الدخول من المتصفح (مثل super_admin)
    const checkAndSanitizeSearch = () => {
      const v = (searchInput.value || '').trim().toLowerCase();
      if (v === 'super_admin' || v === 'admin' || v === 'cashier') {
        searchInput.value = '';
        searchQuery = '';
        const clearBtn = document.getElementById('menu-search-clear-btn');
        if (clearBtn) clearBtn.classList.add('hidden');
        return true;
      }
      return false;
    };

    checkAndSanitizeSearch();

    // فحص إضافي خفيف بعد التحميل لأن المتصفحات (Chrome) تحقن الإكمال التلقائي بعد أجزاء من الثانية
    setTimeout(checkAndSanitizeSearch, 100);
    setTimeout(checkAndSanitizeSearch, 400);
    setTimeout(checkAndSanitizeSearch, 1000);

    searchInput.addEventListener('input', (e) => {
      if (checkAndSanitizeSearch()) {
        renderMenuDishes();
        return;
      }
      searchQuery = e.target.value.toLowerCase().trim();
      const clearBtn = document.getElementById('menu-search-clear-btn');
      if (clearBtn) {
        if (searchQuery) clearBtn.classList.remove('hidden');
        else clearBtn.classList.add('hidden');
      }
      renderMenuDishes();
    });

    searchInput.addEventListener('change', () => {
      if (checkAndSanitizeSearch()) {
        renderMenuDishes();
      }
    });

    searchInput.addEventListener('focus', () => {
      checkAndSanitizeSearch();
    });
  }

  // مستمع لتحديث الإعدادات فورياً عند تغييرها من لوحة الأدمن أو الكاشير
  window.addEventListener('storage', () => {
    updateAppBranding();
    renderCategories();
    renderMenuDishes();
    updateCartUI();
  });

  try {
    if ('BroadcastChannel' in window) {
      const bc = new BroadcastChannel('smart_emenu_channel');
      bc.onmessage = (ev) => {
        if (ev.data && (ev.data.type === 'DISH_AVAILABILITY_CHANGED' || ev.data.type === 'DISH_SAVED' || ev.data.type === 'DISH_DELETED')) {
          renderMenuDishes();
          updateCartUI();
        }
      };
    }
  } catch (e) {}

  // تسجيل PWA Service Worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(err => console.log('SW registration error:', err));
  }
}

// -------------------------------------------------------------
// محرك التحقق من أوقات العمل الرسمية وحالة استقبال الطلبات
// -------------------------------------------------------------
function parseArabicTimeToMinutes(timeStr, isPMHint, isClosingTime = false) {
  if (!timeStr) return null;
  const clean = timeStr.trim();
  const match = clean.match(/(\d{1,2}):(\d{2})/);
  if (!match) return null;
  let h = parseInt(match[1], 10);
  let m = parseInt(match[2], 10);

  const lower = clean.toLowerCase();
  const hasMidnight = lower.includes('منتصف الليل') || lower.includes('نصف الليل');
  const hasDawn = lower.includes('فجر') || lower.includes('صباح') || lower.includes('am');
  const hasEvening = lower.includes('مساء') || lower.includes('ظهرا') || lower.includes('ظهر') || lower.includes('عصر') || lower.includes('ليل') || lower.includes('pm');

  if (hasMidnight) {
    if (h === 12 || h === 0) {
      return isClosingTime ? 24 * 60 : 0;
    } else if (h >= 1 && h <= 5) {
      return h * 60 + m; // 1:00 AM, 2:00 AM
    } else if (h >= 6 && h <= 11) {
      // 10:00 ليلاً / بعد منتصف الليل تعني 10:00 مساءً (22:00)
      h += 12;
      return h * 60 + m;
    }
  }

  const isPM = isPMHint !== undefined ? isPMHint : (hasEvening && !hasDawn);
  if (isPM && h < 12) h += 12;
  if (!isPM && hasDawn && h === 12) h = 0;

  return h * 60 + m;
}

function parseWorkingHoursString(workingHoursText) {
  let openMin = 10 * 60;  // 10:00 AM (600)
  let closeMin = 24 * 60; // 12:00 Midnight (1440)

  if (!workingHoursText) return { openMin, closeMin };

  const matches = [...workingHoursText.matchAll(/(\d{1,2}):(\d{2})/g)];
  if (matches.length >= 2) {
    const m1 = matches[0];
    const m2 = matches[1];

    const sub1 = workingHoursText.substring(0, m2.index);
    const sub2 = workingHoursText.substring(m2.index);

    const t1 = parseArabicTimeToMinutes(sub1, false, false);
    const t2 = parseArabicTimeToMinutes(sub2, undefined, true);

    if (t1 !== null) openMin = t1;
    if (t2 !== null) closeMin = t2;
  }
  return { openMin, closeMin };
}

function checkRestaurantOpenStatus(config, testDate) {
  const cfg = config || (typeof getStoredData === 'function' ? getStoredData('config', DEFAULT_RESTAURANT_CONFIG) : {});

  // 1. فحص التحكم اليدوي المباشر إن وُجد
  if (cfg.storeManualStatus === 'open') {
    return {
      isOpen: true,
      status: 'open',
      reason: 'manual_open',
      workingHoursText: cfg.workingHours || '',
      allowPreorderNextDay: cfg.allowPreorderNextDay !== false
    };
  }
  if (cfg.storeManualStatus === 'closed') {
    return {
      isOpen: false,
      status: 'closed',
      reason: 'manual_closed',
      workingHoursText: cfg.workingHours || '',
      allowPreorderNextDay: cfg.allowPreorderNextDay !== false
    };
  }

  // 2. فحص الحقول الصريحة openTime و closeTime أولاً
  let openMin = null;
  let closeMin = null;

  if (cfg.openTime && cfg.closeTime) {
    const oMatch = cfg.openTime.match(/(\d{1,2}):(\d{2})/);
    const cMatch = cfg.closeTime.match(/(\d{1,2}):(\d{2})/);
    if (oMatch && cMatch) {
      openMin = parseInt(oMatch[1], 10) * 60 + parseInt(oMatch[2], 10);
      closeMin = parseInt(cMatch[1], 10) * 60 + parseInt(cMatch[2], 10);

      // إذا كان وقت الإغلاق 00:00 (منتصف الليل) أو 24:00، فهذا يعني نهاية اليوم (1440 دقيقة)
      if (closeMin === 0 && openMin > 0) {
        closeMin = 24 * 60;
      }
    }
  }

  // إذا لم تكن موجودة بصيغة صريحة أو كانت متطابقة، نستنتجها بدقة من نص ساعات العمل workingHours
  if (openMin === null || closeMin === null || openMin === closeMin) {
    const parsed = parseWorkingHoursString(cfg.workingHours || "من 10:00 صباحاً وحتى 12:00 منتصف الليل");
    openMin = parsed.openMin;
    closeMin = parsed.closeMin;
    if (closeMin === 0 && openMin > 0) {
      closeMin = 24 * 60;
    }
  }

  // إذا بقيا متساويين، نضبطهما افتراضياً على ساعات عمل قياسية (10 صباحاً إلى 12 منتصف الليل)
  if (openMin === null || closeMin === null || openMin === closeMin) {
    openMin = 10 * 60;
    closeMin = 24 * 60;
  }

  const now = testDate || new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  let isOpen = false;
  if (openMin < closeMin) {
    // دوام بنفس اليوم (مثلاً 10:00 صباحاً إلى 12:00 منتصف الليل 1440)
    isOpen = currentMinutes >= openMin && currentMinutes < closeMin;
  } else {
    // دوام يمتد لما بعد منتصف الليل (مثلاً 12:00 ظهراً إلى 02:00 فجراً)
    isOpen = currentMinutes >= openMin || currentMinutes < closeMin;
  }

  return {
    isOpen,
    status: isOpen ? 'open' : 'closed',
    reason: isOpen ? 'in_working_hours' : 'outside_hours',
    currentMinutes,
    openMin,
    closeMin,
    workingHoursText: cfg.workingHours || 'من 10:00 صباحاً وحتى 12:00 منتصف الليل',
    allowPreorderNextDay: cfg.allowPreorderNextDay !== false
  };
}

// -------------------------------------------------------------
// تحديث معلومات وهوية المطعم
// -------------------------------------------------------------
function updateAppBranding() {
  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const config = getStoredData('config', getDefaultRestaurantConfig(restId));
  
  // تحديث النصوص والعناوين
  document.querySelectorAll('.brand-restaurant-name').forEach(el => el.textContent = config.name);
  document.querySelectorAll('.brand-restaurant-tagline').forEach(el => el.textContent = config.tagline);
  document.querySelectorAll('.brand-currency').forEach(el => el.textContent = config.currency);
  
  // فحص وتحديث حالة أوقات العمل الرسمية
  const storeStatus = checkRestaurantOpenStatus(config);

  const statusDot = document.getElementById('header-status-dot');
  const statusText = document.getElementById('header-status-text');
  const heroBadge = document.getElementById('hero-status-badge');
  const heroStatusText = document.getElementById('hero-status-text');
  const closedBanner = document.getElementById('store-closed-banner');
  const closedBannerHours = document.getElementById('store-closed-hours-text');

  if (storeStatus.isOpen) {
    if (statusDot) statusDot.className = "w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse";
    if (statusText) {
      statusText.textContent = "مفتوح الآن لاستقبال الطلبات";
      statusText.className = "text-emerald-400 font-bold";
    }
    if (heroBadge) heroBadge.className = "inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold";
    if (heroStatusText) heroStatusText.textContent = "مفتوح نرحب بكم";
    if (closedBanner) closedBanner.classList.add('hidden');
  } else {
    if (statusDot) statusDot.className = "w-2 h-2 rounded-full bg-amber-400 animate-pulse";
    if (statusText) {
      statusText.textContent = "مغلق حالياً • متاح حجز الغد 📅";
      statusText.className = "text-amber-300 font-bold";
    }
    if (heroBadge) heroBadge.className = "inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-bold";
    if (heroStatusText) heroStatusText.textContent = "مغلق • متاح حجز الغد 📅";
    if (closedBanner) {
      closedBanner.classList.remove('hidden');
      if (closedBannerHours) closedBannerHours.textContent = config.workingHours || storeStatus.workingHoursText;
    }
  }

  // تحديث نصوص الشريط العلوي (Top Header)
  const headerName = document.getElementById('header-restaurant-name');
  if (headerName) headerName.textContent = config.name;

  const headerHours = document.getElementById('header-hours-text');
  if (headerHours) headerHours.textContent = config.workingHours || '10:00 صباحاً - 10:00 بعد منتصف الليل';

  const logoTarget = (config.logo && config.logo.trim()) ? config.logo.trim() : 'logo.svg';
  document.querySelectorAll('.restaurant-logo-img').forEach(img => {
    if (img.getAttribute('src') !== logoTarget) {
      img.src = logoTarget;
    }
    img.onerror = () => { img.src = 'logo.svg'; img.onerror = null; };
  });

  const wifiNameEl = document.getElementById('info-wifi-name');
  if (wifiNameEl) wifiNameEl.textContent = config.wifiName || 'Fahma_Dokhan_WiFi';

  const wifiPassEl = document.getElementById('info-wifi-pass');
  if (wifiPassEl) wifiPassEl.textContent = config.wifiPass || 'fahma2026';

  const hoursEl = document.getElementById('info-hours');
  if (hoursEl) hoursEl.textContent = config.workingHours || '10:00 صباحاً - 10:00 بعد منتصف الليل';

  const holidaysEl = document.getElementById('info-holidays');
  if (holidaysEl) holidaysEl.textContent = config.holidays || 'مفتوح طوال أيام الأسبوع';

  // تحديث العنوان والموقع في الهيدر الرئيسي
  const addressEl = document.getElementById('info-address');
  if (addressEl) addressEl.textContent = config.address || 'العراق - نينوى - الشيماء';

  // تحديث الرابط الحي لخريطة المطعم في الهيدر
  const heroMapBtn = document.getElementById('hero-map-btn');
  if (heroMapBtn) {
    if (config.mapUrl && config.mapUrl.trim()) {
      heroMapBtn.href = config.mapUrl.trim();
    } else if (config.address && config.address.trim()) {
      const q = encodeURIComponent(config.address.trim());
      heroMapBtn.href = `https://www.google.com/maps/search/?api=1&query=${q}`;
    } else {
      heroMapBtn.href = 'https://maps.google.com';
    }
  }

  // تحديث رقم هاتف المطعم المعتمد من الإعدادات للزبائن
  const restPhone = config.phone || '07755009771';
  const cartPhoneEl = document.getElementById('cart-restaurant-phone');
  if (cartPhoneEl) cartPhoneEl.textContent = restPhone;

  const cartPhoneBtn = document.getElementById('cart-restaurant-phone-btn');
  if (cartPhoneBtn) cartPhoneBtn.href = `tel:${restPhone.replace(/\s+/g, '')}`;

  const successPhoneText = document.getElementById('order-success-restaurant-phone-text');
  if (successPhoneText) successPhoneText.textContent = restPhone;

  const successPhoneBtn = document.getElementById('order-success-restaurant-phone-btn');
  if (successPhoneBtn) successPhoneBtn.href = `tel:${restPhone.replace(/\s+/g, '')}`;

  // تحديث درج الإعدادات والمعلومات الجانبي (--- زر)
  const sH = document.getElementById('sidebar-hours');
  if (sH) sH.textContent = config.workingHours || '10:00 صباحاً - 10:00 بعد منتصف الليل';
  const sHd = document.getElementById('sidebar-holidays');
  if (sHd) sHd.textContent = config.holidays || 'مفتوح طوال أيام الأسبوع';
  const sAd = document.getElementById('sidebar-address');
  if (sAd) sAd.textContent = config.address || 'العراق - نينوى - الشيماء';
  const sWN = document.getElementById('sidebar-wifi-name');
  if (sWN) sWN.textContent = config.wifiName || 'Fahma_Dokhan_WiFi';
  const sWP = document.getElementById('sidebar-wifi-pass');
  if (sWP) sWP.textContent = config.wifiPass || 'fahma2026';
  const sPT = document.getElementById('sidebar-phone-text');
  if (sPT) sPT.textContent = restPhone;
  const sPB = document.getElementById('sidebar-phone-btn');
  if (sPB) sPB.href = `tel:${restPhone.replace(/\s+/g, '')}`;

  // هاتف احتياطي إضافي (الرقم الثاني)
  const phone2 = config.phone2 ? config.phone2.trim() : '';
  const p2Cont = document.getElementById('sidebar-phone2-container');
  const p2Text = document.getElementById('sidebar-phone2-text');
  const p2Btn = document.getElementById('sidebar-phone2-btn');
  if (p2Cont && p2Text && p2Btn) {
    if (phone2) {
      p2Cont.classList.remove('hidden');
      p2Text.textContent = phone2;
      p2Btn.href = `tel:${phone2.replace(/\s+/g, '')}`;
    } else {
      p2Cont.classList.add('hidden');
    }
  }

  // رابط وتواصل الواتساب المباشر في الدرج الجانبي
  const waCont = document.getElementById('sidebar-whatsapp-container');
  const waBtn = document.getElementById('sidebar-whatsapp-btn');
  const waText = document.getElementById('sidebar-whatsapp-text');
  const waNum = (config.whatsappNumber || config.phone || '').trim();
  let waUrl = (config.whatsappUrl || '').trim();
  if (!waUrl && waNum) {
    const rawWa = waNum.replace(/\D/g, '').replace(/^0+/, '');
    waUrl = `https://wa.me/${rawWa.startsWith('964') ? rawWa : '964' + rawWa}`;
  }
  if (waCont && waBtn && waText) {
    if (waUrl) {
      waCont.classList.remove('hidden');
      waBtn.href = waUrl;
      waText.textContent = waNum || restPhone;
    } else {
      waCont.classList.add('hidden');
    }
  }

  // رابط الخريطة على جوجل ماب في الدرج الجانبي
  const mapBtn = document.getElementById('sidebar-map-btn');
  if (mapBtn) {
    if (config.mapUrl && config.mapUrl.trim()) {
      mapBtn.href = config.mapUrl.trim();
    } else if (config.address && config.address.trim()) {
      const q = encodeURIComponent(config.address.trim());
      mapBtn.href = `https://www.google.com/maps/search/?api=1&query=${q}`;
    } else {
      mapBtn.href = 'https://maps.google.com';
    }
  }
}

// -------------------------------------------------------------
// إدارة درج الأقسام الجانبي (Category Side Drawer)
// -------------------------------------------------------------
function openCategorySidebar() {
  const modal = document.getElementById('categories-sidebar-modal');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeCategorySidebar() {
  const modal = document.getElementById('categories-sidebar-modal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// -------------------------------------------------------------
// إدارة درج الإعدادات والمعلومات الجانبي (Settings Side Drawer — زر ---)
// -------------------------------------------------------------
function openSettingsSidebar() {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  
  // تحديث بيانات المطعم في الدرج فور فتحه
  const el = (id) => document.getElementById(id);
  if (el('sidebar-hours')) el('sidebar-hours').textContent = config.workingHours || '10:00 صباحاً - 10:00 بعد منتصف الليل';
  if (el('sidebar-holidays')) el('sidebar-holidays').textContent = config.holidays || 'مفتوح طوال أيام الأسبوع';
  if (el('sidebar-address')) el('sidebar-address').textContent = config.address || 'العراق - نينوى - الشيماء';
  if (el('sidebar-wifi-name')) el('sidebar-wifi-name').textContent = config.wifiName || 'Fahma_Dokhan_WiFi';
  if (el('sidebar-wifi-pass')) el('sidebar-wifi-pass').textContent = config.wifiPass || 'fahma2026';
  
  const phone = config.phone || '07755009771';
  if (el('sidebar-phone-text')) el('sidebar-phone-text').textContent = phone;
  if (el('sidebar-phone-btn')) el('sidebar-phone-btn').href = `tel:${phone.replace(/\s+/g, '')}`;

  const phone2 = config.phone2 ? config.phone2.trim() : '';
  const p2Cont = el('sidebar-phone2-container');
  const p2Text = el('sidebar-phone2-text');
  const p2Btn = el('sidebar-phone2-btn');
  if (p2Cont && p2Text && p2Btn) {
    if (phone2) {
      p2Cont.classList.remove('hidden');
      p2Text.textContent = phone2;
      p2Btn.href = `tel:${phone2.replace(/\s+/g, '')}`;
    } else {
      p2Cont.classList.add('hidden');
    }
  }

  // الواتساب
  const waCont = el('sidebar-whatsapp-container');
  const waBtn = el('sidebar-whatsapp-btn');
  const waText = el('sidebar-whatsapp-text');
  const waNum = (config.whatsappNumber || config.phone || '').trim();
  let waUrl = (config.whatsappUrl || '').trim();
  if (!waUrl && waNum) {
    const rawWa = waNum.replace(/\D/g, '').replace(/^0+/, '');
    waUrl = `https://wa.me/${rawWa.startsWith('964') ? rawWa : '964' + rawWa}`;
  }
  if (waCont && waBtn && waText) {
    if (waUrl) {
      waCont.classList.remove('hidden');
      waBtn.href = waUrl;
      waText.textContent = waNum || phone;
    } else {
      waCont.classList.add('hidden');
    }
  }

  const mapBtn = el('sidebar-map-btn');
  if (mapBtn) {
    if (config.mapUrl && config.mapUrl.trim()) {
      mapBtn.href = config.mapUrl.trim();
    } else if (config.address && config.address.trim()) {
      const q = encodeURIComponent(config.address.trim());
      mapBtn.href = `https://www.google.com/maps/search/?api=1&query=${q}`;
    } else {
      mapBtn.href = 'https://maps.google.com';
    }
  }

  const modal = document.getElementById('settings-sidebar-modal');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeSettingsSidebar() {
  const modal = document.getElementById('settings-sidebar-modal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

function handleSettingsSidebarBackdropClick(e) {
  // إغلاق الدرج عند النقر على الخلفية المعتمة خارج اللوحة
  const drawer = e.currentTarget.querySelector('.bg-slate-900');
  if (drawer && !drawer.contains(e.target)) {
    closeSettingsSidebar();
  }
}

function renderCategories() {
  const sidebarContainer = document.getElementById('sidebar-categories-list');
  const mainBarContainer = document.getElementById('main-categories-bar');
  const categories = getStoredData('categories', DEFAULT_CATEGORIES);
  const dishes = getStoredData('dishes', DEFAULT_DISHES);

  // تحديث شارة القسم الحالي في الهيدر
  const currentCatObj = categories.find(c => c.id === currentCategory) || { name: 'كل الأطباق', icon: '🍽️' };
  const iconEl = document.getElementById('current-category-icon');
  const nameEl = document.getElementById('current-category-name');
  if (iconEl) iconEl.textContent = currentCatObj.icon || '🍽️';
  if (nameEl) nameEl.textContent = currentCatObj.name || 'كل الأطباق';

  // شريط الفئات الأفقي السريع
  if (mainBarContainer) {
    mainBarContainer.innerHTML = categories.map(cat => {
      const isActive = currentCategory === cat.id;
      return `
        <button type="button" onclick="selectCategory('${cat.id}')" class="category-pill flex items-center gap-1.5 px-3.5 py-2 rounded-2xl border text-xs font-black whitespace-nowrap transition active:scale-95 flex-shrink-0 ${
          isActive
            ? 'bg-gradient-to-r from-rose-600 to-rose-700 border-rose-500 text-white shadow-lg shadow-rose-600/30 ring-1 ring-rose-400'
            : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
        }">
          <span class="text-sm">${cat.icon || '🍽️'}</span>
          <span>${cat.name}</span>
        </button>
      `;
    }).join('');
  }

  // قائمة الفئات في الدرج الجانبي
  if (sidebarContainer) {
    sidebarContainer.innerHTML = categories.map(cat => {
      const count = cat.id === 'all' 
        ? dishes.length 
        : dishes.filter(d => d.categoryId === cat.id).length;

      const isActive = currentCategory === cat.id;

      return `
        <button type="button" onclick="selectCategory('${cat.id}')" 
          class="w-full text-right p-3 rounded-2xl border transition flex items-center justify-between gap-3 group active:scale-98 ${
            isActive 
              ? 'bg-gradient-to-r from-rose-600 to-rose-700 text-white border-rose-500 shadow-lg shadow-rose-600/30 font-black' 
              : 'bg-slate-950/70 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700'
          }">
          <div class="flex items-center gap-3 min-w-0">
            <span class="w-10 h-10 rounded-xl ${isActive ? 'bg-white/20' : 'bg-slate-900 border border-slate-800'} flex items-center justify-center text-xl flex-shrink-0">
              ${cat.icon || '🍽️'}
            </span>
            <div class="truncate">
              <div class="text-sm font-bold truncate ${isActive ? 'text-white' : 'text-slate-200 group-hover:text-white'}">${cat.name}</div>
              <div class="text-[10px] ${isActive ? 'text-rose-200' : 'text-slate-500'}">اضغط لتصفح الأطباق</div>
            </div>
          </div>
          <span class="text-xs font-mono font-bold px-2.5 py-1 rounded-xl ${
            isActive 
              ? 'bg-white/20 text-white' 
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          } flex-shrink-0">
            ${count} وجبة
          </span>
        </button>
      `;
    }).join('');
  }
}

function selectCategory(catId) {
  currentCategory = catId;
  currentFilter = 'all';
  renderCategories();
  renderMenuDishes();
  closeCategorySidebar();
  // تظل الشاشة ثابتة في مكانها دون صعود أو نزول تلقائي
}

function selectQuickFilter(filter) {
  currentFilter = filter;
  document.querySelectorAll('.filter-chip').forEach(el => el.classList.remove('active'));
  const target = document.getElementById(`filter-chip-${filter}`);
  if (target) target.classList.add('active');
  renderMenuDishes();
}

// -------------------------------------------------------------
function clearMenuSearch() {
  const searchInput = document.getElementById('menu-search-input');
  if (searchInput) searchInput.value = '';
  searchQuery = '';
  const clearBtn = document.getElementById('menu-search-clear-btn');
  if (clearBtn) clearBtn.classList.add('hidden');
  renderMenuDishes();
}

// -------------------------------------------------------------
// عرض قائمة الأطباق بدون نافذة تفاصيل (إضافة مباشرة للسلة)
// -------------------------------------------------------------
function renderMenuDishes() {
  const container = document.getElementById('dishes-grid');
  const countBadge = document.getElementById('dishes-count-badge');
  const emptyState = document.getElementById('dishes-empty');
  if (!container) return;

  // تنظيف إضافي إذا كان المتصفح قد ملأ خانة البحث باسم المستخدم
  const searchInputEl = document.getElementById('menu-search-input');
  if (searchInputEl) {
    const v = (searchInputEl.value || '').trim().toLowerCase();
    if (v === 'super_admin' || v === 'admin' || v === 'cashier') {
      searchInputEl.value = '';
      searchQuery = '';
      const clearBtn = document.getElementById('menu-search-clear-btn');
      if (clearBtn) clearBtn.classList.add('hidden');
    }
  }

  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const fallbackDishes = DEFAULT_DISHES;
  const dishes = getStoredData('dishes', fallbackDishes);
  const config = getStoredData('config', getDefaultRestaurantConfig(restId));

  // تصفية الأطباق
  let filtered = dishes.filter(dish => {
    // 1. تصفية القسم
    if (currentCategory !== 'all' && currentCategory !== 'offers') {
      if (dish.categoryId !== currentCategory) return false;
    }
    if (currentCategory === 'offers' && !dish.oldPrice) return false;

    // 2. تصفية الفلاتر السريعة
    if (currentFilter === 'popular' && !dish.isPopular) return false;
    if (currentFilter === 'veg' && !dish.isVeg) return false;
    if (currentFilter === 'spicy' && !dish.isSpicy) return false;
    if (currentFilter === 'new' && !dish.isNew) return false;

    // 3. تصفية البحث
    if (searchQuery) {
      const matchName = dish.name && dish.name.toLowerCase().includes(searchQuery);
      const matchEn = dish.nameEn && dish.nameEn.toLowerCase().includes(searchQuery);
      const matchDesc = dish.description && dish.description.toLowerCase().includes(searchQuery);
      if (!matchName && !matchEn && !matchDesc) return false;
    }

    return true;
  });

  if (countBadge) countBadge.textContent = `${filtered.length} صنف`;

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-12 text-center bg-slate-900/60 rounded-3xl border border-slate-800 p-8 space-y-3">
        <span class="text-4xl block">🔍</span>
        <h4 class="text-white font-bold text-base">لا توجد أطباق مطابقة للبحث أو القسم المختار</h4>
        <p class="text-xs text-slate-400">جرب اختيار قسم آخر أو إلغاء فلتر البحث</p>
        <button onclick="clearMenuSearch(); selectCategory('all');" class="py-2.5 px-5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg transition active:scale-95">
          عرض كل الأطباق وإلغاء البحث 🍽️
        </button>
      </div>
    `;
    return;
  }

  if (emptyState) emptyState.classList.add('hidden');

  const isTakeawayActive = (config.takeawayPackageActive === true) && (config.allowTakeawayOrders === true);
  const isDineInActive = (config.allowDineInOrders === true);
  const isOrderingAllowed = (config.planType !== 'basic') && (isTakeawayActive || isDineInActive);

  const storeStatus = checkRestaurantOpenStatus(config);
  const isStoreClosed = (!storeStatus.isOpen || config.is_active === false);

  container.innerHTML = filtered.map(dish => {
    // التحقق من حالة نفاذ الصنف وحالة المحل
    const isSoldOut = (dish.available === false || dish.is_available === false || dish.status === 'out_of_stock');
    const isAvailableToOrder = !isSoldOut && !isStoreClosed;

    // التحقق من وجود الصنف بالسلة لمعرفة الكمية الحالية
    const cartItem = cart.find(item => String(item.id) === String(dish.id));
    const inCartQty = cartItem ? cartItem.quantity : 0;

    // الشارات والعروض
    let badgesHtml = '';
    
    // 1. شارة التوصيل المجاني
    if (dish.freeDelivery) {
      badgesHtml += `<span class="bg-emerald-600/95 text-white border border-emerald-400/40 text-[10px] font-black px-2 py-0.5 rounded-lg shadow-lg flex items-center gap-1 backdrop-blur-sm">🛵 توصيل مجاني</span>`;
    }

    const isFishOrWeighted = !!(dish.isWeighted || dish.categoryId === 'fish' || (dish.name && dish.name.includes('سمك')));
    if (isFishOrWeighted) {
      badgesHtml += `<span class="dish-badge-pill bg-blue-600 text-white font-black text-[10px] px-2 py-0.5 rounded-lg shadow-lg border border-blue-400/40">🐟 صنف بالوزن (حسب الطلب)</span>`;
    }
    // 2. شارة الخصم والتخفيض
    if (dish.oldPrice && dish.oldPrice > dish.price) {
      const discountPct = Math.round(((dish.oldPrice - dish.price) / dish.oldPrice) * 100);
      badgesHtml += `<span class="bg-rose-600 text-white font-black text-[10px] px-2 py-0.5 rounded-lg shadow-lg">🔥 خصم ${discountPct}%</span>`;
    } else if (dish.isPopular) {
      badgesHtml += `<span class="dish-badge-pill bg-amber-500/90 text-black font-black text-[10px] px-2 py-0.5 rounded-lg shadow">⭐ الأكثر طلباً</span>`;
    } else if (dish.isNew) {
      badgesHtml += `<span class="dish-badge-pill bg-rose-600 text-white font-black text-[10px] px-2 py-0.5 rounded-lg shadow">✨ جديد</span>`;
    } else if (dish.isVeg) {
      badgesHtml += `<span class="dish-badge-pill bg-emerald-600/90 text-white font-bold text-[10px] px-2 py-0.5 rounded-lg shadow">🥗 نباتي</span>`;
    } else if (dish.isSpicy) {
      badgesHtml += `<span class="dish-badge-pill bg-rose-700 text-white font-bold text-[10px] px-2 py-0.5 rounded-lg shadow">🌶️ حار</span>`;
    }

    return `
      <div class="dish-card cursor-pointer group active:scale-[0.98] transition ${isSoldOut ? 'opacity-60 grayscale-[40%]' : ''}" id="dish-card-${dish.id}" onclick="${isAvailableToOrder ? `addToCartDirect('${dish.id}')` : ''}">
        <div class="dish-card-img-container relative overflow-hidden">
          <div class="absolute top-2.5 right-2.5 z-20 flex flex-col gap-1.5 items-end">
            ${badgesHtml}
          </div>
          <img src="${dish.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'}" alt="${dish.name}" class="dish-card-img group-hover:scale-105 transition duration-300" loading="lazy" />
          
          ${isSoldOut ? `
            <div class="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-2 text-center z-20 backdrop-blur-[2px]">
              <span class="text-xl mb-1">🔒</span>
              <span class="bg-rose-600 text-white text-[11px] font-black px-2.5 py-1 rounded-full shadow-lg">نفد من المطعم ❌</span>
              <span class="text-[9px] text-slate-300 font-bold mt-0.5">غير متوفر حالياً</span>
            </div>
          ` : isStoreClosed ? `
            <div class="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-2 text-center z-20 backdrop-blur-[1px]">
              <span class="text-lg mb-0.5">🌙</span>
              <span class="bg-amber-500/90 text-slate-950 text-[11px] font-black px-2.5 py-1 rounded-full shadow-lg">المطعم مغلق حالياً</span>
            </div>
          ` : ''}
        </div>

        <div class="p-4 flex-1 flex flex-col justify-between">
          <div>
            <div class="flex justify-between items-start gap-2 mb-1">
              <h3 class="font-bold text-base text-white leading-tight group-hover:text-rose-400 transition">${dish.name}</h3>
              ${dish.calories ? `<span class="text-[11px] text-slate-400 font-mono whitespace-nowrap">⚡ ${dish.calories}</span>` : ''}
            </div>

            ${dish.nameEn ? `<div class="text-xs text-slate-400 font-medium mb-2">${dish.nameEn}</div>` : ''}

            <!-- عرض المكونات التفصيلية للطبق -->
            ${dish.ingredients ? `
              <div class="text-[11px] text-slate-300 bg-slate-950/70 p-2 rounded-xl border border-slate-800/80 mb-3 leading-relaxed">
                <span class="text-amber-400 font-bold">🌿 المكونات:</span> ${dish.ingredients}
              </div>
            ` : dish.description ? `
              <p class="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-3">
                ${dish.description}
              </p>
            ` : ''}
          </div>

          <div class="pt-3 border-t border-slate-800 flex items-center justify-between gap-2" onclick="event.stopPropagation()">
            <div>
              <div class="text-base font-black text-rose-400">
                ${dish.price.toLocaleString()} <span class="text-xs font-normal text-slate-400">${config.currency}</span>
              </div>
              ${dish.oldPrice ? `
                <div class="text-xs text-slate-500 line-through">
                  ${dish.oldPrice.toLocaleString()} ${config.currency}
                </div>
              ` : ''}
            </div>

            <!-- أزرار الإضافة المباشرة للسلة -->
            <div>
              ${!isOrderingAllowed ? `
                <span class="text-[11px] font-bold text-slate-500 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800">للعرض فقط</span>
              ` : isSoldOut ? `
                <button disabled class="py-1.5 px-3 bg-slate-900 border border-slate-800 text-slate-500 font-bold text-xs rounded-xl cursor-not-allowed opacity-70 flex items-center gap-1">
                  <span>❌</span>
                  <span>نفد الصنف</span>
                </button>
              ` : isStoreClosed ? `
                <button disabled class="py-1.5 px-3 bg-amber-950/40 border border-amber-800/40 text-amber-400 font-bold text-xs rounded-xl cursor-not-allowed opacity-80 flex items-center gap-1" title="المطعم مغلق حالياً">
                  <span>🌙</span>
                  <span>المطعم مغلق</span>
                </button>
              ` : inCartQty > 0 ? `
                <div class="qty-stepper">
                  <button onclick="changeQuantity('${dish.id}', -1)" class="qty-btn" aria-label="تقليل">−</button>
                  <span class="qty-count">${inCartQty}</span>
                  <button onclick="changeQuantity('${dish.id}', 1)" class="qty-btn" aria-label="زيادة">+</button>
                </div>
              ` : `
                <button onclick="addToCartDirect('${dish.id}')" class="btn-add-direct" aria-label="إضافة للسلة">
                  <span>+</span>
                  <span>إضافة</span>
                </button>
              `}
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// -------------------------------------------------------------
// عمليات السلة التلقائية (Cart Logic)
// -------------------------------------------------------------
function addToCartDirect(dishId) {
  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const fallbackDishes = DEFAULT_DISHES;
  const dishes = getStoredData('dishes', fallbackDishes);
  const config = getStoredData('config', getDefaultRestaurantConfig(restId));
  const storeStatus = checkRestaurantOpenStatus(config);

  if (!storeStatus.isOpen || config.is_active === false) {
    alert("عزيزنا الزبون، المطعم مغلق حالياً ولا يمكن استقبال طلبات جديدة في الوقت الحالي.");
    return;
  }

  const dish = dishes.find(d => String(d.id) === String(dishId));
  if (!dish || dish.available === false || dish.is_available === false || dish.status === 'out_of_stock') {
    alert("عذراً، هذا الصنف نفد من المطعم وغير متوفر حالياً.");
    return;
  }

  const existing = cart.find(item => String(item.id) === String(dishId));
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      id: dish.id,
      name: dish.name,
      price: dish.price,
      image: dish.image,
      quantity: 1
    });
  }

  setStoredData('cart', cart);
  updateCartUI();
  renderMenuDishes();
}

function changeQuantity(dishId, delta) {
  const existingIndex = cart.findIndex(item => item.id === dishId);
  if (existingIndex === -1) return;

  cart[existingIndex].quantity += delta;
  if (cart[existingIndex].quantity <= 0) {
    cart.splice(existingIndex, 1);
  }

  setStoredData('cart', cart);
  updateCartUI();
  renderMenuDishes();
}

function updateCartUI() {
  const hasFishInCart = cart.some(it => it.id === 'fd_fish_masgouf' || it.isWeighted || (it.name && it.name.includes('سمك')));
  const fishSelector = document.getElementById('cart-fish-weight-selector');
  if (fishSelector) {
    if (hasFishInCart) {
      fishSelector.classList.remove('hidden');
      const approxWeightEl = document.getElementById('checkout-fish-approx-weight');
      if (approxWeightEl) {
        const valStr = (approxWeightEl.value || '').trim();
        const parsedW = parseFloat(valStr);
        const hasWeight = !isNaN(parsedW) && parsedW > 0;
        const w = hasWeight ? parsedW : null;
        cart.forEach(it => {
          if (it.id === 'fd_fish_masgouf' || it.isWeighted || (it.name && it.name.includes('سمك'))) {
            it.approxWeight = w;
            const uPrice = it.unitPrice || 10000;
            if (hasWeight) {
              it.price = Math.round(uPrice * w);
              it.name = 'سمك مسكوف عراقي بالوزن (' + w.toFixed(1) + ' كغم)';
            } else {
              it.price = 0;
              it.name = 'سمك مسكوف عراقي بالوزن (سعر الكيلو 10,000 د.ع)';
            }
          }
        });
        const livePriceEl = document.getElementById('checkout-fish-live-price');
        if (livePriceEl) {
          if (hasWeight) {
            livePriceEl.textContent = (Math.round(10000 * w)).toLocaleString() + ' د.ع (لوزن ' + w.toFixed(1) + ' كغم)';
          } else {
            livePriceEl.textContent = 'أدخل الوزن لمعاينة السعر (مثال: 1.5 كغم)';
          }
        }
      }
    } else {
      fishSelector.classList.add('hidden');
    }
  }
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const isTakeawayActive = (config.takeawayPackageActive === true) && (config.allowTakeawayOrders === true);
  const isDineInActive = (config.allowDineInOrders === true);
  const isOrderingAllowed = (config.planType !== 'basic') && (isTakeawayActive || isDineInActive);

  // تحديث زر السلة العلوي قرب تسجيل الدخول
  const headerCartBtn = document.getElementById('header-cart-btn');
  const headerCartCount = document.getElementById('header-cart-count');
  const headerCartTotal = document.getElementById('header-cart-total');

  if (headerCartBtn) {
    if (isOrderingAllowed) {
      headerCartBtn.classList.remove('hidden');
      if (headerCartCount) headerCartCount.textContent = totalCount;
      if (headerCartTotal) headerCartTotal.textContent = `${totalPrice.toLocaleString()} ${config.currency}`;
    } else {
      headerCartBtn.classList.add('hidden');
    }
  }

  // تحديث درج السلة المنزلق
  renderCartDrawerItems(totalPrice, config.currency);
}

function setCustomerFishWeight(w) {
  const el = document.getElementById('checkout-fish-approx-weight');
  if (el) {
    el.value = w;
    updateCartUI();
  }
}
window.setCustomerFishWeight = setCustomerFishWeight;

function renderCartDrawerItems(totalPrice, currency) {
  const container = document.getElementById('cart-items-container');
  const totalDisplay = document.getElementById('cart-drawer-total');
  const emptyDisplay = document.getElementById('cart-drawer-empty');
  const checkoutSection = document.getElementById('cart-checkout-section');
  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = '';
    if (emptyDisplay) emptyDisplay.classList.remove('hidden');
    if (checkoutSection) checkoutSection.classList.add('hidden');
    if (totalDisplay) totalDisplay.textContent = `0 ${currency}`;
    return;
  }

  if (emptyDisplay) emptyDisplay.classList.add('hidden');
  if (checkoutSection) checkoutSection.classList.remove('hidden');
  if (totalDisplay) totalDisplay.textContent = `${totalPrice.toLocaleString()} ${currency}`;

  container.innerHTML = cart.map(item => `
    <div class="flex items-center justify-between p-3 bg-slate-800/80 rounded-2xl border border-slate-700/60 gap-3">
      <img src="${item.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100'}" class="w-14 h-14 rounded-xl object-cover" />
      
      <div class="flex-1 min-w-0">
        <h4 class="font-bold text-white text-sm truncate">${item.name}</h4>
        <div class="text-xs text-rose-400 font-black mt-0.5">
          ${(item.price * item.quantity).toLocaleString()} ${currency}
        </div>
      </div>

      <div class="qty-stepper">
        <button onclick="changeQuantity(${item.id}, -1)" class="qty-btn">−</button>
        <span class="qty-count">${item.quantity}</span>
        <button onclick="changeQuantity(${item.id}, 1)" class="qty-btn">+</button>
      </div>
    </div>
  `).join('');
}

function openCartDrawer() {
  updateAppBranding();
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const selectorWrapper = document.getElementById('order-type-selector-wrapper');
  const dineInBtn = document.getElementById('order-type-dine-in');
  const takeawayBtn = document.getElementById('order-type-takeaway');
  const tableGroup = document.getElementById('checkout-table-group');
  const deliveryGroup = document.getElementById('checkout-delivery-group');

  const isDineInAllowed = (config.allowDineInOrders === true);
  const isTakeawayAllowed = (config.takeawayPackageActive === true) && (config.allowTakeawayOrders === true);

  // 1. إذا كانت الصالة مفعلة والسفري مفعل معاً: نظهر أزرار التبديل كاملة
  if (isDineInAllowed && isTakeawayAllowed) {
    if (selectorWrapper) selectorWrapper.classList.remove('hidden');
    if (dineInBtn) dineInBtn.classList.remove('hidden');
    if (takeawayBtn) takeawayBtn.classList.remove('hidden');
    selectOrderType(currentOrderType || 'dine-in');
  } 
  // 2. إذا كانت الصالة فقط مفعلة (السفري غير مفعل): نجعل السلة حصراً لطلب الصالة ونخفي زر السفري
  else if (isDineInAllowed && !isTakeawayAllowed) {
    if (selectorWrapper) selectorWrapper.classList.add('hidden');
    if (dineInBtn) dineInBtn.classList.remove('hidden');
    if (takeawayBtn) takeawayBtn.classList.add('hidden');
    selectOrderType('dine-in');
  } 
  // 3. إذا كان السفري فقط مفعل (طلب الصالة مقفل): نجعل السلة حصراً لطلب التوصيل والسفري ونخفي زر الصالة
  else if (!isDineInAllowed && isTakeawayAllowed) {
    if (selectorWrapper) selectorWrapper.classList.add('hidden');
    if (dineInBtn) dineInBtn.classList.add('hidden');
    if (takeawayBtn) takeawayBtn.classList.remove('hidden');
    selectOrderType('takeaway');
  } 
  // 4. إذا كان الاثنان مقفلين
  else {
    if (selectorWrapper) selectorWrapper.classList.add('hidden');
    if (tableGroup) tableGroup.classList.add('hidden');
    if (deliveryGroup) deliveryGroup.classList.add('hidden');
  }

  // فحص أوقات العمل الرسمية عند فتح السلة
  const storeStatus = (typeof checkRestaurantOpenStatus === 'function') ? checkRestaurantOpenStatus(config) : { isOpen: true };
  const closedNotice = document.getElementById('cart-closed-notice');
  const noticeHours = document.getElementById('cart-notice-hours');
  const submitBtn = document.getElementById('submit-order-btn');

  if (!storeStatus.isOpen) {
    if (closedNotice) closedNotice.classList.remove('hidden');
    if (noticeHours) noticeHours.textContent = config.workingHours || storeStatus.workingHoursText;
    if (submitBtn) {
      submitBtn.innerHTML = `<span>📅 إرسال وتثبيت الطلب كحجز مسبق لليوم التالي</span><span>🚀</span>`;
      submitBtn.className = "w-full py-3.5 px-4 bg-gradient-to-r from-purple-700 via-rose-700 to-amber-600 hover:from-purple-600 hover:to-amber-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-purple-900/30 transition flex items-center justify-center gap-2 active:scale-95";
    }
  } else {
    if (closedNotice) closedNotice.classList.add('hidden');
    if (submitBtn) {
      submitBtn.className = "w-full py-3.5 px-4 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-black text-sm rounded-2xl shadow-xl shadow-rose-600/30 transition flex items-center justify-center gap-2 active:scale-95";
    }
  }

  document.getElementById('cart-drawer-modal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeCartDrawer() {
  document.getElementById('cart-drawer-modal').classList.add('hidden');
  document.body.style.overflow = 'auto';
}

function selectOrderType(type) {
  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const isDineInAllowed = (config.allowDineInOrders === true);
  const isTakeawayAllowed = (config.takeawayPackageActive === true) && (config.allowTakeawayOrders === true);

  if (type === 'dine-in' && !isDineInAllowed) {
    if (isTakeawayAllowed) type = 'takeaway';
    else return;
  }
  if ((type === 'takeaway' || type === 'delivery') && !isTakeawayAllowed) {
    if (isDineInAllowed) type = 'dine-in';
    else return;
  }

  currentOrderType = type;

  // تحديث حالة الأزرار
  const dineInBtn = document.getElementById('order-type-dine-in');
  const takeawayBtn = document.getElementById('order-type-takeaway');
  const submitBtn = document.getElementById('submit-order-btn');
  const storeStatus = (typeof checkRestaurantOpenStatus === 'function') ? checkRestaurantOpenStatus(config) : { isOpen: true };

  [dineInBtn, takeawayBtn].forEach(btn => {
    if (btn) {
      btn.classList.remove('bg-rose-600', 'text-white', 'border-rose-500');
      btn.classList.add('bg-slate-800', 'text-slate-300', 'border-slate-700');
    }
  });

  const activeBtn = type === 'dine-in' ? dineInBtn : takeawayBtn;
  if (activeBtn) {
    activeBtn.classList.remove('bg-slate-800', 'text-slate-300', 'border-slate-700');
    activeBtn.classList.add('bg-rose-600', 'text-white', 'border-rose-500');
  }

  // إظهار/إخفاء الحقول المناسبة
  const tableGroup = document.getElementById('checkout-table-group');
  const deliveryGroup = document.getElementById('checkout-delivery-group');

  if (type === 'dine-in') {
    if (tableGroup) tableGroup.classList.remove('hidden');
    if (deliveryGroup) deliveryGroup.classList.add('hidden');
    if (submitBtn) {
      if (!storeStatus.isOpen) {
        submitBtn.innerHTML = `<span>📅 حجز طاولة ووجبات لليوم التالي</span><span>🚀</span>`;
      } else {
        submitBtn.innerHTML = `<span>👨‍🍳 إرسال طلب الطاولة للمطبخ والكاشير</span><span>🖨️</span>`;
      }
    }
  } else {
    if (tableGroup) tableGroup.classList.add('hidden');
    if (deliveryGroup) deliveryGroup.classList.remove('hidden');
    if (submitBtn) {
      if (!storeStatus.isOpen) {
        submitBtn.innerHTML = `<span>📅 إرسال وتثبيت الطلب كحجز مسبق لليوم التالي</span><span>🚀</span>`;
      } else {
        submitBtn.innerHTML = `<span>🛵 إرسال طلب التوصيل والسفري للكاشير</span><span>⚡</span>`;
      }
    }
  }
}

// -------------------------------------------------------------
// تحديد موقع الزبون عبر GPS والخريطة
// -------------------------------------------------------------
function captureCustomerGPS() {
  const btn = document.getElementById('gps-locate-btn');
  const badge = document.getElementById('gps-status-badge');
  const mapInput = document.getElementById('checkout-map-url');

  if (!navigator.geolocation) {
    alert("خاصية تحديد الموقع الجغرافي غير مدعومة في متصفحك. يرجى كتابة عنوانك في الحقل.");
    return;
  }

  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span>⏳ جاري تحديد موقعك بدقة عبر الأقمار الصناعية GPS...</span>`;
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      const mapUrl = `https://www.google.com/maps?q=${lat},${lng}`;
      
      if (mapInput) mapInput.value = mapUrl;

      if (badge) {
        badge.textContent = "🎯 تم تحديد موقعك بالـ GPS";
        badge.className = "text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30";
      }

      if (btn) {
        btn.disabled = false;
        btn.className = "w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2";
        btn.innerHTML = `<span>✅ تم حفظ إحداثيات موقعك بنجاح</span>`;
      }
    },
    (err) => {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<span>📍 إعادة محاولة تحديد الموقع بالـ GPS</span>`;
      }
      alert("يرجى تفعيل أو السماح بصلاحية الموقع الجغرافي (Location Permission) في المتصفح لتحديد موقعك تلقائياً، أو كتابة عنوانك يدوياً.");
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
  );
}

function showTakeawayPackageModal() {
  const modal = document.getElementById('takeaway-package-modal');
  if (modal) modal.classList.remove('hidden');
}

function closeTakeawayPackageModal() {
  const modal = document.getElementById('takeaway-package-modal');
  if (modal) modal.classList.add('hidden');
}

function showDineInLockedModal() {
  const modal = document.getElementById('dinein-locked-modal');
  if (modal) modal.classList.remove('hidden');
}

function closeDineInLockedModal() {
  const modal = document.getElementById('dinein-locked-modal');
  if (modal) modal.classList.add('hidden');
}

function populateTableOptions() {
  const select = document.getElementById('checkout-table-select');
  if (!select) return;

  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const tablesCount = config.tablesCount || 20;

  let options = '<option value="">اختر رقم الطاولة...</option>';
  for (let i = 1; i <= tablesCount; i++) {
    const isSelected = selectedTableNumber === i ? 'selected' : '';
    options += `<option value="${i}" ${isSelected}>طاولة رقم ${i}</option>`;
  }
  select.innerHTML = options;
}

// -------------------------------------------------------------
// إرسال الطلب العام (صالة أو توصيل أونلاين للكاشير)
// -------------------------------------------------------------
function submitCustomerOrder() {
  if (cart.length === 0) {
    alert("السلة فارغة، يرجى إضافة أطباق أولاً!");
    return;
  }

  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);

  // 1. إذا كان نوع الطلب صالة
  let finalTableNum = null;
  if (currentOrderType === 'dine-in') {
    if (!config.allowDineInOrders) {
      showDineInLockedModal();
      return;
    }
    const select = document.getElementById('checkout-table-select');
    finalTableNum = selectedTableNumber;
    if (select && select.value) {
      finalTableNum = parseInt(select.value);
    }
    if (!finalTableNum) {
      finalTableNum = 1;
    }
  }

  // 2. إذا كان نوع الطلب استلام أو توصيل أونلاين
  let customerName = '';
  let customerPhone = '';
  let customerAddress = '';
  let mapUrl = '';

  if (currentOrderType === 'takeaway' || currentOrderType === 'delivery') {
    if (!config.takeawayPackageActive) {
      showTakeawayPackageModal();
      return;
    }

    customerName = document.getElementById('checkout-name')?.value?.trim() || '';
    customerPhone = document.getElementById('checkout-phone')?.value?.trim() || '';
    customerAddress = document.getElementById('checkout-address')?.value?.trim() || '';
    mapUrl = document.getElementById('checkout-map-url')?.value?.trim() || '';

    if (!customerPhone) {
      alert("يرجى إدخال رقم الهاتف للتواصل وتأكيد طلب التوصيل!");
      document.getElementById('checkout-phone')?.focus();
      return;
    }

    // إذا لم يتم جلب GPS ولكن تمت كتابة العنوان، نصنع رابط بحث في خرائط جوجل
    if (!mapUrl && customerAddress) {
      mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(customerAddress)}`;
    }
  }

  const notes = document.getElementById('checkout-notes')?.value?.trim() || '';
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const orderId = 'ORD-' + Math.floor(1000 + Math.random() * 9000);

  // فحص أوقات وساعات العمل الرسمية
  const storeStatus = (typeof checkRestaurantOpenStatus === 'function') 
    ? checkRestaurantOpenStatus(config) 
    : { isOpen: true };

  const isClosedNow = !storeStatus.isOpen;
  const preferredTime = document.getElementById('checkout-preorder-time')?.value || 'مع بداية افتتاح المطعم غداً';

  // إذا كان المطعم مغلقاً وتم إلغاء خاصية الحجز المسبق
  if (isClosedNow && config.allowPreorderNextDay === false) {
    alert(`عذراً، المطعم مغلق حالياً خارج أوقات العمل الرسمية (${config.workingHours || storeStatus.workingHoursText}) ولا يستقبل طلبات جديدة في الوقت الراهن.`);
    return;
  }

  let finalNotes = notes;
  if (isClosedNow) {
    finalNotes = `[📅 حجز مسبق لليوم التالي: ${preferredTime}]` + (notes ? ` - ${notes}` : '');
  }

  const newOrder = {
    id: orderId,
    type: currentOrderType === 'dine-in' ? 'dine-in' : 'delivery',
    tableNumber: currentOrderType === 'dine-in' ? finalTableNum : null,
    items: [...cart],
    notes: finalNotes,
    customerName: customerName,
    customerPhone: customerPhone,
    customerAddress: customerAddress,
    mapUrl: mapUrl,
    total: total,
    currency: config.currency,
    status: 'pending_cashier', // بانتظار موافقة الكاشير
    source: 'online_menu',
    isPreorder: isClosedNow,
    preorderDate: isClosedNow ? 'غداً' : null,
    preorderPreferredTime: isClosedNow ? preferredTime : null,
    timestamp: Date.now()
  };

  // حفظ في قائمة الطلبات المركزية محلياً
  const orders = getStoredData('orders', []);
  orders.unshift(newOrder);
  setStoredData('orders', orders);

  // إرسال الطلب فورياً عبر سحابة Supabase (Realtime Broadcast + Database)
  if (typeof sendOrderToSupabaseCloud === 'function') {
    sendOrderToSupabaseCloud(newOrder);
  }

  // إفراغ السلة وتحديث الواجهة
  cart = [];
  setStoredData('cart', []);
  updateCartUI();
  renderMenuDishes();
  closeCartDrawer();
  updateKitchenBadge();

  // عرض نافذة نجاح الطلب
  showOrderSuccessModal(newOrder);
}

// -------------------------------------------------------------
// إرسال الطلب السحابي الفوري للكاشير (Supabase Cloud Sync & Realtime)
// -------------------------------------------------------------
async function sendOrderToSupabaseCloud(order) {
  if (!order || !order.id) return;
  const client = (typeof getSupabase === 'function') ? getSupabase() : ((typeof getSupabaseClient === 'function') ? getSupabaseClient() : null);
  // client check

  const restId = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const totalVal = parseFloat(order.total) || 0;

  // إزالة الصور والبيانات الثقيلة للحفاظ على السعة المجانية وضمان سرعة الشبكة
  const cleanItems = (Array.isArray(order.items) ? order.items : []).map(i => ({
    id: String(i.id || ''),
    name: i.name || '',
    price: Number(i.price) || 0,
    quantity: Number(i.quantity || i.qty) || 1,
    weight: i.weight !== undefined && i.weight !== null ? Number(i.weight) : null,
    isWeighted: !!i.isWeighted,
    pricePerKg: i.pricePerKg ? Number(i.pricePerKg) : null,
    notes: i.notes || i.customerNote || ''
  }));

  const dbPayload = {
    id: String(order.id),
    restaurant_id: restId,
    type: (order.type === 'takeaway' || order.type === 'delivery') ? order.type : 'dine-in',
    table_number: order.tableNumber ? parseInt(order.tableNumber) : null,
    customer_name: order.customerName || (order.tableNumber ? `طاولة ${order.tableNumber}` : 'زبون خارجي'),
    customer_phone: order.customerPhone || '',
    customer_address: order.customerAddress || '',
    map_url: order.mapUrl || '',
    items: cleanItems,
    notes: order.notes || '',
    total: totalVal,
    currency: order.currency || 'د.ع',
    status: 'pending_cashier',
    source: 'customer',
    created_at: new Date(order.timestamp || Date.now()).toISOString(),
    updated_at: new Date(order.timestamp || Date.now()).toISOString()
  };

  let synced = false;

  // 1. الإرسال عبر Supabase JS Client (الطبقة الأولى)
  try {
    const client = (typeof getSupabase === 'function') ? getSupabase() : ((typeof getSupabaseClient === 'function') ? getSupabaseClient() : null);
    if (client) {
      const { error } = await client.from('restaurant_orders').upsert([dbPayload]);
      if (!error) {
        synced = true;
        console.log("✅ Customer order persisted to Supabase via SDK:", order.id);
      } else {
        console.warn("Supabase SDK order upsert notice:", error.message);
      }
    }
  } catch (e) {
    console.warn("Supabase SDK order dispatch error:", e);
  }

  // 2. الإرسال الاحتياطي المباشر عبر REST API (الطبقة الثانية المضمونة)
  if (!synced) {
    try {
      const sbUrl = (typeof getActiveSupabaseUrl === 'function') ? getActiveSupabaseUrl() : DEFAULT_SUPABASE_URL;
      const sbKey = (typeof getActiveSupabaseAnonKey === 'function') ? getActiveSupabaseAnonKey() : DEFAULT_SUPABASE_ANON_KEY;
      const resp = await fetch(`${sbUrl}/rest/v1/restaurant_orders`, {
        method: 'POST',
        headers: {
          'apikey': sbKey,
          'Authorization': `Bearer ${sbKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify(dbPayload)
      });
      if (resp.ok) {
        synced = true;
        console.log("✅ Customer order persisted to Supabase via direct REST fallback:", order.id);
      } else {
        const errTxt = await resp.text();
        console.warn("Direct REST fallback notice:", resp.status, errTxt);
      }
    } catch (restErr) {
      console.warn("Direct REST fallback exception:", restErr);
    }
  }

  // 3. بث فوري عبر قنوات Realtime WebSocket لإشعار الكاشير فورياً بالرنين
  try {
    const client = (typeof getSupabase === 'function') ? getSupabase() : ((typeof getSupabaseClient === 'function') ? getSupabaseClient() : null);
    if (client) {
      // بث عبر قناة المطعم
      const ch1 = client.channel(`orders_channel_${restId}`);
      ch1.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          ch1.send({
            type: 'broadcast',
            event: 'new_customer_order',
            payload: dbPayload
          });
        }
      });

      // بث إضافي عبر قناة الكاشير العامة
      const ch2 = client.channel('cashier-live-orders');
      ch2.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          ch2.send({
            type: 'broadcast',
            event: 'new_customer_order',
            payload: dbPayload
          });
        }
      });
    }
  } catch (bcErr) {
    console.warn("Realtime broadcast error:", bcErr);
  }

  // 4. استماع الزبون لمتابعة حالة طلبه مباشرة (في المطبخ / جاهز للتقديم)
  listenToMyOrderStatus(order.id);
}

// دالة تتبع الزبون لحالة طلبه اللحظية
function listenToMyOrderStatus(orderId) {
  try {
    const client = (typeof getSupabase === 'function') ? getSupabase() : ((typeof getSupabaseClient === 'function') ? getSupabaseClient() : null);
    if (!client) return;

    client
      .channel(`order-track-${orderId}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'restaurant_orders',
        filter: `id=eq.${orderId}`
      }, (payload) => {
        const nextStatus = payload.new ? payload.new.status : null;
        if (nextStatus) {
          renderCustomerOrderStatusUpdate(nextStatus);
        }
      })
      .subscribe();
  } catch (e) {
    console.warn("Order tracking subscribe error:", e);
  }
}

function renderCustomerOrderStatusUpdate(status) {
  const badge = document.getElementById('success-order-status-badge');
  const title = document.getElementById('success-modal-title');
  const subtitle = document.getElementById('success-modal-subtitle');

  if (status === 'in_kitchen' || status === 'in-kitchen' || status === 'preparing') {
    if (badge) {
      badge.textContent = '👨‍🍳 جاري التحضير في المطبخ الآن';
      badge.className = 'px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full text-xs font-black animate-pulse';
    }
    if (title) title.textContent = 'طلبكم قيد التجهيز في المطبخ! 🔥';
  } else if (status === 'served' || status === 'ready') {
    if (badge) {
      badge.textContent = '🍽️ الوجبة جاهزة وتُقدم لطاولتكم';
      badge.className = 'px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-xs font-black';
    }
    if (title) title.textContent = 'الوجبة جاهزة! بالهناء والشفاء ✨';
  } else if (status === 'completed' || status === 'paid') {
    if (badge) {
      badge.textContent = '✅ تم دفع الحساب وإنهاء الجلسة';
      badge.className = 'px-3 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/40 rounded-full text-xs font-black';
    }
  }
}

// دالة مساعدة للتوافق
function submitDineInOrder() {
  submitCustomerOrder();
}

function showOrderSuccessModal(order) {
  const modal = document.getElementById('order-success-modal');
  const iconEl = document.getElementById('success-modal-icon');
  const titleEl = document.getElementById('success-modal-title');
  const subtitleEl = document.getElementById('success-modal-subtitle');
  const detailsEl = document.getElementById('success-order-details');
  const contactBox = document.getElementById('success-contact-box');
  const contactLabel = document.getElementById('success-contact-label');
  const phoneText = document.getElementById('order-success-restaurant-phone-text');
  const phoneBtn = document.getElementById('order-success-restaurant-phone-btn');
  if (!modal) return;

  const config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);
  const isDineIn = order.type === 'dine-in';
  const restPhone = config.phone || '+9647700000000';

  // 1. رسائل الترحيب والأيقونة المخصصة
  if (order.isPreorder) {
    if (iconEl) iconEl.textContent = '📅';
    if (titleEl) titleEl.textContent = `تم تسجيل حجزكم المسبق لليوم التالي بنجاح! ✨`;
    if (subtitleEl) subtitleEl.textContent = `المطعم مغلق حالياً خارج أوقات العمل الرسمية. تم إرسال حجزكم لإدارة المطعم وسيتم البدء بتجهيزه فور افتتاح المطعم غداً (${order.preorderPreferredTime || 'مع بداية الافتتاح'}) إن شاء الله! 👨‍🍳`;
  } else if (isDineIn) {
    if (iconEl) iconEl.textContent = '🍽️';
    if (titleEl) titleEl.textContent = `أهلاً وسهلاً بكم في ${config.name}! 🍽️`;
    if (subtitleEl) subtitleEl.textContent = `تم إرسال طلبكم لطاولة رقم [ ${order.tableNumber} ] بنجاح إلى المطبخ، شيف المطعم يجهّز وجبتكم الساخنة الآن بكل حب! بالصحة والعافية ✨`;
  } else {
    if (iconEl) iconEl.textContent = '🛵';
    if (titleEl) titleEl.textContent = `شكراً لطلبكم من ${config.name}! 🛵`;
    if (subtitleEl) subtitleEl.textContent = `تم استلام طلبكم بنجاح وجاري تحضيره في المطبخ لتسليمه ساخناً وطازجاً في أسرع وقت ✨`;
  }

  // 2. تفاصيل الفاتورة
  if (detailsEl) {
    detailsEl.innerHTML = `
      <div class="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700 text-right text-xs space-y-2 mb-1">
        ${order.isPreorder ? `
          <div class="bg-gradient-to-r from-purple-900/60 to-amber-900/40 p-2.5 rounded-xl border border-amber-500/40 text-amber-200 font-bold text-center mb-1">
            <span>📅 موعد تجهيز الحجز:</span>
            <span class="text-white font-black">غداً (${order.preorderPreferredTime || 'مع بداية الافتتاح'}) ✨</span>
          </div>
        ` : ''}
        <div class="flex justify-between items-center pb-1.5 border-b border-slate-700">
          <span class="text-slate-400">رقم الفاتورة:</span>
          <span class="font-mono font-black text-rose-400 text-sm">#${order.id}</span>
        </div>
        <div class="flex justify-between items-center">
          <span class="text-slate-400">نوع الطلب:</span>
          <span class="font-bold text-white">${isDineIn ? `🍽️ داخل الصالة (طاولة رقم ${order.tableNumber})` : '🛵 طلب توصيل وسفري أونلاين'}</span>
        </div>
        ${order.customerPhone ? `
          <div class="flex justify-between items-center">
            <span class="text-slate-400">هاتف الزبون:</span>
            <span class="font-mono text-slate-200">${order.customerPhone}</span>
          </div>
        ` : ''}
        ${order.customerAddress ? `
          <div class="text-[11px] text-slate-300">
            <span class="text-slate-400">عنوان التوصيل:</span> ${order.customerAddress}
          </div>
        ` : ''}
        <div class="flex justify-between items-center pt-2 border-t border-slate-700">
          <span class="text-slate-300 font-bold">المجموع الكلي:</span>
          <span class="font-black text-rose-400 text-sm">${order.total.toLocaleString()} ${order.currency}</span>
        </div>
      </div>
    `;
  }

  // 3. صندوق التوجيه / رقم هاتف المطعم (معتمد حصراً من إعدادات المطعم وليس رقم المبرمج)
  if (isDineIn) {
    if (contactLabel) contactLabel.textContent = "✨ كابتن الصالة في خدمتكم دائماً لأي طلب إضافي أو مساعدة.";
    if (phoneText) phoneText.textContent = `طاولة رقم [ ${order.tableNumber} ] - نتشرف بزيارتكم`;
    if (phoneBtn) phoneBtn.classList.add('hidden');
  } else {
    if (contactLabel) contactLabel.textContent = `لأي استفسار أو متابعة مع إدارة ${config.name}:`;
    if (phoneText) phoneText.textContent = restPhone;
    if (phoneBtn) {
      phoneBtn.classList.remove('hidden');
      phoneBtn.href = `tel:${restPhone.replace(/\s+/g, '')}`;
      phoneBtn.innerHTML = `<span>📞 الاتصال المباشر بالمطعم (${restPhone})</span>`;
    }
  }

  modal.classList.remove('hidden');
}

function closeSuccessModal() {
  document.getElementById('order-success-modal').classList.add('hidden');
}

// -------------------------------------------------------------
// تنبيه قفل خيار الواتساب المباشر مؤقتاً (Meta WhatsApp Cloud API Requirement)
// -------------------------------------------------------------
function triggerWhatsAppLockedAlert() {
  const modal = document.getElementById('whatsapp-locked-modal');
  if (modal) modal.classList.remove('hidden');
}

function closeWhatsAppLockedModal() {
  const modal = document.getElementById('whatsapp-locked-modal');
  if (modal) modal.classList.add('hidden');
}

// -------------------------------------------------------------
// نافذة نبذة عن مكتب emattec
// -------------------------------------------------------------
function openAboutEmattecModal() {
  const modal = document.getElementById('about-emattec-modal');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeAboutEmattecModal() {
  const modal = document.getElementById('about-emattec-modal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

function openUnifiedLoginModal() {
  window.location.href = 'login.html';
}

function closeUnifiedLoginModal() {
  const modal = document.getElementById('unified-login-modal');
  if (modal) modal.classList.add('hidden');
}

async function handleModalUnifiedLogin() {
  const userIn = document.getElementById('modal-login-username');
  const pinIn = document.getElementById('modal-login-pin');
  const errEl = document.getElementById('modal-login-error');
  const btn = document.getElementById('modal-login-btn');

  const username = userIn ? userIn.value.trim() : '';
  const pin = pinIn ? pinIn.value : '';

  if (!username) {
    if (errEl) {
      errEl.textContent = 'يرجى إدخال اسم المستخدم!';
      errEl.classList.remove('hidden');
    }
    return;
  }

  if (btn) btn.textContent = 'جاري التحقق... ⏳';

  const res = typeof loginUserAsync === 'function' 
    ? await loginUserAsync(username, pin) 
    : { success: false, message: 'خطأ في المصادقة' };

  if (btn) btn.textContent = 'تسجيل الدخول 🚀';

  if (res.success) {
    if (errEl) errEl.classList.add('hidden');
    closeUnifiedLoginModal();
    const targetRest = res.restaurantId || (typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : 'fahma_dokhan');
    const restParam = targetRest ? `?rest=${encodeURIComponent(targetRest)}` : '';

    if (res.role === 'super_admin' || res.role === 'assistant_super_admin') {
      window.location.href = 'super-admin.html';
    } else if (res.role === 'admin') {
      window.location.href = 'admin.html' + restParam;
    } else if (res.role === 'cashier') {
      window.location.href = 'cashier.html' + restParam;
    } else if (res.role === 'captain') {
      window.location.href = 'captain.html' + restParam;
    } else {
      window.location.href = 'index.html' + restParam;
    }
  } else {
    if (errEl) {
      errEl.textContent = res.message || 'اسم المستخدم أو كلمة المرور غير صحيحة!';
      errEl.classList.remove('hidden');
    }
    if (pinIn) {
      pinIn.value = '';
      pinIn.focus();
    }
  }
}

function openProtectedAdminView() {
  openUnifiedLoginModal();
}

function closeAdminPinModal() {
  closeUnifiedLoginModal();
}

function verifyAdminPin() {
  handleModalUnifiedLogin();
}

function lockAdminSession() {
  if (typeof logoutSession === 'function') {
    logoutSession('index.html');
  }
}

try {
  window.addEventListener('DOMContentLoaded', () => {
    try {
      const p = new URLSearchParams(window.location.search);
      if (p.has('login') || p.has('openLogin') || p.has('superadmin') || p.has('auth')) {
        setTimeout(openUnifiedLoginModal, 350);
      }
    } catch(e) {}
  });
} catch(e) {}


// -------------------------------------------------------------
// التبديل بين واجهات التطبيق (Menu / Admin / QR / Landing)
// -------------------------------------------------------------
function switchView(viewName) {
  if (viewName === 'admin' && !isAdminAuthenticated) {
    openProtectedAdminView();
    return;
  }

  const views = ['menu-view', 'admin-view', 'qr-view', 'landing-view'];
  views.forEach(v => {
    const el = document.getElementById(v);
    if (el) el.classList.add('hidden');
  });

  const target = document.getElementById(`${viewName}-view`);
  if (target) target.classList.remove('hidden');

  // تحديث أشرطة التبويب
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.classList.remove('text-rose-400', 'font-black');
    btn.classList.add('text-slate-400');
  });
  const activeBtn = document.getElementById(`nav-btn-${viewName}`);
  if (activeBtn) {
    activeBtn.classList.remove('text-slate-400');
    activeBtn.classList.add('text-rose-400', 'font-black');
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (viewName === 'admin') {
    initAdmin();
  }
}

function updateKitchenBadge() {
  const orders = getStoredData('orders', []);
  const newOrders = orders.filter(o => o.status === 'new').length;
  const badge = document.getElementById('admin-badge-count');
  if (badge) {
    if (newOrders > 0) {
      badge.textContent = newOrders;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  }
}

// -------------------------------------------------------------
// مزامنة إعدادات وحالة تفعيل باقة المطعم من Supabase لحظياً
// -------------------------------------------------------------
async function syncRestaurantConfigFromSupabase() {
  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : DEFAULT_RESTAURANT_ID;
  if (!client) return;

  try {
    const { data, error } = await client.from('restaurants').select('*').eq('id', restId).single();
    if (data && !error) {
      let config = getStoredData('config', DEFAULT_RESTAURANT_CONFIG);

      // قراءة وتحديث اسم ووصف المطعم مباشرة من Supabase
      if (data.name) config.name = data.name;
      if (data.name_en) config.nameEn = data.name_en;
      if (data.tagline) config.tagline = data.tagline;
      if (data.tagline_en) config.taglineEn = data.tagline_en;

      // نقل وتحديث كافة بيانات المطعم من Supabase
      if (data.phone) config.phone = data.phone;
      if (data.phone2 !== undefined) config.phone2 = data.phone2 || '';
      
      // الواتساب ورابطه الحي
      if (data.whatsapp_url) config.whatsappUrl = data.whatsapp_url;
      if (data.whatsapp_number) config.whatsappNumber = data.whatsapp_number;
      if (!config.whatsappUrl && (data.whatsapp_number || data.phone)) {
        const rawWa = (data.whatsapp_number || data.phone || '').replace(/\D/g, '').replace(/^0+/, '');
        config.whatsappUrl = `https://wa.me/${rawWa.startsWith('964') ? rawWa : '964' + rawWa}`;
      }

      // العنوان وموقع خرائط Google Maps
      if (data.address) config.address = data.address;
      if (data.maps_url || data.map_url) config.mapUrl = data.maps_url || data.map_url;

      // أوقات الدوام والعطل والواي فاي
      if (data.working_hours) config.workingHours = data.working_hours;
      if (data.open_time) config.openTime = data.open_time;
      if (data.close_time) config.closeTime = data.close_time;
      if (data.holidays) config.holidays = data.holidays;
      if (data.wifi_name) config.wifiName = data.wifi_name;
      if (data.wifi_pass) config.wifiPass = data.wifi_pass;

      // العملة وعدد الطاولات وحجم الورق
      if (data.currency) config.currency = data.currency;
      if (data.currency_en) config.currencyEn = data.currency_en;
      if (data.tables_count) config.tablesCount = Number(data.tables_count);
      if (data.printer_paper_size) config.printerPaperSize = data.printer_paper_size;
      if (data.published_url) config.publishedUrl = data.published_url;

      // شعار وهوية المطعم من Supabase حصراً
      if (data.logo !== undefined && data.logo !== null && data.logo.trim() !== '') {
        config.logo = data.logo.trim();
      } else {
        config.logo = 'logo.svg';
      }

      // صلاحيات وباقات الطلبات
      config.allowDineInOrders = (data.allow_dinein_orders === true);
      config.allowTakeawayOrders = (data.allow_takeaway_orders === true);
      config.takeawayPackageActive = (data.takeaway_package_active === true);
      config.planType = data.subscription_plan || data.plan_type || 'pro';
      config.isActive = (data.is_active !== false);

      setStoredData('config', config);
      updateAppBranding();
      renderMenuDishes();
      updateCartUI();
      if (typeof populateTableOptions === 'function') populateTableOptions();
    }
  } catch (err) {
    console.warn("Supabase config sync error:", err);
  }

  // اشتراك Realtime لحظي لتلقي أي تحديث يحدث في هذا المطعم حصراً
  const syncSubKey = '_restaurantRealtimeSyncSubscribed_' + restId;
  if (client && !window[syncSubKey]) {
    window[syncSubKey] = true;
    try {
      client.channel(`public:restaurants_sync_${restId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'restaurants', filter: `id=eq.${restId}` }, (payload) => {
          console.log("Supabase restaurant updated in realtime:", payload);
          syncRestaurantConfigFromSupabase();
        })
        .subscribe();
    } catch (e) {
      console.warn("Supabase Realtime subscription error:", e);
    }

    // إعادة المزامنة تلقائياً عند عودة التركيز للمتصفح
    window.addEventListener('focus', () => {
      syncRestaurantConfigFromSupabase();
      syncMenuFromSupabase();
    });

    // مزامنة دورية تلقائية كل 4 ثوانٍ لضمان التحديث الحي حتى لو كان اشتراك Realtime غير مفعل بالجدول
    setInterval(() => {
      syncRestaurantConfigFromSupabase();
    }, 4000);
  }
}

// -------------------------------------------------------------
// مزامنة أطباق وأقسام المنيو لحظياً مع سحابة Supabase
// -------------------------------------------------------------
async function syncMenuFromSupabase() {
  const client = typeof getSupabase === 'function' ? getSupabase() : null;
  const restId = typeof getActiveRestaurantId === 'function' ? getActiveRestaurantId() : (typeof DEFAULT_RESTAURANT_ID !== 'undefined' ? DEFAULT_RESTAURANT_ID : 'fahma_dokhan');
  if (!client) return;

  try {
    // 1. جلب الأقسام من السحابة
    const { data: catData, error: catErr } = await client
      .from('restaurant_categories')
      .select('*')
      .eq('restaurant_id', restId)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (!catErr && catData && catData.length > 0) {
      const categories = [
        { id: "all", name: "الكل", nameEn: "All", icon: "🍽️" },
        ...catData.map(c => ({
          id: c.id,
          name: c.name,
          nameEn: c.name_en || '',
          icon: c.icon || '🍽️'
        }))
      ];
      setStoredData('categories', categories);
    }

    // 2. جلب الأطباق من السحابة
    const { data: dishData, error: dishErr } = await client
      .from('restaurant_dishes')
      .select('*')
      .eq('restaurant_id', restId)
      .order('created_at', { ascending: true });

    if (!dishErr && dishData && dishData.length > 0) {
      // خريطة لحفظ isWeighted/unitPrice لاصناف السمك عند المزامنة من Supabase
      const _wMap = {};
      if (typeof DEFAULT_DISHES !== 'undefined') {
        DEFAULT_DISHES.filter(function(d){ return d.isWeighted; }).forEach(function(d){ _wMap[String(d.id)] = d; });
      }
      const dishes = dishData.map(d => {
        const dishId = isNaN(d.id) ? d.id : Number(d.id);
        const resolvedOldPrice = (d.old_price !== undefined && d.old_price !== null && Number(d.old_price) > 0) ? Number(d.old_price) : null;
        const _def = _wMap[String(d.id)] || {};
        const isWeighted = !!(_def.isWeighted || d.category_id === 'fish');
        const price = Number(d.price) || 0;
        return {
          id: dishId,
          name: d.name,
          nameEn: d.name_en || '',
          categoryId: d.category_id,
          price: price,
          oldPrice: resolvedOldPrice,
          unitPrice: isWeighted ? price : undefined,
          isWeighted: isWeighted || undefined,
          ingredients: d.ingredients || d.description || '',
          description: d.description || d.ingredients || '',
          calories: d.calories ? (d.calories + ' سعرة') : '',
          prepTime: d.prep_time || 15,
          available: d.is_available !== false,
          isPopular: !!d.is_featured,
          isNew: d.badge === 'جديد',
          image: d.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'
        };
      }).filter(d => d && d.id && d.id !== 'undefined');

      setStoredData('dishes', dishes);

      // اعادة رسم المنيو في الشاشة فورا
      if (typeof renderCategories === 'function') renderCategories();
      if (typeof renderMenuDishes === 'function') renderMenuDishes();
    }
  } catch (err) {
    console.warn("Supabase menu sync error:", err);
  }

  // اشتراك Realtime لحظي لأي تغيير في أطباق أو تصنيفات المنيو
  if (client && !window._menuRealtimeSubscribed) {
    window._menuRealtimeSubscribed = true;
    try {
      let debounceTimer = null;
      const triggerRealtimeSync = () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          syncMenuFromSupabase();
        }, 500);
      };

      client.channel(`public:menu_realtime_${restId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'restaurant_dishes', filter: `restaurant_id=eq.${restId}` }, triggerRealtimeSync)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'restaurant_categories', filter: `restaurant_id=eq.${restId}` }, triggerRealtimeSync)
        .subscribe();
    } catch (e) {
      console.warn("Supabase menu realtime error:", e);
    }
  }
}

/* AUTO_MIGRATED_FISH_DATA_V1 */
(function migrateFishData() {
  try {
    const cats = getStoredData('categories', DEFAULT_CATEGORIES);
    if (!cats.some(c => c.id === 'fish')) {
      const chickenIdx = cats.findIndex(c => c.id === 'chicken');
      const pos = chickenIdx !== -1 ? chickenIdx + 1 : cats.length;
      cats.splice(pos, 0, { id: "fish", name: "الأسماك والمسكوف", nameEn: "Fish & Masgouf", icon: "🐟" });
      setStoredData('categories', cats);
    }
    const currentDishes = getStoredData('dishes', DEFAULT_DISHES);
    const hasFish = currentDishes.some(d => d.categoryId === 'fish');
    if (!hasFish) {
      const newFish = DEFAULT_DISHES.filter(d => d.categoryId === 'fish');
      if (newFish.length > 0) {
        setStoredData('dishes', [...currentDishes, ...newFish]);
      }
    }
  } catch(e) {}
})();


// ترقية قسم الأسماك إلى صنف الكيلو الموحد بالوزن الفعلي
(function migrateToSingleWeightedFish() {
  try {
    let dishes = JSON.parse(localStorage.getItem('smart_emenu_dishes') || '[]');
    let changed = false;
    if (Array.isArray(dishes) && dishes.length > 0) {
      const hasOldFish = dishes.some(d => String(d.id).startsWith('fd_8') || (Number(d.id) >= 801 && Number(d.id) <= 836));
      if (hasOldFish) {
        dishes = dishes.filter(d => !String(d.id).startsWith('fd_8') && !(Number(d.id) >= 801 && Number(d.id) <= 836));
        changed = true;
      }
      if (!dishes.some(d => d.id === 'fd_fish_masgouf')) {
        dishes.push({
          id: 'fd_fish_masgouf',
          categoryId: 'fish',
          name: 'سمك مسكوف عراقي بالوزن (سعر الكيلو)',
          nameEn: 'Iraqi Masgouf Fish (Per KG)',
          price: 10000,
          unitPrice: 10000,
          isWeighted: true,
          defaultWeight: 2.0,
          unit: 'كغم',
          description: 'سمك كارب عراقي حي طازج يوزن ويشوى على الحطب، يحسب السعر وفق الوزن الفعلي للسمكة (10,000 د.ع لكل كغم) ويقدم مع الخبز الحار والطرشي والليمون والعمبة وسيرفيس الخضار.',
          image: 'https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format&fit=crop&w=600&q=80',
          available: true,
          is_available: true,
          isPopular: true
        });
        changed = true;
      }
      if (changed) {
        localStorage.setItem('smart_emenu_dishes', JSON.stringify(dishes));
      }
    }
  } catch(e) {}
})();

// =============================================================
// ميزات خدمة الطاولة: نداء الكابتن 🛎️ وطلب الفاتورة 💳
// =============================================================
let _waiterCallCooldown = false;
let _billRequestCooldown = false;

function playCustomerBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1); // A5
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.4);
  } catch(e) {}
}

window.triggerCallWaiter = async function() {
  if (_waiterCallCooldown) {
    alert("⏳ لقد قمت بإرسال نداء مؤخراً! الكابتن في طريقه إليكم الآن.");
    return;
  }

  let tableNum = selectedTableNumber;
  if (!tableNum || isNaN(tableNum) || tableNum <= 0) {
    const input = prompt("يرجى إدخال رقم طاولتك لإرسال نداء إلى كابتن الصالة:");
    if (!input) return;
    tableNum = parseInt(input);
    if (isNaN(tableNum) || tableNum <= 0) {
      alert("رقم الطاولة غير صحيح!");
      return;
    }
    selectedTableNumber = tableNum;
    sessionStorage.setItem('customer_table_number', tableNum);
    const quickBar = document.getElementById('quick-table-service-bar');
    const quickIndicator = document.getElementById('quick-table-indicator');
    if (quickBar) { quickBar.classList.remove('hidden'); quickBar.style.display = 'flex'; }
    if (quickIndicator) quickIndicator.textContent = `طاولة رقم [ ${tableNum} ]`;
  }

  playCustomerBeep();

  const currentRest = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const alertPayload = {
    type: 'CALL_WAITER',
    service: 'call_waiter',
    tableNumber: tableNum,
    restaurant_id: currentRest,
    timestamp: Date.now()
  };

  // 1. الإرسال الفوري محلياً لجميع شاشات النظام عبر BroadcastChannel
  try {
    if ('BroadcastChannel' in window) {
      const bc = new BroadcastChannel('smart_emenu_channel');
      bc.postMessage(alertPayload);
    }
  } catch(e) {}

  // 2. البث السحابي اللحظي عبر Supabase Realtime
  try {
    const client = (typeof getSupabase === 'function') ? getSupabase() : null;
    if (client) {
      const channelName = `orders_channel_${currentRest}`;
      const ch = client.channel(channelName);
      ch.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          ch.send({
            type: 'broadcast',
            event: 'call_waiter',
            payload: alertPayload
          });
        }
      });
    }
  } catch(e) {}

  _waiterCallCooldown = true;
  setTimeout(() => { _waiterCallCooldown = false; }, 20000);

  alert(`🛎️ تم إرسال نداء إلى الكابتن بنجاح!\nطاولة رقم [ ${tableNum} ]\nالكابتن في طريقه إليكم الآن 🏃‍♂️`);
};

window.triggerRequestBill = async function() {
  if (_billRequestCooldown) {
    alert("⏳ لقد أرسلت طلب الفاتورة مسبقاً! جاري إعداد وتجهيز الحساب من الكاشير.");
    return;
  }

  let tableNum = selectedTableNumber;
  if (!tableNum || isNaN(tableNum) || tableNum <= 0) {
    const input = prompt("يرجى إدخال رقم طاولتك لطلب الفاتورة والحساب:");
    if (!input) return;
    tableNum = parseInt(input);
    if (isNaN(tableNum) || tableNum <= 0) {
      alert("رقم الطاولة غير صحيح!");
      return;
    }
    selectedTableNumber = tableNum;
    sessionStorage.setItem('customer_table_number', tableNum);
    const quickBar = document.getElementById('quick-table-service-bar');
    const quickIndicator = document.getElementById('quick-table-indicator');
    if (quickBar) { quickBar.classList.remove('hidden'); quickBar.style.display = 'flex'; }
    if (quickIndicator) quickIndicator.textContent = `طاولة رقم [ ${tableNum} ]`;
  }

  playCustomerBeep();

  const currentRest = (typeof getActiveRestaurantId === 'function') ? getActiveRestaurantId() : 'fahma_dokhan';
  const alertPayload = {
    type: 'REQUEST_BILL',
    service: 'request_bill',
    tableNumber: tableNum,
    restaurant_id: currentRest,
    timestamp: Date.now()
  };

  // 1. الإرسال الفوري محلياً لجميع شاشات النظام عبر BroadcastChannel
  try {
    if ('BroadcastChannel' in window) {
      const bc = new BroadcastChannel('smart_emenu_channel');
      bc.postMessage(alertPayload);
    }
  } catch(e) {}

  // 2. البث السحابي اللحظي عبر Supabase Realtime
  try {
    const client = (typeof getSupabase === 'function') ? getSupabase() : null;
    if (client) {
      const channelName = `orders_channel_${currentRest}`;
      const ch = client.channel(channelName);
      ch.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          ch.send({
            type: 'broadcast',
            event: 'request_bill',
            payload: alertPayload
          });
        }
      });
    }
  } catch(e) {}

  _billRequestCooldown = true;
  setTimeout(() => { _billRequestCooldown = false; }, 20000);

  alert(`💳 تم إرسال طلب الفاتورة للكاشير بنجاح!\nطاولة رقم [ ${tableNum} ]\nموظف الحسابات في خدمتكم فوراً 🧾`);
};